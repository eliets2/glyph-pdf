from pathlib import Path
from collections import Counter
import hashlib, json, re, shutil, zipfile

base=Path(__file__).resolve().parent.parent
out=base/'outputs'; work=base/'work'
old='0caa45e7d0751caaa36a54a085c41211a422f019'
new='b58b91054ca7a573a09c56d950588ac4f966df42'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return p.read_text(encoding='utf-8',errors='replace')

# Complete the saved architecture report's coverage appendix from its existing
# manifest; this changes presentation, not review-depth labels.
arc=json.loads(read(work/'team-architecture-review/coverage.json'))['files']
arcpath=out/'TEAM-ARCHITECTURE-REVIEW-2026-09-07.md'
arc_text=read(arcpath)
marker='<!-- Coverage table is generated from work/team-architecture-review/coverage.json. -->'
arc_text=arc_text.split(marker)[0]+marker+'\n\n| File | Lines | Review depth |\n|---|---:|---|\n'
for item in arc:
    arc_text+=f"| {item['file']} | {item['lines'] if item['lines'] is not None else 'asset'} | {item['review']} |\n"
arcpath.write_text(arc_text,encoding='utf-8')

engpath=out/'TEAM-ENGINE-CODE-REVIEW-2026-09-07.md'
eng=read(engpath).replace('`AutosaveManager.cpp:95–101` captures','`AutosaveManager.cpp:84–91` captures').replace('worker at lines 139–148','worker at lines 135–148').replace('Completion at lines 109–118','Completion at lines 103–118')
engpath.write_text(eng,encoding='utf-8')
infpath=out/'TEAM-INFRASTRUCTURE-REVIEW-2026-09-07.md'
inf=read(infpath).replace('contains 294 first-party files under `src` (60,247 text lines)', 'contains 294 text-bearing first-party files under `src` (60,247 text lines), plus the binary icon: 295 files total')
infpath.write_text(inf,encoding='utf-8')

planpath=out/'GLM-FLASH-IMPLEMENTATION-AND-UI-PLAN-2026-09-05.md'
plan=read(planpath)
marker1='<!-- TEAM-CHECKPOINT-2026-09-08 -->'; marker2='<!-- END-TEAM-CHECKPOINT-2026-09-08 -->'
plan=re.sub(re.escape(marker1)+r'.*?'+re.escape(marker2)+r'\n*','',plan,flags=re.S)
first,sep,rest=plan.partition('\n')
prefix=f'''\n\n{marker1}
> **Current review checkpoint — 8 September 2026:** use [the consolidated team review]({(out/'TEAM-QUALITY-REVIEW-2026-09-08.md').as_posix()}) and [research reconciliation]({(out/'RESEARCH-RECONCILIATION-2026-09-08.md').as_posix()}) before executing the older package instructions below. The remote review is pinned to `{new}`. The team reports 21 new findings, including eight P1 items; branch acceptance is withheld. Repair shared save, document identity, autosave/annotations, close-after-save and undo failures first. N01/N02/N03/N04/N05/N07/N10 and E-1 now have scoped independent acceptance; N06/N09/D02-redaction remain partial. D01/D06/N08 and earlier V/D findings still require work. The older checkpoint/status sections below describe their dated revisions and are superseded where this new review supplies a disposition.
>
> The research synthesis is a proposal, not implementation status. DocMDP certification and recipient encryption already have code paths; do not rebuild them as missing. No installed UI review or reinstallation was performed. Each new fix stays `implemented-awaiting-review` until independent acceptance.
{marker2}
\n'''
planpath.write_text(first+prefix+rest,encoding='utf-8')

# Pin the changing research inputs for reproducible local reconciliation.
rroot=Path(r'C:\Users\User\Projects\pdf\.context\research')
rwork=work/'team-research-review'; rwork.mkdir(exist_ok=True)
inventory=[]
for p in sorted(rroot.rglob('*')):
    if p.is_file(): inventory.append({'path':p.relative_to(rroot).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)})
briefs=[p for p in sorted(rroot.glob('*.md'))]
for p in briefs:
    target=rwork/'curated-inputs'/p.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(p,target)
research_manifest={'root':str(rroot),'curated_count':len(briefs),'all_file_count':len(inventory),'files':inventory,
    'review_depth':'Methods, conclusions, deltas, recommendations and selected feature tables in all17 input briefs; synthesis read in full. Raw cache inventoried only.',
    'official_pages_rechecked':['https://support.bluebeam.com/revu/how-to/manage-and-review-markups-with-filter-list.html','https://www.sejda.com/ocr-pdf','https://help.abbyy.com/en-us/finereader/16/user_guide/checkingtext/','https://www.ilovepdf.com/compare-pdf']}
(rwork/'research-input-manifest.json').write_text(json.dumps(research_manifest,indent=2),encoding='utf-8')

oldzip=zipfile.ZipFile(work/'parity-0caa45e.zip');newzip=zipfile.ZipFile(work/'team-new-review/source-b58b910.zip')
ec=json.loads(read(work/'team-engine-review/coverage.json'))
owned={x for x in oldzip.namelist() if x.startswith('src/') and not x.endswith('/')}
coverage=ec+arc; names={x['file'] for x in coverage}
assert names==owned and len(coverage)==len(names)
for item in coverage: assert hashlib.sha256(oldzip.read(item['file'])).hexdigest()==item['sha256'],item['file']
for name in newzip.namelist():
    if not name.endswith('/'):
        p=work/'team-new-review/source'/name
        assert p.exists() and digest(p)==hashlib.sha256(newzip.read(name)).hexdigest(),name
assert (work/'team-new-review/build/CTestTestfile.cmake').read_bytes()==(work/'team-new-review/new-original-CTestTestfile.cmake').read_bytes()

# Save the pinned ledger and metadata next to evidence, with no repository edit.
(work/'team-new-review/pinned-ledger.md').write_bytes(newzip.read('docs/audit/CURRENT-EVIDENCE-LEDGER-2026-09-05.md'))
metadata={'baseline':old,'new_revision':new,'new_source_archive_sha256':digest(work/'team-new-review/source-b58b910.zip'),
    'baseline_source_archive_sha256':digest(work/'parity-0caa45e.zip'),'baseline_tracked_src_files':len(owned),
    'coverage_has_no_gaps_or_overlap':True,'coverage_hashes_match_source':True,'current_extracted_source_matches_archive':True,
    'ctest_config_restored':True,'delta_files':len(read(work/'team-new-review/files.txt').splitlines()),
    'engine_review_depth':dict(Counter(x['depth'] for x in ec)),
    'architecture_review_depth':dict(Counter(x['review'] for x in arc)),
    'test_detail_suites':len(list((work/'team-new-review/new-test-details').glob('*.txt'))),
    'test_result':'106/108 initial full run; after source-root fixture staging, 2/2 targeted retry. Not one clean108/108 run.',
    'research_curated_inputs':len(briefs),'research_files_inventoried':len(inventory)}
(work/'team-review-metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')

def lane_files(lane):
    root=work/lane
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        parts=p.relative_to(root).parts
        if any(x in parts for x in ['build','source','third_party','curated-inputs','profile']): continue
        if p.suffix.lower() in ['.exe','.dll','.zip','.a','.o']: continue
        yield p

def bundle(filename, paths):
    unique=sorted(set(paths))
    entries=[{'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in unique]
    with zipfile.ZipFile(out/filename,'w',zipfile.ZIP_DEFLATED) as z:
        for p in unique: z.write(p,p.relative_to(base).as_posix())
        z.writestr('MANIFEST.json',json.dumps({'review':metadata,'entries':entries},indent=2))
        z.writestr('README.txt','Review-only evidence. All PDF/secret fixtures are synthetic. Probes record failing contracts, so executable exit0 is not feature acceptance. Rebuild against the pinned source and documented vendor trees; build products/vendors are omitted. Source snapshots remain in the review workspace. Preserve the work/ directory relationship for helper includes. The architecture sidecar was cleared later in its probe; prior persisted-note evidence is in probe.log. Original full and targeted-rerun CTest logs are separate.\n')
    with zipfile.ZipFile(out/filename) as z:
        assert z.testzip() is None
        manifest=json.loads(z.read('MANIFEST.json'))
        for item in manifest['entries']: assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
    return {'file':filename,'bytes':(out/filename).stat().st_size,'sha256':digest(out/filename),'entries':len(entries)}

common=[work/'parity_probe.cpp',work/'team-review-metadata.json']
packages=[]
packages.append(bundle('team-engine-review-evidence-2026-09-07.zip',list(lane_files('team-engine-review'))+common+[engpath]))
packages.append(bundle('TEAM-NEW-COMMITS-EVIDENCE-2026-09-07.zip',list(lane_files('team-new-review'))+common+[out/'TEAM-NEW-COMMITS-REVIEW-2026-09-07.md']))
allpaths=common+[work/'team_infrastructure_review.py',work/'team_infrastructure_witness.py',work/'team_finish.py',work/'read_research.py',Path(__file__)]
for lane in ['team-engine-review','team-architecture-review','team-new-review','team-infrastructure-review','team-research-review']: allpaths+=list(lane_files(lane))
allpaths+=list(out.glob('TEAM-*-REVIEW-2026-09-0[78].md'))
allpaths+=[out/'RESEARCH-RECONCILIATION-2026-09-08.md',planpath]
packages.append(bundle('team-quality-evidence-2026-09-08.zip',allpaths))
(out/'TEAM-REVIEW-VERIFICATION-2026-09-08.json').write_text(json.dumps({'review':metadata,'archives':packages},indent=2),encoding='utf-8')
print(json.dumps({'review':metadata,'archives':packages},indent=2))
