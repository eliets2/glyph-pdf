from pathlib import Path
import zipfile,json,re,sys
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent;s=w/'parity-95676e6';out=w/'team-infrastructure-review';out.mkdir(exist_ok=True)
with zipfile.ZipFile(w/'parity-0caa45e.zip') as z:
    files=[p.filename for p in z.infolist() if not p.is_dir()]
    manifest=[]
    for p in files:
        if p.startswith(('src/','tests/','fuzz/','cmake/','.github/','tools/','packaging/')) or p in ['CMakeLists.txt','build_all.bat','CLAUDE.md','CONTRIBUTING.md']:
            raw=z.read(p)
            try:t=raw.decode('utf-8')
            except UnicodeDecodeError:continue
            manifest.append({'path':p,'lines':len(t.splitlines()),'root':p.split('/')[0]})
    (out/'baseline-inventory.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if len(sys.argv)>1 and sys.argv[1]=='read':
        for p in sys.argv[2:]:
            lo,hi=1,100000
            if '@' in p:
                p,span=p.split('@',1);lo,hi=map(int,span.split(':'))
            print('\nFILE:',p)
            t=z.read(p).decode('utf-8',errors='replace')
            print('\n'.join(f'{i+1}: {x}' for i,x in enumerate(t.splitlines()) if lo<=i+1<=hi))
    else:
        for root in sorted(set(p['root'] for p in manifest)):
            group=[p for p in manifest if p['root']==root]
            print(root,len(group),'files',sum(p['lines'] for p in group),'lines')
        print('Infrastructure files:')
        for p in manifest:
            if p['root'] not in ['src','tests']:print(p['path'],p['lines'])
