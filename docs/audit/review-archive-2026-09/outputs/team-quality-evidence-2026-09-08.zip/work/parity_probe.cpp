#include <QApplication>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QUndoStack>
#include <cstdio>
#include "engines/ConversionManager.h"
#include "engines/pdfium/PdfiumBackend.h"
#include "engines/DiffEngine.h"
#include "engines/FormManager.h"
#include "engines/DocumentSession.h"
#include "commands/EditFormFieldCommand.h"

static QString makePdf(const QString& path, const QByteArray& content) {
    QList<QByteArray> objs={
        "<</Type/Catalog/Pages 2 0 R>>",
        "<</Type/Pages/Kids[3 0 R]/Count 1>>",
        "<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>",
        "<</Length "+QByteArray::number(content.size())+">>stream\n"+content+"endstream",
        "<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>"
    };
    QByteArray pdf="%PDF-1.4\n"; QList<qint64> offsets;
    for(int i=0;i<objs.size();++i) { offsets.append(pdf.size()); pdf+=QByteArray::number(i+1)+" 0 obj\n"+objs[i]+"\nendobj\n"; }
    const auto xref=pdf.size(); pdf+="xref\n0 6\n0000000000 65535 f \n";
    for(auto off:offsets) pdf+=QByteArray::number(off).rightJustified(10,'0')+" 00000 n \n";
    pdf+="trailer<</Size 6/Root 1 0 R>>\nstartxref\n"+QByteArray::number(xref)+"\n%%EOF\n";
    QFile f(path); if(!f.open(QIODevice::WriteOnly)||f.write(pdf)!=pdf.size()) return {}; return path;
}

int main(int argc,char**argv) {
    qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString& msg) { std::fprintf(stdout,"%s\n",msg.toUtf8().constData()); });
    QApplication app(argc,argv);
    QCoreApplication::setOrganizationName("GlyphAudit"); QCoreApplication::setApplicationName("ParityProbe");
    QDir().mkpath("../parity-probe-data"); QString d=QDir("../parity-probe-data").absolutePath();
    const QString table=makePdf(d+"/table.pdf", "BT /F1 12 Tf 72 720 Td (Name) Tj ET\nBT /F1 12 Tf 300 720 Td (Amount) Tj ET\nBT /F1 12 Tf 72 700 Td (Alice) Tj ET\nBT /F1 12 Tf 300 700 Td (125) Tj ET\n");
    PdfiumBackend backend; qInfo()<<"LOAD_TABLE"<<backend.loadDocument(table);
    for(const auto& run:backend.extractPageTextRuns(0)) qInfo()<<"TABLE_RUN"<<run.text<<run.rect;
    ConversionManager conversion;
    qInfo()<<"CSV_OK"<<conversion.convertTo(table,d+"/table.csv",IConversionEngine::TargetFormat::Csv);
    QFile csv(d+"/table.csv"); if(!csv.open(QIODevice::ReadOnly)) return 2; qInfo()<<"CSV_BYTES"<<csv.readAll();
    qInfo()<<"XLSX_OK"<<conversion.convertTo(table,d+"/table.xlsx",IConversionEngine::TargetFormat::Excel);
    const QString old=makePdf(d+"/old.pdf","BT /F1 12 Tf 72 720 Td (Apple) Tj ET\n");
    const QString newer=makePdf(d+"/new.pdf","BT /F1 12 Tf 72 720 Td (Orange) Tj ET\n");
    const auto diff=DiffEngine().compare(old,newer,72);
    qInfo()<<"ONE_PAGE_TEXT_EDIT"<<diff.pageCount1<<diff.pageCount2<<"STRUCTURAL_CHANGES"<<diff.pageChanges.size();
    for(const auto& change:diff.pageChanges) qInfo()<<"STRUCTURAL"<<static_cast<int>(change.type)<<change.oldPage<<change.newPage;
    const QString form=makePdf(d+"/form.pdf", "BT /F1 12 Tf 72 720 Td (Synthetic form) Tj ET\n");
    FormManager fm; const bool add=fm.addTextField(form,0,QRectF(72,150,140,30),"field",form);
    qInfo()<<"SAME_PATH_ADD"<<add<<"SIZE"<<QFileInfo(form).size()<<"FIELDS"<<fm.listFields(form);
    QFile data(d+"/data.csv"); if(!data.open(QIODevice::WriteOnly)) return 2; data.write("field\nImported\n"); data.close();
    const QString output=form+".tmp"; QStringList unsupported;
    const bool imported=fm.importFormData(form,d+"/data.csv",output,&unsupported);
    qInfo()<<"IMPORT_TO_TEMP"<<imported<<"OUTPUT_EXISTS"<<QFile::exists(output)<<"UNSUPPORTED"<<unsupported;
    DocumentSession session;session.setPath(form);QUndoStack history;
    EditFormFieldProperties props;props.defaultVal="Changed";
    history.push(new EditFormFieldCommand(&fm,&session,"field",props));
    qInfo()<<"UNDO_BEFORE"<<history.index()<<"VALUE"<<fm.captureFieldSnapshot(form,"field").value;
    FormManager::setSaveFaultForTesting(FormManager::SaveFault::Commit);
    history.undo();
    FormManager::setSaveFaultForTesting(FormManager::SaveFault::None);
    qInfo()<<"UNDO_AFTER_COMMIT_FAILURE"<<history.index()<<"CAN_UNDO"<<history.canUndo()<<"VALUE"<<fm.captureFieldSnapshot(form,"field").value;
    return 0;
}
