#include <QApplication>
#include <QDebug>
#include <QDir>
#include <QEventLoop>
#include <QTimer>
#include <QSemaphore>
#include <QThreadPool>
#include <QtConcurrent>
#include <QUndoStack>
#include <QFile>
#include <QFileInfo>
#include <QCryptographicHash>
#include "../parity-95676e6/tests/mocks/MockPdfEditorEngine.h"
#include <QSettings>
#include <atomic>
#include "engines/AutosaveManager.h"
#include "engines/DocumentSession.h"
#include "engines/PdfEditorEngine.h"
#include "engines/RenderCache.h"
#include "engines/pdfium/PdfiumBackend.h"
#include "core/EncryptedFileSecretStore.h"
#include "commands/DeleteImageCommand.h"
#include "commands/CropPageCommand.h"
#include "commands/ReplaceImageCommand.h"
#include <podofo/podofo.h>
#ifdef DrawText
#undef DrawText
#endif

static void fixture(const QString& path, const QStringList& texts) {
  PoDoFo::PdfMemDocument pdf;
  auto* font=pdf.GetFonts().SearchFont("Helvetica");
  for(const auto& text:texts) {
    auto& page=pdf.GetPages().CreatePage(PoDoFo::Rect(0,0,612,792));
    PoDoFo::PdfPainter painter; painter.SetCanvas(page);
    painter.TextState.SetFont(*font,12);
    painter.DrawText(text.toStdString(),72,700); painter.FinishDrawing();
  }
  pdf.Save(path.toStdString());
}

class InsertFailEngine : public MockPdfEditorEngine { public: int inserts=0,deletes=0,deletedIndex=-1;
 bool insertPageFromBytes(const QString&,int,const QByteArray&) override {++inserts;return false;}
 bool deletePage(const QString&,int index) override {++deletes;deletedIndex=index;return true;}
};
class CropRecordingEngine : public MockPdfEditorEngine {public: QRectF crop{0,0,612,792};int writes=0;
 bool cropPage(const QString&,int,const QRectF& rect) override {crop=rect;++writes;return true;}
};
class BlockingRenderer : public IPdfRenderer {
public:
 QSemaphore entered, release; std::atomic<int> inFlight{0};
 QImage renderPage(int,int) override { ++inFlight; entered.release(); release.acquire(); --inFlight; return QImage(10,10,QImage::Format_RGB32); }
 QImage renderTile(int p,const QRectF&,int dpi) override {return renderPage(p,dpi);}
 QSizeF pageSize(int) const override {return {612,792};}
 QString extractText(int) override {return {};}
};
class QuickRenderer : public IPdfRenderer {
public:
 QSemaphore entered;
 QImage renderPage(int,int) override {entered.release(); return QImage(10,10,QImage::Format_RGB32);}
 QImage renderTile(int p,const QRectF&,int dpi) override {return renderPage(p,dpi);}
 QSizeF pageSize(int) const override {return {612,792};}
 QString extractText(int) override {return {};}
};

int main(int argc,char** argv) {
 QApplication app(argc,argv);
 QCoreApplication::setOrganizationName("GlyphReviewFixture");
 QCoreApplication::setApplicationName("TeamEngineReview");
 const QString dir=QString::fromLocal8Bit(argv[1]); QDir().mkpath(dir);
 QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,dir);
 QSettings::setDefaultFormat(QSettings::IniFormat);
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString& s){fprintf(stdout,"%s\n",s.toUtf8().constData());fflush(stdout);});

 // This path/key is entirely synthetic and never touches the user's vault.
 EncryptedFileSecretStore fallback(dir+"/fake-secrets.json");
 const bool stored=fallback.storeSecret("review-fake-service","not-a-real-credential");
 qInfo()<<"DEFAULT_KEY_FALLBACK_STORED"<<stored<<"READ_MATCHES"<<(fallback.readSecret("review-fake-service")=="not-a-real-credential");
 EncryptedFileSecretStore injected(dir+"/injected-secrets.json",QByteArray("review-test-key"));
 qInfo()<<"INJECTED_KEY_CONTROL"<<injected.storeSecret("review-fake-service","not-a-real-credential")<<(injected.readSecret("review-fake-service")=="not-a-real-credential");

 const QString a=dir+"/A.pdf", b=dir+"/B.pdf";
 fixture(a,{"AUTOSAVE_A"}); fixture(b,{"AUTOSAVE_B"});
 auto engine=std::make_shared<PdfEditorEngine>(); auto doc=std::make_shared<DocumentSession>();
 engine->loadDocumentForEditing(a); doc->setPath(a); doc->markDirty();
 AutosaveManager manager(engine,doc);
 auto* pool=QThreadPool::globalInstance();const int oldCapacity=pool->maxThreadCount();pool->setMaxThreadCount(1);
 QSemaphore started,go;
 auto blocker=QtConcurrent::run([&]{started.release();go.acquire();});started.acquire();
 bool completed=false;QEventLoop loop;
 QObject::connect(&manager,&AutosaveManager::autosaveCompleted,&loop,[&](auto){completed=true;loop.quit();});
 QObject::connect(&manager,&AutosaveManager::autosaveFailed,&loop,[&](auto){loop.quit();});
 QMetaObject::invokeMethod(&manager,"onTick",Qt::DirectConnection);
 const bool loadedB=engine->loadDocumentForEditing(b);doc->setPath(b);
 go.release(); QTimer::singleShot(5000,&loop,&QEventLoop::quit);loop.exec();pool->waitForDone();pool->setMaxThreadCount(oldCapacity);
 PdfiumBackend output;bool reopened=output.loadDocument(a+".autosave.pdf");
 qInfo()<<"AUTOSAVE_B_LOADED"<<loadedB<<"COMPLETED"<<completed<<"A_OUTPUT_REOPENED"<<reopened<<"A_OUTPUT_TEXT"<<output.extractText(0)<<"B_LAST_AUTOSAVE_SET"<<doc->lastAutosave().isValid();

 for(int mode=0;mode<3;++mode){
 const QString path=dir+QString("/save-%1.pdf").arg(mode); fixture(path,{"SOURCE_FIRST","SOURCE_SECOND"});
 QFile original(path);original.open(QIODevice::ReadOnly);QByteArray originalBytes=original.readAll();original.close();QFile beforeFile(path+".before");beforeFile.open(QIODevice::WriteOnly);beforeFile.write(originalBytes);beforeFile.close();
 engine->loadDocumentForEditing(path);
 bool ok=mode==2?engine->rotatePage(path,0,90):engine->saveDocument(mode==0?dir+"/safe-copy.pdf":path);
 const QString target=mode==0?dir+"/safe-copy.pdf":path;PdfiumBackend saved;
 bool opens=saved.loadDocument(target);qInfo()<<"NORMAL_SAVE_MODE"<<mode<<"RETURNED"<<ok<<"REOPENS"<<opens<<"PAGES"<<saved.pageCount()<<"BYTES"<<QFileInfo(target).size()<<"ORIGINAL_BYTES"<<originalBytes.size()<<"ORIGINAL_SHA256"<<QCryptographicHash::hash(originalBytes,QCryptographicHash::Sha256).toHex();
 }
 // Fault fixture: empty backup from a failed extraction. Both commands must
 // stop before deleting another page if restoring that backup fails.
 for(int which=0;which<2;++which){
   const QString path=dir+QString("/undo-%1.pdf").arg(which);
   fixture(path,{"PAGE_ONE","PAGE_TWO"});engine->loadDocumentForEditing(path);doc->setPath(path);
   PdfiumBackend beforeDoc; beforeDoc.loadDocument(path); const int before=beforeDoc.pageCount(); beforeDoc.closeDocument();
   if(which==0){DeleteImageCommand command(engine.get(),doc.get(),0,"MissingImage",{});command.undo();}
   else {ReplaceImageCommand command(engine.get(),doc.get(),0,"MissingImage",dir+"/missing.png",{});command.undo();}
   PdfiumBackend afterDoc; afterDoc.loadDocument(path); qInfo()<<"IMAGE_UNDO_KIND"<<which<<"PAGES_BEFORE"<<before<<"PAGES_AFTER"<<afterDoc.pageCount()<<"TEXT"<<afterDoc.extractText(0);
 }

 for(int which=0;which<2;++which){InsertFailEngine fault;DocumentSession session;session.setPath("review-fixture.pdf");
 if(which==0){DeleteImageCommand cmd(&fault,&session,0,"Image",{});cmd.undo();}
 else{ReplaceImageCommand cmd(&fault,&session,0,"Image","replacement.png",{});cmd.undo();}
 qInfo()<<"IMAGE_UNDO_FAULT_KIND"<<which<<"INSERTS"<<fault.inserts<<"DELETES"<<fault.deletes<<"DELETED_INDEX"<<fault.deletedIndex<<"DIRTY"<<session.isDirty();}
 {CropRecordingEngine cropEngine;DocumentSession session;session.setPath("review-fixture.pdf");QUndoStack history;
 QRectF original=cropEngine.crop;history.push(new CropPageCommand(&cropEngine,&session,0,QRectF(20,20,500,700)));history.undo();
 qInfo()<<"CROP_UNDO_HISTORY_INDEX"<<history.index()<<"BACKEND_WRITES"<<cropEngine.writes<<"ORIGINAL_RESTORED"<<(cropEngine.crop==original);}
 // The first prefetch is deliberately still rendering when a replacement
 // prefetch completes. clear() must drain BOTH before renderer retirement.
 pool->setMaxThreadCount(qMax(2,oldCapacity));
 auto cache=std::make_shared<RenderCache>();cache->setPageCount(2);
 BlockingRenderer slow;QuickRenderer fast;
 cache->prefetchViewport(0,1.0,&slow);slow.entered.acquire();
 cache->prefetchViewport(0,2.0,&fast);fast.entered.acquire();
 cache->clear();qInfo()<<"PREFETCH_STILL_IN_RENDER_AFTER_CLEAR"<<slow.inFlight.load();
 slow.release.release();pool->waitForDone();cache.reset();pool->setMaxThreadCount(oldCapacity);
 return 0;
}
