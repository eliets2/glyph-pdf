from pathlib import Path
import sys, json
sys.stdout.reconfigure(encoding='utf-8')
root = Path(r'C:\Users\User\Projects\pdf\.context\research')
files = sorted(root.glob('*.md'))
if len(sys.argv) == 1:
    print(json.dumps([{'name': p.name, 'bytes': p.stat().st_size, 'lines': len(p.read_text(encoding='utf-8', errors='replace').splitlines())} for p in files], indent=2))
else:
    for spec in sys.argv[1:]:
        name, _, span = spec.partition('@')
        p = root / name
        print('\n===== ' + name + ' =====\n')
        lines = p.read_text(encoding='utf-8', errors='replace').splitlines()
        if span:
            start, end = map(int, span.split(':'))
            print('\n'.join(f'{i}: {lines[i-1]}' for i in range(start, min(end, len(lines))+1)))
        else:
            print('\n'.join(lines))
