from pathlib import Path
import sys, json, re, hashlib, zipfile
sys.stdout.reconfigure(encoding='utf-8')
base = Path(__file__).resolve().parent.parent
research = Path(r'C:\Users\User\Projects\pdf\.context\research')
if sys.argv[1] == 'inventory':
    for folder in ['team-new-review','team-engine-review','team-architecture-review','team-infrastructure-review']:
        print('\n'+folder)
        for p in sorted((base/'work'/folder).rglob('*')):
            if p.is_file() and not any(x in p.relative_to(base/'work'/folder).parts for x in ['source','build','.git','fixture-output']):
                print(str(p.relative_to(base)) + ' ' + str(p.stat().st_size))
elif sys.argv[1] == 'research':
    for name in sys.argv[2:]:
        p = research/name
        lines = p.read_text(encoding='utf-8', errors='replace').splitlines()
        print('\n===== '+name+' =====')
        take = True
        for i,l in enumerate(lines,1):
            if l.startswith('## '):
                take = bool(re.search('Method|Confidence|GlyphPDF|Implication|Recommendation|Synthesis|summary|Summary|Failure|Loved|Source|Licens|Opportunity|Limit|UX|Task-first|Anti-',l,re.I))
            if take:
                print(str(i)+': '+l)
elif sys.argv[1] == 'read':
    for name in sys.argv[2:]:
        p=base/name
        print('\n===== '+name+' =====\n'+p.read_text(encoding='utf-8',errors='replace'))
elif sys.argv[1] == 'metadata':
    for lane in ['team-engine-review','team-architecture-review']:
        data=json.loads((base/'work'/lane/'coverage.json').read_text())
        print(lane, type(data).__name__)
        print(json.dumps(data[:3] if isinstance(data,list) else {k:(v[:2] if isinstance(v,list) else v) for k,v in data.items()},indent=2)[:6000])
    for p in sorted(research.glob('*.md')):
        lines=p.read_text(encoding='utf-8',errors='replace').splitlines()
        print(p.name, ' | '.join(f'{i}: {s}' for i,s in enumerate(lines,1) if s.startswith('## ')))
elif sys.argv[1] == 'check':
    source=base/'work/team-new-review/source'
    old=zipfile.ZipFile(base/'work/parity-0caa45e.zip')
    new=zipfile.ZipFile(base/'work/team-new-review/source-b58b910.zip')
    ec=json.loads((base/'work/team-engine-review/coverage.json').read_text())
    arc=json.loads((base/'work/team-architecture-review/coverage.json').read_text())['files']
    names={x['file'] for x in ec+arc}
    owned={x for x in old.namelist() if x.startswith('src/') and not x.endswith('/')}
    print('BASELINE_SRC',len(owned),'LANE_UNION',len(names),'UNCOVERED',sorted(owned-names),'OUTSIDE',sorted(names-owned),'OVERLAP',sorted({x['file'] for x in ec}&{x['file'] for x in arc}))
    errors=[]
    for x in ec+arc:
        if hashlib.sha256(old.read(x['file'])).hexdigest()!=x['sha256']: errors.append(x['file'])
    print('COVERAGE_HASH_ERRORS',errors)
    print('CURRENT_ARCHIVE_SHA256',hashlib.sha256((base/'work/team-new-review/source-b58b910.zip').read_bytes()).hexdigest())
    changed=[]
    for name in owned:
        if name in new.namelist() and old.read(name)!=new.read(name): changed.append(name)
    print('CHANGED_SRC', sorted(changed))
    for spec in sys.argv[2:]:
        name,_,span=spec.partition('@')
        lines=new.read(name).decode('utf-8',errors='replace').splitlines()
        print('\n'+name)
        if span:
            start,end=map(int,span.split(':'))
            print('\n'.join(f'{i}: {lines[i-1]}' for i in range(start,min(end,len(lines))+1)))
        else:
            for i,l in enumerate(lines,1):
                if re.search('certify|DocMDP|EncryptPubSec|recipient|Certify|certificate-based|certificate encryption',l,re.I):
                    print(f'{i}: {l}')
