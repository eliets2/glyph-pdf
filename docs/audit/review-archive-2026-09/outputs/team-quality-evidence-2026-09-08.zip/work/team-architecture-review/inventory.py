from pathlib import Path
import json,re,hashlib
w=Path(__file__).parent;s=w.parent/'parity-95676e6'
owned=[p for p in (s/'src').rglob('*') if p.is_file() and (p.relative_to(s).parts[1] in ('app','modes','shell','ui','util') or len(p.relative_to(s).parts)==2)]
deep=set('''src/GpMainWindow.cpp src/GpMainWindow.h src/app/Bootstrapper.cpp src/app/Bootstrapper.h src/shell/controllers/HomeController.cpp src/shell/controllers/HomeController.h src/shell/controllers/FormsController.cpp src/shell/controllers/FormsController.h src/shell/controllers/PagesController.cpp src/shell/controllers/PagesController.h src/shell/Sidebar.cpp src/shell/Sidebar.h src/shell/StatusBar.cpp src/shell/StatusBar.h src/modes/ModeController.cpp src/modes/ModeController.h src/modes/PdfAValidationPanel.cpp src/modes/PdfAValidationPanel.h src/ui/PdfViewerWidget.cpp src/ui/PdfViewerWidget.h src/ui/AnnotationLayer.h'''.split())
targeted=set('''src/shell/controllers/EditController.cpp src/shell/controllers/SecurityController.cpp src/modes/FormBuilderMode.cpp src/modes/FormFieldPropertiesPanel.cpp src/modes/RedactMode.cpp src/modes/PagesMode.cpp src/ui/SignaturePicker.cpp src/ui/AnnotationLayer.cpp src/ui/CommentsWidget.cpp src/ui/EditAnnotationCommand.cpp src/ui/PreferencesDialog.cpp'''.split())
rows=[];scan=[]
for p in sorted(owned):
 rel=p.relative_to(s).as_posix(); data=p.read_bytes()
 if p.suffix not in ('.cpp','.h'): status='inventory-only non-C++ asset';n=None
 else:
  text=data.decode('utf-8-sig');lines=text.splitlines();n=len(lines)
  status='focused lifecycle/caller deep review' if rel in deep else 'targeted source review' if rel in targeted else 'automated structural scan only'
  funcs=[f'{i}: {line.strip()}' for i,line in enumerate(lines,1) if re.search(r'(?:^[\w:<>&*\s]+::\w+\(|QtConcurrent|QThread::|waitForFinished|QFile::remove|QFile::rename|TODO|FIXME)',line)]
  scan.append(rel+f' ({n} lines)\n'+'\n'.join(funcs))
 rows.append(dict(file=rel,lines=n,sha256=hashlib.sha256(data).hexdigest(),review=status))
(w/'coverage.json').write_text(json.dumps({'baseline':'0caa45e7d0751caaa36a54a085c41211a422f019','files':rows},indent=2),encoding='utf-8')
(w/'structural-scan.txt').write_text('\n\n'.join(scan),encoding='utf-8')
print('Files',len(rows),'C++ lines',sum(x['lines'] or 0 for x in rows))
from collections import Counter
print(Counter(x['review'] for x in rows))
