#define main prior_probe_main
#include "../parity_probe.cpp"
#undef main
#include "GpMainWindow.h"
#include "core/AppContext.h"
#include "engines/PdfEditorEngine.h"
#include "engines/SignatureManager.h"
#include "commands/RotatePageCommand.h"
#include "shell/controllers/HomeController.h"
#include "shell/controllers/PagesController.h"
#include "modes/PdfAValidationPanel.h"
#include "ui/PdfViewerWidget.h"
#include <QSettings>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QCloseEvent>
#include <QTimer>
#include <QEventLoop>
#include <podofo/podofo.h>

static void drain(int ms) { QEventLoop e;QTimer::singleShot(ms,&e,&QEventLoop::quit);e.exec(); }
static int rotation(const QString& path) { PoDoFo::PdfMemDocument d;d.Load(path.toStdString());return d.GetPages().GetPageAt(0).GetRotation(); }
int main(int argc,char**argv) {
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString& msg){std::fprintf(stdout,"%s\n",msg.toUtf8().constData());std::fflush(stdout);});
 QApplication app(argc,argv); app.setQuitOnLastWindowClosed(false);
 QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,QDir::currentPath()+"/profile");
 QCoreApplication::setOrganizationName("GlyphReviewOwnFixtures");QCoreApplication::setApplicationName("Architecture");
 const QString dataDir="data-"+QString::number(QDateTime::currentMSecsSinceEpoch());QDir().mkpath(dataDir);QString dir=QDir(dataDir).absolutePath();
 const auto a=makePdf(dir+"/a.pdf","BT /F1 12 Tf 72 720 Td (Document A) Tj ET\n");
 const auto b=makePdf(dir+"/b.pdf","BT /F1 12 Tf 72 720 Td (Document B) Tj ET\n");
 AppContext ctx;auto engine=std::make_shared<PdfEditorEngine>();ctx.pdfEditor=engine;ctx.document=std::make_shared<DocumentSession>();ctx.undoStack=std::make_shared<QUndoStack>();ctx.forms=std::make_shared<FormManager>();ctx.signing=std::make_shared<SignatureManager>();
 gp::MainWindow window(ctx); window.openDocument(a);drain(100);
 auto* viewer=window.pdfViewer();
 qInfo()<<"ROTATE_IMMEDIATELY_AFTER_OPEN"<<engine->rotatePage(a,0,90)<<"ERROR"<<engine->lastError().userMessage;
 engine->loadDocumentForEditing(a);
 ctx.undoStack->push(new RotatePageCommand(engine.get(),ctx.document.get(),0,90));
 qInfo()<<"A_ROTATED"<<rotation(a)<<"HISTORY"<<ctx.undoStack->count();
 window.openDocument(b);drain(100);
 qInfo()<<"OPEN_B_RETAINED_HISTORY"<<ctx.undoStack->count()<<"B_BEFORE_UNDO"<<rotation(b);
 engine->loadDocumentForEditing(b); // Existing edit/metadata flows prime the shared editor for B.
 ctx.undoStack->undo();
 qInfo()<<"B_AFTER_A_UNDO"<<rotation(b)<<"SESSION"<<ctx.document->path();
 ctx.undoStack->clear();ctx.document->setClean();
 AnnotationItem note;note.mode=ToolMode::AddComment;note.pageIndex=0;note.text="ONLY_A_SECRET_NOTE";note.rect=QRectF(72,72,100,20);
 window.openDocument(a);viewer->setAnnotations({note});
 qInfo()<<"ANNOTATION_EDIT_SESSION_DIRTY"<<ctx.document->isDirty();
 window.openDocument(b);
 qInfo()<<"B_CARRIED_A_ANNOTATIONS"<<viewer->annotations().size()<<"TEXT"<<(viewer->annotations().isEmpty()?QString():viewer->annotations().first().text);
 drain(2400);
 qInfo()<<"B_SIDECAR_CONTAINS_A_NOTE";QFile sidecar(b+".ann");sidecar.open(QIODevice::ReadOnly);qInfo()<<sidecar.readAll().contains("ONLY_A_SECRET_NOTE");sidecar.close();
 window.activateScreen("pdfa");auto* panel=window.findChild<gp::PdfAValidationPanel*>();
 bool emptyLabel=false;for(auto* label:panel->findChildren<QLabel*>())if(label->text()=="No document loaded.")emptyLabel=true;
 qInfo()<<"PDFA_PANEL_SAYS_NO_DOCUMENT"<<emptyLabel<<"VIEWER_HAS_DOC"<<viewer->isLoaded();
 window.activateScreen("");viewer->setAnnotations({});drain(2200);
 int dialogs=0;QTimer clicker;QObject::connect(&clicker,&QTimer::timeout,[&](){for(auto* top:QApplication::topLevelWidgets())if(auto* box=qobject_cast<QMessageBox*>(top)){if(!box->isVisible())continue;dialogs++;if(box->windowTitle()=="Unsaved Changes"){for(auto* button:box->buttons())if(button->text()=="Save")button->click();}else box->accept();}});clicker.start(10);
 ctx.document->markDirty();gp::HomeController home(&ctx,&window);home.activate(ToolId::Save);
 qInfo()<<"SAVE_WITH_VIEWER_OPEN_DIALOG_COUNT"<<dialogs<<"DIRTY"<<ctx.document->isDirty();
 viewer->document()->close();home.activate(ToolId::Save);
 qInfo()<<"AFTER_SAVE_VIEWER_RELEASED_SESSION_DIRTY"<<ctx.document->isDirty()<<"HISTORY_CLEAN"<<ctx.undoStack->isClean();
 viewer->loadDocument(b);
 viewer->setReadOnly(true);gp::PagesController pages(&ctx,&window);const int before=rotation(b);pages.activate(ToolId::RotateCW);
 qInfo()<<"READ_ONLY_ROTATE"<<before<<rotation(b)<<"STILL_READ_ONLY"<<viewer->isReadOnly();
 viewer->setReadOnly(false);ctx.document->markDirty();
 QCloseEvent close;QApplication::sendEvent(&window,&close);clicker.stop();
 qInfo()<<"FAILED_SAVE_CLOSE_ACCEPTED"<<close.isAccepted()<<"DIRTY"<<ctx.document->isDirty()<<"DIALOGS"<<dialogs;
 ctx.document->setClean();drain(300);return 0;
}
