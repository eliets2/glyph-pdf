import pathlib, sys, re
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(__file__).parent.parent/'parity-95676e6'
if sys.argv[1]=='search':
    regex=re.compile(sys.argv[2]); files=list((root/'src').rglob('*'))
    for p in files:
        if p.suffix not in ('.cpp','.h'): continue
        for n,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1):
            if regex.search(line): print(f'{p.relative_to(root)}:{n}: {line}')
else:
    p=root/sys.argv[1]; lines=p.read_text(encoding='utf-8-sig').splitlines()
    start=int(sys.argv[2]) if len(sys.argv)>2 else 1
    end=int(sys.argv[3]) if len(sys.argv)>3 else len(lines)
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1) if start<=n<=end))
