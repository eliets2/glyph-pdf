from pathlib import Path
import zipfile,shutil,subprocess,os,sys,re
w=Path(__file__).resolve().parent;s=w/'source';b=w/'build'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
mode=sys.argv[1]
if mode=='build':
    print('Free GiB:',round(shutil.disk_usage(w).free/2**30,2),flush=True)
    with (w/'new-configure.log').open('w') as log:r=subprocess.run(['cmake','-S',str(s),'-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-g0','-DCMAKE_C_FLAGS_DEBUG=-g0'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Configure exit:',r.returncode,flush=True)
    if r.returncode:print((w/'new-configure.log').read_text());sys.exit(r.returncode)
    with (w/'new-build.log').open('w') as log:r=subprocess.run(['cmake','--build',str(b),'--parallel','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Full build exit:',r.returncode,flush=True);print((w/'new-build.log').read_text()[-1500:]);sys.exit(r.returncode)
elif mode=='test':
    env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env['PATH']]);env['QT_QPA_PLATFORM']='offscreen'
    details=w/'new-test-details';details.mkdir(exist_ok=True)
    config=b/'CTestTestfile.cmake';original=config.read_text();(w/'new-original-CTestTestfile.cmake').write_text(original)
    names='TestExcisionCorruption TestCompareEntry TestBatchMode TestFormSafety TestRapidOcr TestSignaturePicker TestSignatureBadges TestSignatureAppearance TestSignatureSessionCache TestSignatureRealCrypto TestBatchOpsCoverage TestCompareIntegration TestCompressDialogHonesty TestLinkBookmarkRoundTrip TestPageLabels TestPagesMode TestReadingOrderThreshold TestRedactMarkAll TestRedactTransaction TestOcrPreprocessor TestOllamaProvider TestConversionExtraction TestDiffEngine TestCapabilityRegistry TestReadingOrderAsync TestExportPathBadge'.split()
    patched=original
    for name in names:
        patched=re.sub(r'(add_test\('+name+r' "[^"]+"\))',lambda m:m[0][:-1]+' "-o" "'+(details/(name+'.txt')).as_posix()+',txt")',patched)
    config.write_text(patched)
    try:
        with (w/'new-tests.log').open('w') as log:r=subprocess.run(['ctest','--test-dir',str(b),'--output-on-failure','-j','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
        print('Full tests exit:',r.returncode,flush=True);print((w/'new-tests.log').read_text()[-1300:])
    finally:config.write_text(original)
    for p in sorted(details.glob('*.txt')):
        lines=p.read_text(errors='replace').splitlines();print(p.name)
        for i,line in enumerate(lines):
            if any(t in line for t in ('FAIL!','SKIP','Totals:')):print('\n'.join(lines[i:i+(4 if 'FAIL!' in line else 1)]))
    sys.exit(r.returncode)
