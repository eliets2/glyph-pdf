from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;b=w/'build';s=w/'source'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
for name,args in [('sync-delete',['probe.exe','sync-delete']),('capability-functions',['TestCapabilityRegistry.exe','-functions']),('marking-functions',['TestRedactMarkAll.exe','-functions'])]:
    with (w/(name+'.log')).open('w') as log:
        try:r=subprocess.run([str(b/args[0]),*args[1:]],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=15);code=r.returncode
        except subprocess.TimeoutExpired:code='TIMEOUT'
    print(name,code);print((w/(name+'.log')).read_text(errors='replace'))
