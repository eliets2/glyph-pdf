from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;b=w/'build';s=w/'source'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
commands=subprocess.check_output(['ninja','-t','commands','TestOcrVerifyNavigation'],cwd=b,env=env,text=True).splitlines()
command=next(x for x in reversed(commands) if '  libpdfws_ui.a' in x)
libs=['libpdfws_ui.a']+shlex.split(command.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets','Qt6Pdf','Qt6PdfWidgets'],env=env,text=True))
with (w/'probe-build.log').open('w') as log:
    r=subprocess.run(['g++','-std=c++17','-I'+str(s/'src'),'-I'+str(s/'third_party/podofo/install/include'),'-I'+str(s/'third_party/pdfium/include'),*flags,str(w/'probe.cpp'),'-o','probe.exe',*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((w/'probe-build.log').read_text());raise SystemExit(r.returncode)
with (w/'probe.log').open('w') as log:r=subprocess.run([str(b/'probe.exe')],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
print((w/'probe.log').read_text());raise SystemExit(r.returncode)
