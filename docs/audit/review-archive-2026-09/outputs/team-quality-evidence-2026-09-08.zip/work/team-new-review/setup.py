from pathlib import Path
import zipfile, subprocess, shutil, hashlib
root=Path(__file__).resolve().parent
repo=Path(r'C:\Users\User\Projects\pdf-parity')
head='b58b91054ca7a573a09c56d950588ac4f966df42'
base='0caa45e7d0751caaa36a54a085c41211a422f019'
git=['git','-c','safe.directory=C:/Users/User/Projects/pdf-parity','-C',str(repo)]
with zipfile.ZipFile(root/'source-b58b910.zip') as z:z.extractall(root/'source')
for name,args in [('delta.diff',['diff',base+'..'+head]),('commits.txt',['log','--format=%h %s',base+'..'+head]),('status.txt',['status','--short']),('files.txt',['diff','--name-only',base+'..'+head])]:
    (root/name).write_bytes(subprocess.check_output(git+args))
for tree in ['third_party/podofo/install','third_party/pdfium','onnxruntime-win-x64-1.17.3']:
    shutil.copytree(root.parent/'parity-95676e6'/tree,root/'source'/tree,dirs_exist_ok=True)
print('archive_sha256',hashlib.sha256((root/'source-b58b910.zip').read_bytes()).hexdigest())
