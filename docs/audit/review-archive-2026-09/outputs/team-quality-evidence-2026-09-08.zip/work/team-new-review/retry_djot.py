from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;b=w/'build';s=w/'source'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
import shutil
shutil.copytree(s/'third_party/djot',w/'third_party/djot',dirs_exist_ok=True)
with (w/'djot-retry.log').open('w') as log:
    r=subprocess.run(['ctest','--test-dir',str(b),'--output-on-failure','-R','^TestDjot(Roundtrip|Fuzz)$'],env=env,stdout=log,stderr=subprocess.STDOUT)
print((w/'djot-retry.log').read_text());print('exit',r.returncode)
