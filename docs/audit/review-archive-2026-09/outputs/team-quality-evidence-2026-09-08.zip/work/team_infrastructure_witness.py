from pathlib import Path
import ast,json,re,sys,tempfile,zipfile
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent;out=w/'team-infrastructure-review';out.mkdir(exist_ok=True)
oldzip=w/'parity-0caa45e.zip';newzip=w/'team-new-review/source-b58b910.zip'
with zipfile.ZipFile(oldzip) as z:
    paths=['.github/workflows/ci.yml','.github/workflows/release.yml','.github/workflows/glyphpdf-fuzz.yml',
           'fuzz/run_oracles.sh','fuzz/build_clang/build_djot_clang.sh','packaging/build-msi.ps1',
           'packaging/build-portable.ps1','tools/clean_scanned_pdf.py']
    old={p:z.read(p) for p in paths}
with zipfile.ZipFile(newzip) as z:
    latest={p:z.read(p) for p in paths}
same={p:old[p]==latest[p] for p in paths}

# Run the unchanged main() up to its first PDF open. No image-processing
# libraries or user PDFs are involved; this isolates filesystem ordering.
tree=ast.parse(latest['tools/clean_scanned_pdf.py'].decode('utf-8'))
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
class ReaderBoundary:
    @staticmethod
    def open(path):
        Path(path).read_bytes() # missing source raises just as opening a deleted file would
        raise RuntimeError('Stopped at PDF reader boundary; rendering is out of scope')
results=[]
with tempfile.TemporaryDirectory(prefix='cleanup-review-',dir=out) as tmp:
    td=Path(tmp)
    for name,samepath in [('same_input_output',True),('bad_input_existing_output',False)]:
        case=td/name;case.mkdir();source=case/'input.pdf';dest=source if samepath else case/'existing.pdf'
        if samepath:source.write_bytes(b'%PDF-1.4\nsynthetic review fixture')
        else:dest.write_bytes(b'PREVIOUS OUTPUT MUST SURVIVE')
        args=['clean_scanned_pdf.py',str(source),str(case/'intermediate'),str(dest)]
        env={'Path':Path,'sys':type('FakeSys',(),{'argv':args,'stderr':sys.stderr})(),'fitz':ReaderBoundary}
        exec(compile(ast.Module(body=[main],type_ignores=[]),'reviewed-main','exec'),env)
        try:env['main']()
        except Exception as ex:failure=type(ex).__name__
        results.append({'case':name,'error':failure,'input_exists_after':source.exists(),'destination_exists_after':dest.exists()})

msi=latest['packaging/build-msi.ps1'].decode('utf-8');portable=latest['packaging/build-portable.ps1'].decode('utf-8')
versions={'msi':re.search(r"\$Version\s*=\s*'([^']+)'",msi).group(1),'portable':re.search(r"\$Version\s*=\s*'([^']+)'",portable).group(1)}
ci=latest['.github/workflows/ci.yml'].decode('utf-8')
release_guard=(w/'build-parity-95676e6/CMakeFiles/CMakeOutput.log').exists()
facts={'baseline':'0caa45e7d0751caaa36a54a085c41211a422f019','latest':'b58b91054ca7a573a09c56d950588ac4f966df42','reviewed_files_unchanged':same,
       'cleanup_main_boundary_reproductions':results,'packaging_versions':versions,
       'ci_push_branch_declaration':next(x.strip() for x in ci.splitlines() if 'branches: [' in x),
       'built_baseline_CMakeOutput_log_exists':release_guard,
       'reader_witness_limit':'Executed unchanged AST main with reader replaced only to stop before rendering; no claim of image/PDF-library behavior',
       'not_executed':['CI on GitHub','Packaging/deployment/signing','Fuzz campaign']}
(out/'witnesses.json').write_text(json.dumps(facts,indent=2),encoding='utf-8')
print(json.dumps(facts,indent=2))
