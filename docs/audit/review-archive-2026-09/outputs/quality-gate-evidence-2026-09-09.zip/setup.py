from pathlib import Path
import subprocess,zipfile,shutil,hashlib,json
w=Path(__file__).resolve().parent
repo=Path(r'C:\Users\User\Projects\pdf-parity')
git=['git','-c','safe.directory=C:/Users/User/Projects/pdf-parity','-C',str(repo)]
revs={'remote':'e99c73365e14189fc6343da5836d84df24183152','local':'a5840dcfc6b2716e5b11e626a46ae3ec0ba0eaeb'}
base='b58b91054ca7a573a09c56d950588ac4f966df42'
manifest={}
for label,rev in revs.items():
    archive=w/(label+'.zip')
    subprocess.run(git+['archive','--format=zip','--output='+str(archive),rev],check=True)
    with zipfile.ZipFile(archive) as z:z.extractall(w/label)
    manifest[label]={'commit':rev,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
    start=base if label=='remote' else revs['remote']
    for name,args in [('delta.diff',['diff',start+'..'+rev]),('commits.txt',['log','--format=%h %s',start+'..'+rev]),('files.txt',['diff','--name-only',start+'..'+rev])]:
        (w/(label+'-'+name)).write_bytes(subprocess.check_output(git+args))
for label in revs:
    for tree in ['third_party/podofo/install','third_party/pdfium','onnxruntime-win-x64-1.17.3']:
        shutil.copytree(w.parent/'parity-95676e6'/tree,w/label/tree,dirs_exist_ok=True)
(w/'status.txt').write_bytes(subprocess.check_output(git+['status','--short']))
(w/'refs.txt').write_bytes(subprocess.check_output(git+['rev-parse','HEAD','origin/feat/parity-glm']))
(w/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
print('Free GiB',round(shutil.disk_usage(w).free/2**30,2))
