from pathlib import Path
import os,shlex,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
p=Path(__file__).resolve().parent;w=p.parent;b=w/'build-remote';s=w/'remote'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
commands=subprocess.check_output(['ninja','-t','commands','TestOcrVerifyNavigation'],cwd=b,env=env,text=True).splitlines()
command=next(x for x in reversed(commands) if '  libpdfws_ui.a' in x)
libs=['libpdfws_ui.a']+shlex.split(command.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets','Qt6Pdf','Qt6PdfWidgets','Qt6Concurrent'],env=env,text=True))
if '--run' not in sys.argv:
 with (p/'build.log').open('w') as log:
  r=subprocess.run(['g++','-std=c++17','-DHAS_PDFIUM','-I'+str(s/'src'),'-I'+str(s/'tests'),'-I'+str(s/'third_party/podofo/install/include'),'-I'+str(s/'third_party/pdfium/include'),*flags,str(p/'engine_probe.cpp'),'-o',str(p/'engine_probe.exe'),*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:print((p/'build.log').read_text(errors='replace'));raise SystemExit(r.returncode)
for mode in ['','cache-owner-drop']:
 with (p/('probe.log' if not mode else mode+'.log')).open('w') as log:
  try:r=subprocess.run([str(p/'engine_probe.exe'),str(p/'fixtures'),*([mode] if mode else [])],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=40);print(mode or 'main','exit',r.returncode)
  except subprocess.TimeoutExpired:print(mode,'TIMEOUT')
 print((p/('probe.log' if not mode else mode+'.log')).read_text(errors='replace'))
