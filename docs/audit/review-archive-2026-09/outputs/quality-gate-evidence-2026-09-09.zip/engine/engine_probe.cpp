#include <QApplication>
#include <QDebug>
#include <QDir>
#include <QEventLoop>
#include <QTimer>
#include <QSemaphore>
#include <QThreadPool>
#include <QtConcurrent>
#include <QUndoStack>
#include <QFile>
#include <QFileInfo>
#include <QCryptographicHash>
#include <QSettings>
#include <QPdfWriter>
#include <QPainter>
#include <QProcess>
#include <QJsonDocument>
#include <QJsonObject>
#include <atomic>
#include <thread>
#include "engines/AutosaveManager.h"
#include "engines/DocumentSession.h"
#include "engines/PdfEditorEngine.h"
#include "engines/RenderCache.h"
#include "engines/SafeSave.h"
#include "engines/pdfium/PdfiumBackend.h"
#include "core/EncryptedFileSecretStore.h"
#include "commands/DeleteImageCommand.h"
#include "commands/CropPageCommand.h"
#include "commands/ReplaceImageCommand.h"
#include "commands/EditFormFieldCommand.h"
#include "mocks/MockPdfEditorEngine.h"
#include "engines/FormManager.h"
#include <podofo/podofo.h>
#ifdef GetObject
#undef GetObject
#endif

static void fixture(const QString& path,const QStringList& texts) {
 QPdfWriter w(path); w.setPageSize(QPageSize(QPageSize::A4)); w.setResolution(72);
 QPainter p(&w);bool first=true;for(const auto& t:texts){if(!first)w.newPage();first=false;p.drawText(80,100,t);}p.end();
}
static QByteArray bytes(const QString& path){QFile f(path);if(!f.open(QIODevice::ReadOnly))return {};return f.readAll();}
static QString text(const QString& path,int page=0){PdfiumBackend pdf;if(!pdf.loadDocument(path))return {};return pdf.extractText(page);}
static QRectF box(const QString& path){try{PoDoFo::PdfMemDocument pdf;pdf.Load(path.toStdString());auto r=pdf.GetPages().GetPageAt(0).GetCropBox();return {r.X,r.Y,r.Width,r.Height};}catch(...){return {};}}
static void boxFixture(const QString& path,bool inherited) {
 PoDoFo::PdfMemDocument pdf;auto& p=pdf.GetPages().CreatePage(PoDoFo::Rect(0,0,612,792));
 if(inherited){auto* parent=p.GetDictionary().FindKey("Parent");parent->GetDictionary().AddKey("CropBox",PoDoFo::Rect(10,20,500,700).ToArray());}
 else p.GetDictionary().AddKey("CropBox",PoDoFo::Rect(10,20,500,700).ToArray());pdf.Save(path.toStdString());
}
class RestoreFault : public MockPdfEditorEngine {public:bool insertOk=false,deleteOk=true;int inserts=0,deletes=0;
 bool insertPageFromBytes(const QString&,int,const QByteArray&)override{++inserts;return insertOk;}
 bool deletePage(const QString&,int)override{++deletes;return deleteOk;}
};
class BlockingRenderer : public IPdfRenderer {public:QSemaphore entered,release;std::atomic<int> inFlight{0};
 QImage renderPage(int,int)override{++inFlight;entered.release();release.acquire();--inFlight;return QImage(10,10,QImage::Format_RGB32);}
 QImage renderTile(int p,const QRectF&,int d)override{return renderPage(p,d);}
 QSizeF pageSize(int)const override{return {612,792};}QString extractText(int)override{return {};}
};
class QuickRenderer : public IPdfRenderer {public:QSemaphore entered;
 QImage renderPage(int,int)override{entered.release();return QImage(10,10,QImage::Format_RGB32);}
 QImage renderTile(int p,const QRectF&,int d)override{return renderPage(p,d);}
 QSizeF pageSize(int)const override{return {612,792};}QString extractText(int)override{return {};}
};

int main(int argc,char**argv){
 QApplication app(argc,argv);QCoreApplication::setOrganizationName("GlyphGateFixture");QCoreApplication::setApplicationName("EngineGate20260909");
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){fprintf(stdout,"%s\n",s.toUtf8().constData());fflush(stdout);});
 const QString dir=QString::fromLocal8Bit(argv[1]);QDir().mkpath(dir);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,dir);QSettings::setDefaultFormat(QSettings::IniFormat);
 const QString mode=argc>2?QString::fromLocal8Bit(argv[2]):QString();
 if(mode=="secret-write"){EncryptedFileSecretStore store(dir+"/child-secret.json");return store.storeSecret("synthetic-service","SYNTHETIC_NOT_A_CREDENTIAL")?0:3;}
 if(mode=="cache-owner-drop"){
  auto cache=std::make_shared<RenderCache>();cache->setPageCount(2);BlockingRenderer renderer;std::weak_ptr<RenderCache> weak=cache;
  cache->prefetchViewport(0,1,&renderer);if(!renderer.entered.tryAcquire(1,5000))return 4;
  cache.reset();renderer.release.release();qInfo()<<"OWNER_DROP_RELEASED_RENDER";
  const bool drained=QThreadPool::globalInstance()->waitForDone(2000);qInfo()<<"OWNER_DROP_POOL_DRAINED"<<drained<<"WEAK_EXPIRED"<<weak.expired();
  // Deliberately terminate only this synthetic child to avoid the process-wide pool destructor hanging on the demonstrated self-join.
  fflush(stdout);std::_Exit(drained?0:7);
 }
 // EC04: default DPAPI, new instance, separate process, corrupted payload.
 EncryptedFileSecretStore store(dir+"/default-secret.json");const bool stored=store.storeSecret("synthetic-service","SYNTHETIC_NOT_A_CREDENTIAL");EncryptedFileSecretStore again(dir+"/default-secret.json");
 QProcess child;child.start(QCoreApplication::applicationFilePath(),{dir,"secret-write"});child.waitForFinished(10000);EncryptedFileSecretStore childStore(dir+"/child-secret.json");
 qInfo()<<"EC04_DEFAULT"<<stored<<"NEW_INSTANCE"<<(again.readSecret("synthetic-service")=="SYNTHETIC_NOT_A_CREDENTIAL")<<"CHILD_EXIT"<<child.exitCode()<<"CHILD_READ"<<(childStore.readSecret("synthetic-service")=="SYNTHETIC_NOT_A_CREDENTIAL");
 auto json=QJsonDocument::fromJson(bytes(dir+"/default-secret.json")).object();auto entries=json["secrets"].toObject();QByteArray blob=QByteArray::fromBase64(entries["synthetic-service"].toString().toLatin1());qInfo()<<"EC04_BLOB_VERSION"<<int((unsigned char)blob[0])<<"PLAINTEXT_ON_DISK"<<bytes(dir+"/default-secret.json").contains("SYNTHETIC_NOT_A_CREDENTIAL");blob[blob.size()/2]^=0x5a;entries["synthetic-service"]=QString::fromLatin1(blob.toBase64());json["secrets"]=entries;QFile corrupt(dir+"/default-secret.json");corrupt.open(QIODevice::WriteOnly);corrupt.write(QJsonDocument(json).toJson());corrupt.close();qInfo()<<"EC04_CORRUPT_EMPTY"<<store.readSecret("synthetic-service").isEmpty();
 // EC02: queue autosave for dirty A, switch A -> B -> a replaced A path, then release the real worker.
 auto* pool=QThreadPool::globalInstance();int capacity=pool->maxThreadCount();pool->setMaxThreadCount(1);QSemaphore ready,go;auto barrier=QtConcurrent::run([&]{ready.release();go.acquire();});ready.acquire();
 const QString a=dir+"/A.pdf",b=dir+"/B.pdf";fixture(a,{"OLD_A"});fixture(b,{"B"});fixture(a+".autosave.pdf",{"OLD_RECOVERY_A"});const auto previousRecovery=bytes(a+".autosave.pdf");
 auto editor=std::make_shared<PdfEditorEngine>();auto session=std::make_shared<DocumentSession>();editor->loadDocumentForEditing(a);session->beginDocument(a);session->markDirty();AutosaveManager manager(editor,session);int completed=0,stale=0,failed=0;QEventLoop loop;
 QObject::connect(&manager,&AutosaveManager::autosaveCompleted,&loop,[&](auto){++completed;loop.quit();});QObject::connect(&manager,&AutosaveManager::autosaveStale,&loop,[&](auto){++stale;loop.quit();});QObject::connect(&manager,&AutosaveManager::autosaveFailed,&loop,[&](auto){++failed;loop.quit();});
 QMetaObject::invokeMethod(&manager,"onTick",Qt::DirectConnection);editor->loadDocumentForEditing(b);session->beginDocument(b);fixture(a,{"NEW_INCARNATION_A"});editor->loadDocumentForEditing(a);session->beginDocument(a);go.release();QTimer::singleShot(5000,&loop,&QEventLoop::quit);loop.exec();pool->waitForDone();pool->setMaxThreadCount(capacity);
 qInfo()<<"EC02_ABA_COMPLETED"<<completed<<"STALE"<<stale<<"FAILED"<<failed<<"RECOVERY_CHANGED"<<(bytes(a+".autosave.pdf")!=previousRecovery)<<"RECOVERY_TEXT"<<text(a+".autosave.pdf")<<"NEW_SESSION_TIMESTAMP"<<session->lastAutosave().isValid();
 // EC01 ordinary save and rotation controls, and newly enabled encryption of a lazily loaded ordinary PDF.
 for(int which=0;which<3;++which){QString path=dir+QString("/save-%1.pdf").arg(which);fixture(path,{"PAGE_ONE_KEEP","PAGE_TWO_KEEP"});QByteArray before=bytes(path);PdfEditorEngine e;e.loadDocumentForEditing(path);bool encrypted=false;if(which==2)encrypted=e.encryptDocument("","synthetic-owner-password",DocumentPermissions{});bool ok=which==1?e.rotatePage(path,0,90):e.saveDocument(path);qInfo()<<"EC01_SAVE_MODE"<<which<<"ENCRYPTION_SET"<<encrypted<<"RETURN"<<ok<<"BEFORE"<<before.size()<<"AFTER"<<bytes(path).size()<<"TEXT"<<text(path);QFile bf(path+".before");bf.open(QIODevice::WriteOnly);bf.write(before);}
 // EC05 explicit nonzero-origin and inherited crop boxes, real undo/redo artifact geometry.
 for(bool inherited:{false,true}){QString path=dir+(inherited?"/inherited-crop.pdf":"/offset-crop.pdf");boxFixture(path,inherited);auto original=box(path);PdfEditorEngine e;e.loadDocumentForEditing(path);DocumentSession d;d.beginDocument(path);QUndoStack history;history.push(new CropPageCommand(&e,&d,0,QRectF(50,60,400,500)));history.undo();qInfo()<<"EC05_INHERITED"<<inherited<<"ORIGINAL"<<original<<"AFTER_UNDO"<<box(path)<<"HISTORY_INDEX"<<history.index();}
 // Failed command is removed from history but resident mutation survives and leaks into a later successful Save.
 {QString path=dir+"/failed-crop.pdf";boxFixture(path,false);auto original=box(path);auto before=bytes(path);PdfEditorEngine e;e.loadDocumentForEditing(path);DocumentSession d;d.beginDocument(path);int errors=0;QObject::connect(&d,&DocumentSession::mutationFailed,&d,[&](auto){++errors;});QUndoStack history;gp::SafeSave::setCommitFaultForTesting(gp::SafeSave::CommitFaultForTesting::FailBeforeCommit);history.push(new CropPageCommand(&e,&d,0,QRectF(80,90,200,300)));gp::SafeSave::setCommitFaultForTesting(gp::SafeSave::CommitFaultForTesting::None);qInfo()<<"EC05_FAILED_PUSH_COUNT"<<history.count()<<"DIRTY"<<d.isDirty()<<"ERRORS"<<errors<<"DISK_UNCHANGED"<<(bytes(path)==before);bool saveOk=e.saveDocument(path);qInfo()<<"EC05_LATER_SAVE"<<saveOk<<"ORIGINAL"<<original<<"AFTER_SAVE"<<box(path);}
 // EC03 original insert-failure branch is repaired; history and two-phase removal residuals remain observable.
 for(int type=0;type<2;++type){RestoreFault e;e.m_loaded=true;DocumentSession d;d.beginDocument("synthetic.pdf");QUndoStack history;int errors=0;QObject::connect(&d,&DocumentSession::mutationFailed,&d,[&](auto){++errors;});if(type==0)history.push(new DeleteImageCommand(&e,&d,0,"Im1","backup"));else history.push(new ReplaceImageCommand(&e,&d,0,"Im1","replacement.png","backup"));history.undo();qInfo()<<"EC03_INSERT_FAIL_TYPE"<<type<<"INSERTS"<<e.inserts<<"DELETES"<<e.deletes<<"INDEX"<<history.index()<<"CLEAN"<<history.isClean()<<"ERRORS"<<errors;}
 {QString path=dir+"/form-undo.pdf";fixture(path,{"FORM FIXTURE"});FormManager forms;forms.addTextField(path,0,QRectF(72,100,144,24),"F1",path);QVariantMap seed;seed["F1"]="ORIGINAL";forms.fillForm(path,seed,path,false);DocumentSession d;d.beginDocument(path);QUndoStack history;int errors=0;QObject::connect(&d,&DocumentSession::mutationFailed,&d,[&](auto){++errors;});EditFormFieldProperties props;props.defaultVal="EDITED";history.push(new EditFormFieldCommand(&forms,&d,"F1",props));FormManager::setSaveFaultForTesting(FormManager::SaveFault::Commit);history.undo();FormManager::setSaveFaultForTesting(FormManager::SaveFault::None);qInfo()<<"V02_VALUE"<<forms.captureFieldSnapshot(path,"F1").value<<"INDEX"<<history.index()<<"CLEAN"<<history.isClean()<<"CAN_UNDO"<<history.canUndo()<<"CAN_REDO"<<history.canRedo()<<"ERRORS"<<errors;}
 // EC06 original superseded-future clear control. Deterministic barrier prevents hiding an in-flight first renderer.
 {pool->setMaxThreadCount(qMax(3,capacity));auto cache=std::make_shared<RenderCache>();cache->setPageCount(2);BlockingRenderer slow;QuickRenderer fast;cache->prefetchViewport(0,1,&slow);slow.entered.acquire();cache->prefetchViewport(0,2,&fast);fast.entered.acquire();std::atomic<bool> returned{false};QSemaphore clearing;std::thread clearer([&]{clearing.release();cache->clear();returned=true;});clearing.acquire();QThread::msleep(100);qInfo()<<"EC06_CLEAR_RETURNED_BEFORE_RELEASE"<<returned.load()<<"IN_FLIGHT"<<slow.inFlight.load();slow.release.release();clearer.join();pool->waitForDone();qInfo()<<"EC06_CLEAR_RETURNED_AFTER_RELEASE"<<returned.load();cache.reset();pool->setMaxThreadCount(capacity);}
 return 0;
}
