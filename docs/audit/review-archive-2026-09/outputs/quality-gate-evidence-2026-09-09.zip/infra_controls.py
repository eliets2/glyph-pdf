from pathlib import Path
import subprocess,json,hashlib,os,shutil
w=Path(__file__).resolve().parent;root=w/'local';out=w/'infra'/'controls';out.mkdir(parents=True,exist_ok=True)
ps=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
def run(name,script,args):
    p=subprocess.run([ps,'-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)]+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (out/(name+'.log')).write_bytes(p.stdout)
    return {'name':name,'exit':p.returncode,'output':p.stdout.decode(errors='replace')[-1500:]}
rows=[]
app={'directory':'C:/build','file':'src/app/main.cpp','command':'g++ -o CMakeFiles/PdfWorkstation.dir/src/app/main.cpp.obj -c src/app/main.cpp'}
engine={'directory':'C:/build','file':'src/engines/core.cpp','command':'g++ -o CMakeFiles/pdfws_engines.dir/src/engines/core.cpp.obj -c src/engines/core.cpp'}
test={'directory':'C:/build','file':'tests/TestCrypto.cpp','command':'g++ -DGLYPH_TESTING -o CMakeFiles/TestCrypto.dir/tests/TestCrypto.cpp.obj -c tests/TestCrypto.cpp'}
for name,entries in {'normal':[app,engine,test],'missing_engine':[app],'missing_app':[engine],'empty':[],'forbidden_production':[app,dict(engine,command=engine['command']+' -DGLYPH_TESTING')],'missing_file':None}.items():
    evidence=out/(name+'.json')
    if entries is not None:evidence.write_text(json.dumps(entries))
    rows.append(run('defines-'+name,root/'packaging/check-release-defines.ps1',['-BuildDir',str(out),'-CompileCommands',str(evidence)]))
for name,typ,release,lto,home in [('normal','Release','ON','ON',root),('debug','Debug','ON','ON',root),('disabled','Release','OFF','ON',root),('wrong_cmake_source','Release','ON','ON',out),('lto_off','Release','ON','OFF',root)]:
    b=out/name;b.mkdir(exist_ok=True)
    (b/'CMakeCache.txt').write_text(f'CMAKE_BUILD_TYPE:STRING={typ}\nGLYPHPDF_RELEASE_BUILD:BOOL={release}\nGLYPHPDF_ENABLE_LTO:BOOL={lto}\nCMAKE_HOME_DIRECTORY:INTERNAL={home.as_posix()}\n')
    (b/'glyphpdf-release-stamp.txt').write_text(f'SourceDir={root}\nCommit=a5840dcfc6b2716e5b11e626a46ae3ec0ba0eaeb\nTestsPassed=1\nLTO=ON\n')
    rows.append(run('validate-'+name,root/'packaging/validate-release-build.ps1',['-BuildDir',str(b),'-ProjectRoot',str(root),'-RequireStamp','-RequireCommitMatch','-ExpectedCommit','a5840dcfc6b2716e5b11e626a46ae3ec0ba0eaeb']))
deploy_build=out/'dedicated-release';deploy_build.mkdir(exist_ok=True);(deploy_build/'PdfWorkstation.exe').write_bytes(b'SYNTHETIC PLACEHOLDER NEVER EXECUTED')
# Unmodified deploy script stops at its FIRST read-only validation because the
# absolute child path is incorrectly appended to ProjectRoot. No deployment runs.
rows.append(run('deploy-absolute-build-path',root/'packaging/deploy.ps1',['-BuildDir',str(deploy_build)]))
dll=root/'third_party/pdfium/bin/pdfium.dll'
rows.append({'name':'pdfium_hash_subject','dll_sha256':hashlib.sha256(dll.read_bytes()).hexdigest(),'bootstrap_expected':'a487e1d2a18f164adc3a17aacee158787fa86049e6d91d3712b0a43f745e6905','applied_to':'downloaded pdfium.tgz archive before extraction'})
(out/'results.json').write_text(json.dumps(rows,indent=2))
for row in rows:print(row['name'],row.get('exit',row.get('dll_sha256')))
