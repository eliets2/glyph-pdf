from pathlib import Path
import zipfile,hashlib,json,re,subprocess,os
w=Path(__file__).resolve().parent;outputs=w.parent.parent/'outputs'
git=['git','-c','safe.directory=C:/Users/User/Projects/pdf-parity','-C',r'C:\Users\User\Projects\pdf-parity']
for name,args in [('final-refs.txt',['rev-parse','HEAD','origin/feat/parity-glm']),('final-status.txt',['status','--short']),('unreviewed-followup.txt',['log','--oneline','a5840dc..HEAD'])]:
    (w/name).write_bytes(subprocess.check_output(git+args))
items={}
def add(p,name=None):
    if not p.is_file():return
    if p.suffix.lower() in ['.exe','.obj','.a','.dll','.pyc'] or '__pycache__' in p.parts:return
    if 'secret.json' in p.name or p.suffix=='.ini':return
    items[name or p.relative_to(w).as_posix()]=p
for p in w.iterdir():
    if p.suffix in ['.py','.log','.txt','.json','.diff']:add(p)
for d in ['engine','architecture','features','infra','remote-test-details','remote-tests-details','remote-retry-details','local-tests-details']:
    for p in (w/d).rglob('*'):add(p)
anchors=['src/engines/podofo/PoDoFoBackend.cpp','src/engines/AutosaveManager.cpp','src/engines/PdfEditorEngine.cpp','src/engines/DocumentSession.cpp','src/engines/DocumentSession.h','src/engines/RenderCache.cpp','src/engines/SafeSave.cpp','src/GpMainWindow.cpp','src/core/Capability.cpp','src/core/PageLabels.cpp','src/core/MeasureCore.h','src/shell/controllers/HomeController.cpp','src/shell/controllers/EditController.cpp','src/shell/controllers/PagesController.cpp','src/shell/controllers/SecurityController.cpp','src/shell/controllers/FormsController.cpp','src/ui/PdfViewerWidget.cpp','src/modes/PagesMode.cpp','src/modes/BatchMode.cpp','src/modes/BatchMode.h','src/commands/CropPageCommand.h','src/commands/DeleteImageCommand.h','src/commands/ReplaceImageCommand.h','src/commands/EditFormFieldCommand.h','tools/clean_scanned_pdf.py','packaging/deploy.ps1','packaging/build-msi.ps1','packaging/build-portable.ps1','packaging/validate-release-build.ps1','packaging/check-release-defines.ps1','scripts/bootstrap-vendor-deps.sh','fuzz/run_oracles.sh','fuzz/build_clang/build_djot_clang.sh','.github/workflows/ci.yml','.github/workflows/release.yml','.github/workflows/glyphpdf-fuzz.yml','tests/TestStatusBarSlim.cpp','tests/TestBatchOpsCoverage.cpp','tests/TestHistoryIntegrity.cpp','tests/TestMeasureCore.cpp','tests/TestMeasureRoundTrip.cpp','docs/audit/CURRENT-EVIDENCE-LEDGER-2026-09-05.md','CMakeLists.txt']
for label in ['remote','local']:
    for rel in anchors:add(w/label/rel,'source-anchors/'+label+'/'+rel)
    for rel in ['CMakeCache.txt','compile_commands.json','CTestTestfile.cmake']:
        add(w/('build-'+label)/rel,'build-metadata/'+label+'/'+rel)
for name in ['QUALITY-GATE-2026-09-09.md','GLM-REPAIR-PROMPT-2026-09-09.md']:add(outputs/name,'reports/'+name)
entries=[]
archive=outputs/'quality-gate-evidence-2026-09-09.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(items.items()):
        raw=p.read_bytes();z.writestr(name,raw);entries.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
manifest={'gate':'FAIL','snapshots':json.loads((w/'manifest.json').read_text()),'published_build_steps':677,'local_release_build_steps':686,'published_first_ctest':{'passed':106,'total':116,'seconds':230.83},'published_targeted_rerun':{'passed':6,'total':8,'seconds':41.37},'local_release_ctest':{'passed':116,'total':118,'seconds':91.57},'remaining_ctest_failures':['TestBatchOpsCoverage','TestStatusBarSlim'],'extra_published_layout_failures':['TestDjotRoundtrip','TestDjotFuzz'],'release_define_gate':{'production_compilations':180,'test_compilations':250,'forbidden_production_macro':False,'app_and_engine_present':True},'exe_version':'1.3.2.3','archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'entries':entries}
(outputs/'QUALITY-GATE-VERIFICATION-2026-09-09.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
report=(outputs/'QUALITY-GATE-2026-09-09.md').read_text(encoding='utf8')
findings=re.findall(r'^### (G\d+) — (P\d)',report,re.M)
assert len(findings)==23 and len(set(x[0] for x in findings))==23
print(json.dumps({'finding_count':len(findings),'priorities':{p:sum(x[1]==p for x in findings) for p in ['P1','P2','P3']},'entries':len(entries),'archive':manifest['archive']},indent=2))
