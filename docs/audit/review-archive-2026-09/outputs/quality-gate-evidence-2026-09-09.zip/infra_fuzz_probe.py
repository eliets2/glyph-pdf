from pathlib import Path
import shutil,subprocess,os,json
w=Path(__file__).resolve().parent;s=w/'local';root=w/'infra'/'fuzz-stale-fixture';f=root/'fuzz'
for sub in ['bin','oracle','scratch']:(f/sub).mkdir(parents=True,exist_ok=True)
shutil.copyfile(s/'fuzz/run_oracles.sh',f/'run_oracles.sh')
for p in (s/'fuzz/oracle').glob('*.py'):shutil.copyfile(p,f/'oracle'/p.name)
(f/'bin/redaction_driver.exe').write_text('#!/usr/bin/env bash\necho synthetic-driver-failed >&2\nexit 9\n',newline='\n')
for name in ['case_identity','case_rot90','case_rot45','case_scale3x','case_skewx','p1_simple']:
    shutil.copyfile(w/'engine/fixtures/save-0.pdf',f/'scratch'/(name+'.pdf'))
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;C:\msys64\usr\bin;'+env.get('PATH','');env['PYTHON']='/c/Python314/python.exe'
with (w/'infra/fuzz-stale-probe.log').open('w') as log:r=subprocess.run([r'C:\msys64\usr\bin\bash.exe',str(f/'run_oracles.sh')],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=50)
(w/'infra/fuzz-stale-probe.json').write_text(json.dumps({'driver_exit':9,'campaign_exit':r.returncode,'prior_pdf_count':6,'script_unmodified':True},indent=2))
print('campaign_exit',r.returncode);print((w/'infra/fuzz-stale-probe.log').read_text(errors='replace'))
