from pathlib import Path
import subprocess,os,sys,re,json,time
w=Path(__file__).resolve().parent
label=sys.argv[1]; mode=sys.argv[2]; s=w/label;b=w/('build-'+label)
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
if mode=='build':
    args=['cmake','-S',str(s),'-B',str(b),'-G','Ninja','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
    if label=='remote':args+=['-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-g0','-DCMAKE_C_FLAGS_DEBUG=-g0']
    else:args+=['-DCMAKE_BUILD_TYPE=Release','-DGLYPHPDF_RELEASE_BUILD=ON','-DGLYPHPDF_ENABLE_LTO=ON']
    with (w/(label+'-configure.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(label,'configure',r.returncode,flush=True)
    if r.returncode:print((w/(label+'-configure.log')).read_text()[-4000:]);sys.exit(r.returncode)
    with (w/(label+'-build.log')).open('w') as log:r=subprocess.run(['cmake','--build',str(b),'--parallel','3' if label=='remote' else '2'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print(label,'build',r.returncode,flush=True);print((w/(label+'-build.log')).read_text()[-3000:]);sys.exit(r.returncode)
if mode in ('test','retry'):
    env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env['PATH']]);env['QT_QPA_PLATFORM']='offscreen'
    suffix='tests' if mode=='test' else 'retry'
    details=w/(label+'-'+suffix+'-details');details.mkdir(exist_ok=True)
    config=b/'CTestTestfile.cmake';original=config.read_text();(w/(label+'-CTestTestfile.cmake')).write_text(original)
    patched=original
    for name in re.findall(r'add_test\((Test\w+) "',original):
        patched=re.sub(r'(add_test\('+name+r' "[^"]+")',lambda m:m[0]+' "-o" "'+(details/(name+'.txt')).as_posix()+',txt"',patched)
    config.write_text(patched)
    try:
        args=['ctest','--test-dir',str(b),'--output-on-failure','-j','1']
        if mode=='retry':args+=['-R','^(SmokeTest|TestRedaction|TestBatchOcrLanguage|TestOcrPreprocessPrefs|TestBatchOpsCoverage|TestStatusBarSlim|TestExportPresets|TestOllamaProvider)$']
        with (w/(label+'-'+suffix+'.log')).open('w') as log:r=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
        print(label,suffix,r.returncode,flush=True);print((w/(label+'-'+suffix+'.log')).read_text()[-2500:])
    finally:config.write_text(original)
    out=[]
    for p in sorted(details.glob('*.txt')):
        lines=p.read_text(errors='replace').splitlines()
        for i,line in enumerate(lines):
            if any(t in line for t in ('FAIL!','SKIP','Totals:')):out.append(p.name+': '+'\n'.join(lines[i:i+(3 if 'FAIL!' in line else 1)]))
    (w/(label+'-'+suffix+'-summary.txt')).write_text('\n'.join(out),encoding='utf8')
    sys.exit(r.returncode)
