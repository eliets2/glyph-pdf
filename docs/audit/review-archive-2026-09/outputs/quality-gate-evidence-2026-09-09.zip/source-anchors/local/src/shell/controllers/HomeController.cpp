// SPDX-License-Identifier: Apache-2.0
#include "HomeController.h"
#include "shell/EditPolicy.h"
#include "core/AppContext.h"
#include "GpMainWindow.h"
#include "ui/PdfViewerWidget.h"
#include "ui/PageSetupDialog.h"
#include "ui/ExportPresetsPanel.h"
#include "engines/ConversionManager.h"
#include "engines/DocumentSession.h"   // ARC04: session clean baseline after a checked save

#ifdef Q_OS_WIN
#include <windows.h>
#include <mapi.h>
#endif

#include <QFileDialog>
#include <QMessageBox>
#include <QPushButton>
#include <QDesktopServices>
#include <QUrl>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QProcess>
#include <QInputDialog>
#include <QLineEdit>
#include <QStandardPaths>
#include <QCoreApplication>
#include <QSettings>
#include <QPrintPreviewDialog>
#include <QPrinter>
#include <QPainter>
#include <QProgressDialog>
#include <QtConcurrent/QtConcurrent>
#include <QFutureWatcher>
#include <algorithm>
#include "shell/StatusBar.h"
#include "core/interfaces/IPdfEditorEngine.h"
#include "core/interfaces/ISignatureManager.h"
#include "pdfws_djot/ProvenanceGuard.h"
#include "docmodel/ProvenanceTag.h"
#include <QUndoStack>
#include <QPdfDocument>

namespace gp {

HomeController::HomeController(const AppContext* ctx, MainWindow* mainWindow, QObject* parent)
    : QObject(parent), _ctx(ctx), _mainWindow(mainWindow) {}

// ARC07: dispatch and enablement share ONE predicate (shell/EditPolicy.h).
bool HomeController::isEnabled(ToolId id) const {
    return !EditPolicy::toolRefusedByReadOnly(
        _ctx && _ctx->document ? _ctx->document.get() : nullptr, id);
}

QList<ToolId> HomeController::handledTools() const {
    return {
        ToolId::Open, ToolId::Save, ToolId::SaveAs,
        ToolId::Print, ToolId::PrintPreview, ToolId::PageSetup,
        ToolId::ExportPresets, ToolId::Share, ToolId::Properties,
        ToolId::ImportOffice, ToolId::ImagesToPdf,
        ToolId::Undo, ToolId::Redo,
        ToolId::Watermark, ToolId::Compare
    };
}

void HomeController::activate(ToolId id) {
    switch (id) {
    case ToolId::Open: {
        QString fileName = QFileDialog::getOpenFileName(
            _mainWindow, tr("Open PDF Document"), QString(),
            tr("PDF Files (*.pdf);;All Files (*)"));
        if (!fileName.isEmpty()) {
            _mainWindow->openDocument(fileName);
        }
        break;
    }
    case ToolId::Save:
        onSave();
        break;
    case ToolId::SaveAs:
        onSaveAs();
        break;
    case ToolId::Print:
        onPrint();
        break;
    case ToolId::PrintPreview:
        onPrintPreview();
        break;
    case ToolId::PageSetup:
        onPageSetup();
        break;
    case ToolId::ExportPresets:
        onExportPresets();
        break;
    case ToolId::Share:
        onShare();
        break;
    case ToolId::Properties:
        showProperties();
        break;
    case ToolId::ImportOffice:
        onImportOffice();
        break;
    case ToolId::ImagesToPdf:
        onImagesToPdf();
        break;
    case ToolId::Undo:
        if (_ctx && _ctx->undoStack) _ctx->undoStack->undo();
        break;
    case ToolId::Redo:
        if (_ctx && _ctx->undoStack) _ctx->undoStack->redo();
        break;
    case ToolId::Watermark:
        _mainWindow->onScreenSelected(QStringLiteral("watermark"));
        break;
    case ToolId::Compare:
        _mainWindow->onScreenSelected(QStringLiteral("compare"));
        break;
    default:
        break;
    }
}

void HomeController::onSave() {
    saveNow();
}

// ARC03: the save operation with an explicit, checked result. Every guard
// refusal and every write failure is reported to the caller instead of being
// swallowed by status text — the close path decides on THIS outcome whether
// the window may go away ("save initiated" is not proof of persistence).
HomeController::SaveOutcome HomeController::saveNow() {
    auto* viewer = _mainWindow->pdfViewer();
    if (!viewer) {
        _mainWindow->statusBar()->showMessage(tr("No document is open."), 3000);
        return SaveOutcome::Canceled;   // nothing was attempted
    }
    if (!_ctx->pdfEditor) {
        _mainWindow->statusBar()->showMessage(tr("Save unavailable: PDF engine is not ready."), 5000);
        return SaveOutcome::Failed;     // guard failure — work stays open
    }
    const QString filePath = viewer->filePath();
    if (filePath.isEmpty()) {
        _mainWindow->statusBar()->showMessage(tr("Save unavailable: current tab has no file path."), 5000);
        return SaveOutcome::Failed;     // guard failure — work stays open
    }

    // ARC07: a read-only document refuses SAVE-IN-PLACE (the same policy the
    // mutation boundary enforces everywhere else); Save As remains available
    // by design. A checked refusal — the close path treats Failed as
    // "work stays open".
    if (EditPolicy::mutationBlocked(_ctx->document.get())) {
        _mainWindow->statusBar()->showMessage(EditPolicy::readOnlyMessage(), 5000);
        return SaveOutcome::Failed;
    }

    // R2-1 D1+D2: ProvenanceGuard check + signed-document routing.
    //
    // The guard (D1) enforces §6 non-negotiable:
    //   - DjotThenSave on a signed document is REFUSED (would full-rewrite,
    //     invalidating /ByteRange).  The caller must use "Save as copy".
    //   - DirectStructural on a signed document is ALLOWED and is routed
    //     through writeUpdate (D2), which performs an incremental append that
    //     preserves the existing signed byte range.
    //
    // We use the engine's hasPdfSignatures() for the routing decision to avoid
    // re-parsing the file; validateSignatures() is heavier and hits the disk.
    const bool isSigned = _ctx->pdfEditor && _ctx->pdfEditor->hasPdfSignatures();

    // AR-9 D2: derive the provenance origin from the loaded document rather than
    // hardcoding BornPDF. The save path operates on the currently-open file; its
    // origin is determined by how it was loaded. The shell only opens PDFs via
    // this controller (born-PDF), so we infer BornPDF from the .pdf source; when
    // born-Djot / born-OCR import paths are wired they will thread their true
    // origin through DocumentSession to here. Inferring (not asserting) keeps the
    // guard honest for whatever the document actually is.
    const docmodel::ProvenanceTag origin =
        filePath.endsWith(QStringLiteral(".djot"), Qt::CaseInsensitive)
            ? docmodel::ProvenanceTag::BornDjot
            : docmodel::ProvenanceTag::BornPDF;

    if (_ctx->provenanceGuard) {
        try {
            _ctx->provenanceGuard->checkEditVia(
                origin,
                isSigned,
                pdfws::EditPath::DirectStructural);
        } catch (const pdfws::ProvenanceViolation& pv) {
            QMessageBox::warning(
                _mainWindow,
                tr("Save Blocked"),
                tr("This document cannot be saved in-place: %1\n\n"
                   "Use 'Save As' to create a copy.")
                    .arg(QString::fromStdString(pv.what())));
            return SaveOutcome::Failed;   // guard refusal — work stays open
        }
    }

    // Flush the .ann sidecar cache so it stays in sync with the embedded copy.
    viewer->saveAnnotations();

    // AR-7 D1: embed annotations into the PDF object graph, not just the sidecar.
    // embedAnnotations(in, out, annots) loads the live document via resolveDocument,
    // appends annotation dictionaries to the page /Annots arrays, and calls
    // writeUpdate(out) — which persists ALL in-memory changes (structural edits
    // AND annotations) as an incremental update.  This replaces the separate
    // saveDocument / writeUpdate call below.  Signed documents benefit from the
    // same incremental-append path (writeUpdate preserves the /ByteRange).
    const bool ok = _ctx->pdfEditor->embedAnnotations(filePath, filePath, viewer->annotations());

    if (ok) {
        if (_ctx->undoStack) _ctx->undoStack->setClean();
        // ARC04: ONE session dirty policy — the clean baseline is established
        // only after a CHECKED successful save, and only for the session that
        // actually describes the persisted file (a diverged session keeps its
        // dirty state instead of silently losing unsaved work).
        if (_ctx->document && _ctx->document->path() == filePath)
            _ctx->document->setClean();
        _mainWindow->statusBar()->showMessage(tr("Document saved: %1").arg(filePath), 5000);
        return SaveOutcome::Saved;
    } else {
        // UX-14: a save failure means the user's work was NOT persisted.
        // A 5-second status bar transient is easily missed for a data-loss event.
        // Show a modal QMessageBox::critical to match the onSaveAs failure path.
        QMessageBox::critical(
            _mainWindow,
            tr("Save Failed"),
            tr("Could not save '%1'. Check that the disk is not full and the "
               "file is not write-protected.").arg(filePath));
        _mainWindow->statusBar()->showMessage(tr("Save failed: %1").arg(filePath), 5000);
        return SaveOutcome::Failed;
    }
}

void HomeController::onSaveAs() {
    auto* viewer = _mainWindow->pdfViewer();
    if (!viewer) return;
    QString fileName = QFileDialog::getSaveFileName(
        _mainWindow,
        tr("Save Document As"), QFileInfo(viewer->filePath()).fileName(),
        tr("PDF Files (*.pdf);;All Files (*)"));
    if (fileName.isEmpty()) return;

    // ER-4: warn before silently producing a file with an invalidated signature.
    // onSave() routes signed saves through writeUpdate (incremental append) to
    // preserve /ByteRange.  onSaveAs() must always do a full rewrite to the new
    // path, which shifts byte offsets and breaks every existing signature.
    // Give the user an explicit choice rather than silently delivering a broken file.
    if (_ctx->pdfEditor && _ctx->pdfEditor->hasPdfSignatures()) {
        auto choice = QMessageBox::warning(
            _mainWindow, tr("Signed Document — Save As"),
            tr("Saving as a new file will invalidate this document’s digital signature.\n\n"
               "To preserve the signature use Save (Ctrl+S) instead, which appends "
               "an incremental update.\n\n"
               "Continue and save an unsigned copy?"),
            QMessageBox::Ok | QMessageBox::Cancel, QMessageBox::Cancel);
        if (choice != QMessageBox::Ok) return;
    }

    // AR-7 D1: embed annotations directly into the output PDF so they are visible
    // in other readers.  If the engine is available, route through embedAnnotations
    // (which also copies all structural edits and annotation dicts in one call).
    // Fall back to a raw file copy for engine-less open documents.
    bool ok = false;
    if (_ctx && _ctx->pdfEditor) {
        ok = _ctx->pdfEditor->embedAnnotations(
            viewer->filePath(), fileName, viewer->annotations());
        if (ok) {
            // Also copy the .ann sidecar cache alongside the new PDF.
            const QString srcAnn = viewer->filePath() + QStringLiteral(".ann");
            const QString dstAnn = fileName + QStringLiteral(".ann");
            if (QFile::exists(srcAnn) && srcAnn != dstAnn) {
                if (QFile::exists(dstAnn)) QFile::remove(dstAnn);
                QFile::copy(srcAnn, dstAnn);
            }
        }
    } else {
        ok = viewer->saveDocumentAs(fileName);
    }

    if (ok) {
        _mainWindow->statusBar()->showMessage(tr("Document saved to %1").arg(fileName), 5000);
    } else {
        QMessageBox::warning(
            _mainWindow,
            tr("Save Failed"),
            tr("Could not save the document to '%1'. See application log for details.").arg(fileName));
        _mainWindow->statusBar()->showMessage(tr("Save failed: %1").arg(fileName), 5000);
    }
}

void HomeController::onShare() {
    auto* viewer = _mainWindow->pdfViewer();
    if (!viewer) return;

    const QString filePath = viewer->filePath();
    if (filePath.isEmpty()) {
        _mainWindow->statusBar()->showMessage(tr("No document is open."), 3000);
        return;
    }

    QMessageBox box(_mainWindow);
    box.setWindowTitle(tr("Share Document"));
    box.setIcon(QMessageBox::Question);
    box.setText(tr("How would you like to share this document?"));
    QPushButton* emailBtn = box.addButton(tr("Email attachment"), QMessageBox::AcceptRole);
    QPushButton* pkgBtn   = box.addButton(tr("Create encrypted package"), QMessageBox::ActionRole);
    box.addButton(QMessageBox::Cancel);
    box.exec();

    if (box.clickedButton() == pkgBtn) {
        createEncryptedPackage(filePath);
    } else if (box.clickedButton() == emailBtn) {
        shareViaEmail(filePath);
    }
}

void HomeController::shareViaEmail(const QString& filePath) {
    QString fileName = QFileInfo(filePath).fileName();
    QString subject = tr("PDF Document: %1").arg(fileName);
    QString body = tr("Please find the attached PDF document.");

#ifdef Q_OS_WIN
    HMODULE hMapi = LoadLibraryA("mapi32.dll");
    if (hMapi) {
        LPMAPISENDMAIL pfnSendMail = reinterpret_cast<LPMAPISENDMAIL>(reinterpret_cast<void*>(GetProcAddress(hMapi, "MAPISendMail")));
        if (pfnSendMail) {
            MapiFileDesc fileDesc;
            memset(&fileDesc, 0, sizeof(MapiFileDesc));
            fileDesc.nPosition = (ULONG)-1;
            
            QByteArray pathStr = QDir::toNativeSeparators(filePath).toLocal8Bit();
            QByteArray nameStr = fileName.toLocal8Bit();
            fileDesc.lpszPathName = pathStr.data();
            fileDesc.lpszFileName = nameStr.data();

            MapiMessage message;
            memset(&message, 0, sizeof(MapiMessage));
            
            QByteArray subjStr = subject.toLocal8Bit();
            QByteArray bodyStr = body.toLocal8Bit();
            message.lpszSubject = subjStr.data();
            message.lpszNoteText = bodyStr.data();
            message.nFileCount = 1;
            message.lpFiles = &fileDesc;

            pfnSendMail(0, reinterpret_cast<ULONG_PTR>(_mainWindow->winId()), &message, MAPI_DIALOG, 0);
        }
        FreeLibrary(hMapi);
        return;
    }
#endif

    QString url = QString("mailto:?subject=%1&body=%2").arg(subject).arg(body);
    QDesktopServices::openUrl(QUrl(url, QUrl::TolerantMode));
}

// Secure sharing (§9.11): bundle the PDF into an AES-256 encrypted ZIP using a
// 7-Zip executable (PATH, common install dirs, or bundled next to the app).
void HomeController::createEncryptedPackage(const QString& filePath) {
    QString sevenZip = QStandardPaths::findExecutable(QStringLiteral("7z"));
    if (sevenZip.isEmpty()) {
        const QStringList candidates = {
            QStringLiteral("C:/Program Files/7-Zip/7z.exe"),
            QStringLiteral("C:/Program Files (x86)/7-Zip/7z.exe"),
            QCoreApplication::applicationDirPath() + QStringLiteral("/7z.exe"),
        };
        for (const QString& c : candidates)
            if (QFileInfo::exists(c)) { sevenZip = c; break; }
    }
    if (sevenZip.isEmpty()) {
        QMessageBox::warning(_mainWindow, tr("Encrypted Package"),
            tr("7-Zip (7z.exe) was not found. Install 7-Zip to create AES-256 "
               "encrypted packages, or use Protect \xE2\x96\xB8 Encrypt to password-protect "
               "the PDF directly."));
        return;
    }

    bool ok = false;
    const QString password = QInputDialog::getText(_mainWindow, tr("Encrypted Package"),
        tr("Package password:"), QLineEdit::Password, QString(), &ok);
    if (!ok || password.isEmpty()) return;

    QString outPath = QFileDialog::getSaveFileName(_mainWindow,
        tr("Save Encrypted Package"),
        QFileInfo(filePath).completeBaseName() + QStringLiteral(".zip"),
        tr("Encrypted ZIP (*.zip)"));
    if (outPath.isEmpty()) return;
    if (!outPath.endsWith(QLatin1String(".zip"), Qt::CaseInsensitive))
        outPath += QStringLiteral(".zip");
    QFile::remove(outPath);  // 7z appends to an existing archive — start fresh

    // 7z a -tzip -mem=AES256 -p<pwd> <out.zip> <pdf>
    QStringList args;
    args << QStringLiteral("a") << QStringLiteral("-tzip")
         << QStringLiteral("-mem=AES256")
         << (QStringLiteral("-p") + password)
         << QDir::toNativeSeparators(outPath)
         << QDir::toNativeSeparators(filePath);

    // P8: run 7-Zip off the GUI thread. The previous proc.waitForFinished(-1)
    // blocked the event loop for the entire (unbounded) packaging time, freezing
    // the UI. Mirror the QFutureWatcher + QProgressDialog pattern used by the
    // Office/Images converters below. The QProcess lives entirely inside the
    // worker; only a small result struct crosses back to the GUI thread.
    struct PackResult { bool launched = false; bool ok = false; int exitCode = 0; };

    auto* progress = new QProgressDialog(
        tr("Creating encrypted package…"), QString(), 0, 0, _mainWindow);
    progress->setWindowModality(Qt::WindowModal);
    progress->setMinimumDuration(500);

    auto* watcher = new QFutureWatcher<PackResult>(_mainWindow);
    QObject::connect(watcher, &QFutureWatcher<PackResult>::finished, _mainWindow, [=]() {
        progress->close();
        progress->deleteLater();
        const PackResult r = watcher->result();
        watcher->deleteLater();

        if (!r.launched) {
            QMessageBox::warning(_mainWindow, tr("Encrypted Package"),
                tr("Could not launch 7-Zip."));
            return;
        }
        if (r.ok && QFileInfo::exists(outPath)) {
            _mainWindow->statusBar()->showMessage(
                tr("Encrypted package created: %1").arg(QFileInfo(outPath).fileName()), 5000);
            QMessageBox::information(_mainWindow, tr("Encrypted Package"),
                tr("AES-256 encrypted package created:\n%1").arg(outPath));
        } else {
            QMessageBox::warning(_mainWindow, tr("Encrypted Package"),
                tr("7-Zip failed to create the package (exit code %1).").arg(r.exitCode));
        }
    });

    watcher->setFuture(QtConcurrent::run([sevenZip, args]() -> PackResult {
        PackResult r;
        QProcess proc;
        proc.start(sevenZip, args);
        if (!proc.waitForStarted(5000)) {
            return r;  // launched == false
        }
        r.launched = true;
        proc.waitForFinished(-1);
        r.exitCode = proc.exitCode();
        r.ok = (proc.exitStatus() == QProcess::NormalExit && proc.exitCode() == 0);
        return r;
    }));
    progress->show();
}

void HomeController::onPrint() {
    auto* viewer = _mainWindow->pdfViewer();
    if (viewer) {
        viewer->printDocument();
    } else {
        _mainWindow->statusBar()->showMessage(tr("No document is open."), 3000);
    }
}

void HomeController::showProperties() {
    auto* viewer = _mainWindow->pdfViewer();
    if (!viewer || !viewer->document()) return;
    auto* doc = viewer->document();

    QString title = doc->metaData(QPdfDocument::MetaDataField::Title).toString();
    QString author = doc->metaData(QPdfDocument::MetaDataField::Author).toString();
    QString subject = doc->metaData(QPdfDocument::MetaDataField::Subject).toString();
    QString keywords = doc->metaData(QPdfDocument::MetaDataField::Keywords).toString();
    QString creator = doc->metaData(QPdfDocument::MetaDataField::Creator).toString();
    QString producer = doc->metaData(QPdfDocument::MetaDataField::Producer).toString();

    QString info = tr("<b>Title:</b> %1<br>"
                      "<b>Author:</b> %2<br>"
                      "<b>Subject:</b> %3<br>"
                      "<b>Keywords:</b> %4<br>"
                      "<b>Creator:</b> %5<br>"
                      "<b>Producer:</b> %6<br>"
                      "<b>Page Count:</b> %7")
                      .arg(title.isEmpty() ? tr("[None]") : title)
                      .arg(author.isEmpty() ? tr("[None]") : author)
                      .arg(subject.isEmpty() ? tr("[None]") : subject)
                      .arg(keywords.isEmpty() ? tr("[None]") : keywords)
                      .arg(creator.isEmpty() ? tr("[None]") : creator)
                      .arg(producer.isEmpty() ? tr("[None]") : producer)
                      .arg(doc->pageCount());

    QMessageBox::information(_mainWindow, tr("Document Properties"), info);
}

void HomeController::onPrintPreview() {
    auto* viewer = _mainWindow->pdfViewer();
    if (!viewer || !viewer->document()) {
        _mainWindow->statusBar()->showMessage(tr("No document is open."), 3000);
        return;
    }

    QPrinter printer(QPrinter::HighResolution);
    QString filePath = viewer->filePath();
    auto ps = PageSetupDialog::loadForDocument(filePath);
    printer.setPageSize(QPageSize(ps.pageSize));
    printer.setPageOrientation(ps.orientation == QPageLayout::Landscape
                                   ? QPageLayout::Landscape : QPageLayout::Portrait);
    printer.setPageMargins(QMarginsF(ps.marginLeft, ps.marginTop,
                                     ps.marginRight, ps.marginBottom), QPageLayout::Millimeter);
    Q_UNUSED(ps);  // Settings applied to printer above; render uses fixed 150 DPI

    QPrintPreviewDialog preview(&printer, _mainWindow);
    preview.setWindowTitle(tr("Print Preview"));

    QPdfDocument* doc = viewer->document();
    connect(&preview, &QPrintPreviewDialog::paintRequested, _mainWindow,
        [doc](QPrinter* p) {
            if (!doc || doc->pageCount() == 0) return;

            QPainter painter(p);
            QRectF printable = p->pageRect(QPrinter::DevicePixel);
            constexpr int renderDpi = 150;

            for (int i = 0; i < doc->pageCount(); ++i) {
                if (i > 0) p->newPage();

                QSizeF pageSize = doc->pagePointSize(i);
                QImage img = doc->render(i, (pageSize * renderDpi / 72.0).toSize());
                if (img.isNull()) continue;

                // Scale to fit printable area
                QSizeF scaled = img.size().scaled(printable.size().toSize(), Qt::KeepAspectRatio);
                double x = (printable.width()  - scaled.width())  / 2.0;
                double y = (printable.height() - scaled.height()) / 2.0;
                painter.drawImage(QRectF(x, y, scaled.width(), scaled.height()), img);
            }
            painter.end();
        });

    preview.exec();
}

void HomeController::onPageSetup() {
    auto* viewer = _mainWindow->pdfViewer();
    QString path = viewer ? viewer->filePath() : QString();
    PageSetupDialog dlg(path, _mainWindow);
    dlg.exec();
}

void HomeController::onExportPresets() {
    ExportPresetsPanel panel(_mainWindow);
    // §9.16 P0: actually execute the chosen preset instead of emitting into
    // the void. Linearized → qpdf-backed linearizeDocument; PDF/A →
    // exportPdfA; both operate on a Save-As copy of the open document.
    // planForExport() (pure, unit-tested) maps the preset onto the steps.
    connect(&panel, &ExportPresetsPanel::presetSelected, this,
            [this](const ExportPresetsPanel::Preset& p) {
        auto* viewer = _mainWindow->pdfViewer();
        if (!viewer || !_ctx || !_ctx->pdfEditor) return;
        if (viewer->filePath().isEmpty()) {
            QMessageBox::information(_mainWindow, tr("Export Preset"),
                tr("No document is open."));
            return;
        }
        const QString base = QFileInfo(viewer->filePath()).completeBaseName();
        const QString outPath = QFileDialog::getSaveFileName(
            _mainWindow, tr("Save Preset Export"),
            QFileInfo(viewer->filePath()).absolutePath() + QLatin1Char('/') + base + "_export.pdf",
            tr("PDF Files (*.pdf)"));
        if (outPath.isEmpty()) return;
        if (!viewer->saveDocumentAs(outPath)) {
            QMessageBox::critical(_mainWindow, tr("Export Preset"),
                tr("Could not write %1").arg(outPath));
            return;
        }
        // Reload the exported copy so engine operations target it.
        _ctx->pdfEditor->loadDocumentForEditing(outPath);
        const ExportPlan plan = planForExport(p);
        QStringList applied;
        if (plan.linearize && _ctx->pdfEditor->linearizeDocument(outPath))
            applied << tr("linearized");
        if (plan.pdfALevel > 0) {
            if (_ctx->pdfEditor->exportPdfA(outPath, plan.pdfALevel))
                applied << QStringLiteral("PDF/A-%1b").arg(plan.pdfALevel);
        }
        if (applied.isEmpty())
            applied << tr("plain copy (no post-processing options enabled)");
        _mainWindow->statusBar()->showMessage(
            tr("Preset '%1' exported to %2 — %3")
                .arg(p.name, outPath, applied.join(tr(", "))), 8000);
    });
    panel.exec();
}

// §9.16: single source of truth for preset → post-processing mapping.
// "2b"/"3b" style levels map to the engine's conformance-level int; anything
// else (including an empty level) falls back to 2b, matching the previous
// inline default.
HomeController::ExportPlan
HomeController::planForExport(const ExportPresetsPanel::Preset& p) {
    ExportPlan plan;
    plan.linearize = p.linearized;
    if (p.pdfA) {
        plan.pdfALevel = p.pdfALevel.startsWith(QLatin1Char('3')) ? 3 : 2;
    }
    return plan;
}

// ── Recent files ────────────────────────────────────────────────────────

void HomeController::addRecentFile(const QString& filePath) {
    if (filePath.isEmpty()) return;
    QSettings settings;
    QStringList recent = settings.value("recentFiles").toStringList();
    recent.removeAll(filePath);
    recent.prepend(filePath);
    while (recent.size() > 20)
        recent.removeLast();
    settings.setValue("recentFiles", recent);
}

QStringList HomeController::recentFiles() const {
    QSettings settings;
    return settings.value("recentFiles").toStringList();
}

void HomeController::removeFromRecents(const QString& filePath) {
    if (filePath.isEmpty()) return;
    QSettings settings;
    QStringList recent = settings.value("recentFiles").toStringList();
    recent.removeAll(filePath);
    settings.setValue("recentFiles", recent);
}

int HomeController::pruneMissingRecents() {
    QSettings settings;
    QStringList recent = settings.value("recentFiles").toStringList();
    const QStringList before = recent;
    recent.erase(
        std::remove_if(recent.begin(), recent.end(),
                       [](const QString& p) { return !QFileInfo::exists(p); }),
        recent.end());
    const int removed = before.size() - recent.size();
    if (removed > 0)
        settings.setValue("recentFiles", recent);
    return removed;
}

void HomeController::onImportOffice()
{
    // Runtime detection — works with whatever the user has installed (LibreOffice on
    // the PATH, in Program Files, or recorded in the registry), independent of what
    // the build machine had. No converter is bundled; we use the one already present.
    if (!ConversionManager::isOfficeImportAvailable()) {
        QMessageBox box(_mainWindow);
        box.setIcon(QMessageBox::Information);
        box.setWindowTitle(tr("Office Import Needs a Converter"));
        box.setText(tr("Importing Word, Excel and PowerPoint files to PDF uses "
                       "LibreOffice, which doesn't appear to be installed."));
        box.setInformativeText(tr("LibreOffice is free and open source. Install it once, "
                                  "then this feature works automatically — no GlyphPDF "
                                  "restart required."));
        QPushButton *download = box.addButton(tr("Download LibreOffice…"), QMessageBox::AcceptRole);
        box.addButton(QMessageBox::Cancel);
        box.setDefaultButton(download);
        box.exec();
        if (box.clickedButton() == download)
            QDesktopServices::openUrl(QUrl("https://www.libreoffice.org/download/download/"));
        return;
    }

    const QString officePath = QFileDialog::getOpenFileName(
        _mainWindow,
        tr("Import Office Document"),
        QString(),
        tr("Office Documents (*.docx *.doc *.xlsx *.xls *.pptx *.ppt *.odt *.ods *.odp *.rtf *.csv *.txt)"
           ";;All Files (*)"));
    if (officePath.isEmpty())
        return;

    const QString outputPath = QFileDialog::getSaveFileName(
        _mainWindow,
        tr("Save as PDF"),
        QFileInfo(officePath).completeBaseName() + ".pdf",
        tr("PDF Files (*.pdf)"));
    if (outputPath.isEmpty())
        return;

    auto* progress = new QProgressDialog(
        tr("Converting %1 to PDF…").arg(QFileInfo(officePath).fileName()),
        tr("Cancel"), 0, 0, _mainWindow);
    progress->setWindowModality(Qt::WindowModal);
    progress->setMinimumDuration(500);

    auto* watcher = new QFutureWatcher<bool>(_mainWindow);
    QObject::connect(progress, &QProgressDialog::canceled, watcher, &QFutureWatcher<bool>::cancel);
    QObject::connect(watcher, &QFutureWatcher<bool>::finished, _mainWindow, [=]() {
        progress->close();
        progress->deleteLater();
        if (watcher->isCanceled()) {
            watcher->deleteLater();
            return;
        }
        const bool ok = watcher->result();
        watcher->deleteLater();
        if (ok) {
            _mainWindow->statusBar()->showMessage(
                tr("Converted to PDF: %1").arg(outputPath), 6000);
            _mainWindow->openDocument(outputPath);
        } else {
            QMessageBox::warning(
                _mainWindow,
                tr("Conversion Failed"),
                tr("Could not convert '%1' to PDF.\n"
                   "Ensure LibreOffice is installed and the file is not password-protected.")
                    .arg(QFileInfo(officePath).fileName()));
        }
    });

    watcher->setFuture(QtConcurrent::run([officePath, outputPath]() {
        ConversionManager mgr;
        return mgr.convertOfficeToPdf(officePath, outputPath);
    }));
    progress->show();
}

void HomeController::onImagesToPdf()
{
    const QStringList imagePaths = QFileDialog::getOpenFileNames(
        _mainWindow,
        tr("Select Images"),
        QString(),
        tr("Images (*.png *.jpg *.jpeg *.tif *.tiff *.bmp);;All Files (*)"));
    if (imagePaths.isEmpty())
        return;

    const QString outputPath = QFileDialog::getSaveFileName(
        _mainWindow,
        tr("Save as PDF"),
        "images.pdf",
        tr("PDF Files (*.pdf)"));
    if (outputPath.isEmpty())
        return;

    auto* progress = new QProgressDialog(
        tr("Building PDF from %1 image(s)…").arg(imagePaths.size()),
        tr("Cancel"), 0, 0, _mainWindow);
    progress->setWindowModality(Qt::WindowModal);
    progress->setMinimumDuration(300);

    auto* watcher = new QFutureWatcher<bool>(_mainWindow);
    QObject::connect(progress, &QProgressDialog::canceled, watcher, &QFutureWatcher<bool>::cancel);
    QObject::connect(watcher, &QFutureWatcher<bool>::finished, _mainWindow, [=]() {
        progress->close();
        progress->deleteLater();
        if (watcher->isCanceled()) {
            watcher->deleteLater();
            return;
        }
        const bool ok = watcher->result();
        watcher->deleteLater();
        if (ok) {
            _mainWindow->statusBar()->showMessage(
                tr("Images combined into PDF: %1").arg(outputPath), 6000);
            _mainWindow->openDocument(outputPath);
        } else {
            QMessageBox::warning(
                _mainWindow,
                tr("Conversion Failed"),
                tr("Could not combine images into a PDF.\n"
                   "Ensure all selected files are valid image files."));
        }
    });

    watcher->setFuture(QtConcurrent::run([imagePaths, outputPath]() {
        ConversionManager mgr;
        return mgr.convertImagesToPdf(imagePaths, outputPath);
    }));
    progress->show();
}

} // namespace gp
