// SPDX-License-Identifier: Apache-2.0
#include "engines/AutosaveManager.h"
#include "engines/DocumentSession.h"
#include "core/interfaces/IPdfEditorEngine.h"
#include <QSettings>
#include <QDebug>
#include <QThread>
#include <QFile>
#include <QtConcurrent/QtConcurrent>
#include <QFutureWatcher>
#include <QPointer>

#ifdef _WIN32
#include <windows.h>
#endif

static bool atomicRename(const QString &from, const QString &to)
{
#ifdef _WIN32
    std::wstring fromW = from.toStdWString();
    std::wstring toW = to.toStdWString();
    return MoveFileExW(fromW.c_str(), toW.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
#else
    if (QFile::exists(to)) {
        QFile::remove(to);
    }
    return QFile::rename(from, to);
#endif
}

AutosaveManager::AutosaveManager(std::shared_ptr<IPdfEditorEngine> pdfEditor, std::shared_ptr<DocumentSession> document, QObject* parent)
    : QObject(parent)
    , m_pdfEditor(std::move(pdfEditor))
    , m_document(std::move(document))
    , m_timer(new QTimer(this))
{
    connect(m_timer, &QTimer::timeout, this, &AutosaveManager::onTick);

    // Read initial interval from settings
    QSettings settings;
    int savedInterval = settings.value("autosave/intervalSeconds", 300).toInt();
    // Clamp [60, 1800]
    if (savedInterval < 60) savedInterval = 60;
    if (savedInterval > 1800) savedInterval = 1800;
    m_intervalSeconds = savedInterval;
}

AutosaveManager::~AutosaveManager()
{
    stop();
}

void AutosaveManager::start(int intervalSeconds)
{
    if (intervalSeconds < 60) intervalSeconds = 60;
    if (intervalSeconds > 1800) intervalSeconds = 1800;
    
    m_intervalSeconds = intervalSeconds;
    m_timer->start(m_intervalSeconds * 1000);
}

void AutosaveManager::stop()
{
    m_timer->stop();
}

bool AutosaveManager::isActive() const
{
    return m_timer->isActive();
}

int AutosaveManager::interval() const
{
    return m_intervalSeconds;
}

void AutosaveManager::onTick()
{
    if (m_saving) return;

    if (!m_document || !m_pdfEditor) return;
    if (!m_document->isDirty()) return;

    // EC02: capture the identity this autosave run belongs to — the editor's
    // resident document AND the session's document generation. Everything
    // below (worker paths, rename, timestamp) is validated against this
    // capture, so a document switch that lands while the queued save is
    // pending can never write B's bytes into A's recovery file or timestamp
    // B's session for A's work.
    const QString capturedFile = m_pdfEditor->currentFile();
    if (capturedFile.isEmpty()) return;
    const qint64 capturedGeneration = m_document->documentGeneration();

    m_saving = true;
    emit autosaveStarted();

    QString tmpAutosavePath = capturedFile + ".autosave.pdf.tmp";
    QString finalAutosavePath = capturedFile + ".autosave.pdf";

    std::weak_ptr<IPdfEditorEngine> weakEditor = m_pdfEditor;

    // EC02 worker outcome: identity-guarded save classification.
    enum SaveOutcome { SaveFailed = 0, SaveOk = 1, SaveStale = 2 };

    auto watcher = new QFutureWatcher<int>(this);
    connect(watcher, &QFutureWatcher<int>::finished, this, [this, watcher, capturedFile, capturedGeneration, tmpAutosavePath, finalAutosavePath]() {
        const int result = watcher->result();
        watcher->deleteLater();

        // EC02: the completion may land after a session switch. Identity
        // matching means BOTH the path and the generation captured at tick
        // time — a same-path reopen (A→A) is a new session for which the old
        // run's completion must not claim an autosave.
        const bool sessionMatches = m_document
            && m_document->path() == capturedFile
            && m_document->documentGeneration() == capturedGeneration;

        if (result == SaveOk) {
            bool renameOk = atomicRename(tmpAutosavePath, finalAutosavePath);
            if (renameOk) {
                QDateTime now = QDateTime::currentDateTime();
                if (sessionMatches && m_document) {
                    m_document->setLastAutosave(now);
                }
                emit autosaveCompleted(now);
            } else {
                // Retry once after 250ms asynchronously
                QPointer<AutosaveManager> weakThis(this);
                QTimer::singleShot(250, [weakThis, capturedFile, capturedGeneration, tmpAutosavePath, finalAutosavePath]() {
                    if (!weakThis) return;
                    bool retryOk = atomicRename(tmpAutosavePath, finalAutosavePath);
                    if (retryOk) {
                        QDateTime now = QDateTime::currentDateTime();
                        if (weakThis->m_document
                            && weakThis->m_document->path() == capturedFile
                            && weakThis->m_document->documentGeneration() == capturedGeneration) {
                            weakThis->m_document->setLastAutosave(now);
                        }
                        emit weakThis->autosaveCompleted(now);
                    } else {
                        qWarning() << "Autosave failed: atomic rename failed from" << tmpAutosavePath << "to" << finalAutosavePath;
                        emit weakThis->autosaveFailed("Failed to rename temporary autosave file");
                    }
                    weakThis->m_saving = false;
                });
                return; // Return early, m_saving = false will be handled in the timer
            }
        } else if (result == SaveStale) {
            // EC02: the resident document changed between capture and save —
            // the engine refused WITHOUT writing. Clear any leftover temp and
            // terminate with a clear stale outcome; neither session is
            // timestamped and the captured document's recovery file is
            // untouched.
            QFile::remove(tmpAutosavePath);
            emit autosaveStale(capturedFile);
        } else {
            qWarning() << "Autosave failed during document save";
            emit autosaveFailed("Failed to save temporary document");
        }
        m_saving = false;
    });

    QFuture<int> future = QtConcurrent::run([weakEditor, capturedFile, tmpAutosavePath]() -> int {
        auto editor = weakEditor.lock();
        if (!editor) return SaveFailed;
        try {
            // EC02: identity-guarded save — the engine checks under its
            // serialization lock that the document it holds is still the one
            // captured for this run, so a switch cannot be serialized into
            // the captured path. A `false` with a changed resident document
            // is a stale run, not a save failure.
            if (!editor->saveDocumentIfCurrent(capturedFile, tmpAutosavePath)) {
                return editor->currentFile() == capturedFile ? SaveFailed : SaveStale;
            }
            return SaveOk;
        } catch (const std::exception &e) {
            qWarning("Autosave failed: %s", e.what());
            return SaveFailed;
        } catch (...) {
            qWarning("Autosave failed with unknown exception");
            return SaveFailed;
        }
    });
    watcher->setFuture(future);
}
