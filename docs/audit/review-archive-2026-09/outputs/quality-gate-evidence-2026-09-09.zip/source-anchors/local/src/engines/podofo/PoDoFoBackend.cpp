// SPDX-License-Identifier: Apache-2.0
#include "engines/podofo/PoDoFoBackend.h"
#include "engines/SafeSave.h"
#include "core/MeasureCore.h"
#include <memory>
#include "PdfStringEscape.h"
#include "GlyphAdvanceCalculator.h"
#include "pdfws_djot/DjotToRichTextXhtml.h"
#include <QDebug>
#include <QTemporaryFile>
#include <QFileInfo>
#include <QFile>
#include <QDir>
#include <QRecursiveMutex>
#include <QMutexLocker>
#include <podofo/podofo.h>
#include <podofo/auxiliary/StreamDevice.h>
#include <cmath>
#include <sstream>
#include <algorithm>
#include <utility>
#include <QMap>
#include <set>
#include <QDateTime>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QCryptographicHash>
#include <QRandomGenerator>
#include <QStandardPaths>
#include <QBuffer>
#include <QImageWriter>
#include <cstdlib>
#include <unordered_map>


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifdef HAS_QPDF
#include <qpdf/qpdf-c.h>
#endif

namespace {

// RAII removal of this operation's candidate file on every path (same idiom
// as the FormManager R01 transaction).
class CandidateFileGuard {
public:
    explicit CandidateFileGuard(const QString& path) : m_path(path) {}
    ~CandidateFileGuard() { if (!m_path.isEmpty()) QFile::remove(m_path); }
    CandidateFileGuard(const CandidateFileGuard&) = delete;
    CandidateFileGuard& operator=(const CandidateFileGuard&) = delete;
private:
    QString m_path;
};

PoDoFo::PdfObject* ensurePageResources(PoDoFo::PdfPage& page)
{
    auto* resDict = page.GetDictionary().FindKey("Resources");
    if (!resDict) {
        page.GetDictionary().AddKey("Resources", PoDoFo::PdfDictionary());
        resDict = page.GetDictionary().FindKey("Resources");
    }
    return resDict;
}

void ensureStandardFontResource(PoDoFo::PdfMemDocument& doc,
                                PoDoFo::PdfPage& page,
                                const std::string& resourceName,
                                const std::string& baseFontName)
{
    auto* resDict = ensurePageResources(page);
    auto* fontDict = resDict->GetDictionary().FindKey("Font");
    if (!fontDict) {
        resDict->GetDictionary().AddKey("Font", PoDoFo::PdfDictionary());
        fontDict = resDict->GetDictionary().FindKey("Font");
    }
    if (fontDict->GetDictionary().HasKey(resourceName))
        return;

    auto& fontObj = doc.GetObjects().CreateDictionaryObject();
    fontObj.GetDictionary().AddKey("Type", PoDoFo::PdfName("Font"));
    fontObj.GetDictionary().AddKey("Subtype", PoDoFo::PdfName("Type1"));
    fontObj.GetDictionary().AddKey("BaseFont", PoDoFo::PdfName(baseFontName));
    fontDict->GetDictionary().AddKeyIndirect(resourceName, fontObj);
}

void appendPageContent(PoDoFo::PdfMemDocument& doc, PoDoFo::PdfPage& page, const std::string& content)
{
    Q_UNUSED(doc)
    auto& contents = page.GetOrCreateContents();
    auto& stream = contents.CreateStreamForAppending();
    stream.SetData(PoDoFo::bufferview(content.data(), content.size()));
}

std::pair<double, double> textPositionFor(const PoDoFo::Rect& mediaBox,
                                          HeaderFooterOptions::Position position,
                                          double textWidth,
                                          int fontSize)
{
    double x = 0;
    double y = 0;
    constexpr double margin = 36.0;

    switch (position) {
        case HeaderFooterOptions::Position::TopLeft:
            x = mediaBox.X + margin;
            y = mediaBox.Y + mediaBox.Height - margin - fontSize;
            break;
        case HeaderFooterOptions::Position::TopCenter:
            x = mediaBox.X + (mediaBox.Width - textWidth) / 2.0;
            y = mediaBox.Y + mediaBox.Height - margin - fontSize;
            break;
        case HeaderFooterOptions::Position::TopRight:
            x = mediaBox.X + mediaBox.Width - margin - textWidth;
            y = mediaBox.Y + mediaBox.Height - margin - fontSize;
            break;
        case HeaderFooterOptions::Position::BottomLeft:
            x = mediaBox.X + margin;
            y = mediaBox.Y + margin;
            break;
        case HeaderFooterOptions::Position::BottomCenter:
            x = mediaBox.X + (mediaBox.Width - textWidth) / 2.0;
            y = mediaBox.Y + margin;
            break;
        case HeaderFooterOptions::Position::BottomRight:
            x = mediaBox.X + mediaBox.Width - margin - textWidth;
            y = mediaBox.Y + margin;
            break;
    }

    return {x, y};
}

void appendEscapedText(PoDoFo::PdfMemDocument& doc,
                       PoDoFo::PdfPage& page,
                       const QString& text,
                       HeaderFooterOptions::Position position,
                       int fontSize,
                       const std::string& baseFontName)
{
    constexpr const char* resourceName = "PDFWS_HF";
    ensureStandardFontResource(doc, page, resourceName, baseFontName);

    const PoDoFo::PdfFont* font = doc.GetFonts().SearchFont(baseFontName);
    if (!font) {
        font = &doc.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
    }

    PoDoFo::PdfTextState textState;
    textState.Font = font;
    textState.FontSize = fontSize;
    const QByteArray utf8 = text.toUtf8();
    double textWidth = font->GetStringLength(utf8.constData(), textState);
    const auto [x, y] = textPositionFor(page.GetMediaBox(), position, textWidth, fontSize);

    std::ostringstream stream;
    stream << "q\nBT\n/" << resourceName << " " << fontSize << " Tf\n";
    stream << "1 0 0 1 " << x << " " << y << " Tm\n";
    stream << "(" << pdfEscapeLiteralString(text) << ") Tj\n";
    stream << "ET\nQ\n";
    appendPageContent(doc, page, stream.str());
}

} // namespace

class PoDoFoBackend::Private {
public:
    std::unique_ptr<PoDoFo::PdfMemDocument> document;
    std::unique_ptr<PoDoFo::PdfMemDocument> tempDocument;
    QString currentFile;
    mutable QRecursiveMutex mutex;
    QList<PdfImageInfo> lastListedImages;
    // EC01 re-seat: the re-seated resident document parses lazily FROM the
    // candidate byte buffer (PdfMemDocument::LoadFromBuffer keeps a reference,
    // it does not copy), so the buffer must live as long as the document.
    // Owned here — a stack-local QByteArray died at the end of the saving
    // call and left the resident document parsing freed memory.
    QByteArray reseatBuffer;

    PoDoFo::PdfMemDocument& resolveDocument(const QString& path) {
        // Already the loaded document (possibly with unsaved in-memory edits) — operate on it.
        if (document && currentFile == path) {
            return *document;
        }
        // AR-4 D2 security guard: never silently load a SECOND, divergent copy from disk
        // while a different document is already in memory — that would discard the edited
        // doc and save the stale on-disk bytes instead. Refuse loudly.
        if (document && !currentFile.isEmpty()) {
            throw std::runtime_error(
                "SECURITY: refusing to mutate '" + path.toStdString() +
                "' while a different document ('" + currentFile.toStdString() + "') is loaded");
        }
        // Nothing loaded yet — lazy-load the requested path. The path-based mutator API
        // (addHeaderFooter/applyBatesNumbering/cropPage/…) is contractually a
        // load→mutate→save over `path`; honour that when no document is resident.
        auto newDoc = std::make_unique<PoDoFo::PdfMemDocument>();
        newDoc->Load(path.toUtf8().constData());
        document = std::move(newDoc);
        currentFile = path;
        return *document;
    }

    PdfImageInfo* findImageByName(int pageIndex, const QString& xobjectName, PoDoFoBackend* parent) {
        lastListedImages = parent->listImages(pageIndex);
        for (auto& img : lastListedImages) {
            if (img.xobjectName == xobjectName) {
                return &img;
            }
        }
        return nullptr;
    }
};

PoDoFoBackend::PoDoFoBackend() : d(std::make_unique<Private>()) {}

PoDoFoBackend::~PoDoFoBackend() = default;

bool PoDoFoBackend::loadDocument(const QString &path) {
    QMutexLocker locker(&d->mutex);
    auto newDoc = std::make_unique<PoDoFo::PdfMemDocument>();
    try {
        newDoc->Load(path.toUtf8().constData());
        if (newDoc->GetPages().GetCount() > 10000) {
            qCritical() << "SECURITY: Rejected document exceeding max page limit of 10,000 pages.";
            return false;
        }
        d->document = std::move(newDoc);
        d->currentFile = path;
        d->reseatBuffer.clear();   // file-backed document: no re-seat buffer pinned
        return true;
    } catch (const PoDoFo::PdfError& e) {
        // E-05/E-18: log unconditionally (not only in Debug). In a Release build the
        // bare boolean return left zero diagnostic for "why did this PDF fail to
        // load?" — including on the recovery-load entry point.
        qWarning() << "PoDoFoBackend::loadDocument failed:" << e.what() << "path:" << path;
        return false;
    }
}

bool PoDoFoBackend::saveDocument(const QString &path) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    // ── Encrypted documents: separate contract (like the signed incremental
    // path). PoDoFo re-serializes them with the in-memory encrypt object, and
    // the result cannot be reopened for candidate validation without the
    // loading password (not exposed by PdfMemDocument), nor be re-seated via
    // LoadFromBuffer. These documents are parsed eagerly (no deferred object
    // streams), so the EC01 same-path truncation does not reproduce here —
    // preserve the exact pre-EC01 direct-save semantics for them. Residual:
    // an encrypted document WITH deferred object streams could still truncate
    // on a same-path save; the reviewed EC01 repro is the ordinary document.
    if (d->document->IsEncrypted()) {
        try {
            d->document->Save(path.toUtf8().constData());
        } catch (const PoDoFo::PdfError& e) {
            qCritical() << "PoDoFoBackend::saveDocument (encrypted) failed:"
                        << e.what() << "path:" << path;
            return false;
        }
        return true;
    }

    // ── EC01 (P1): candidate → validate → checked commit at the shared save
    // boundary (R01/U05 SafeSave pattern; TEAM-ENGINE-CODE-REVIEW-2026-09-07).
    //
    // A loaded PdfMemDocument keeps its source device open for deferred object
    // parsing (PdfMemDocument::m_device). The old code handed `path` straight
    // to Save(), so a save to the loaded source path truncated the very file
    // the parser was still reading ("InvalidNumber — Object and generation
    // number cannot be read"): a valid two-page PDF became ZERO bytes and the
    // operation returned failure. Every path-based mutator funnels through
    // here (PdfEditorEngine::saveDocument, unsigned writeUpdate ← rotatePage /
    // cropPage / reorder / …), so the transaction lives at this one choke
    // point:
    //   1. serialize the COMPLETE in-memory document to a unique temp
    //      candidate (never the destination — no fragile path-equality
    //      checks),
    //   2. reopen the candidate and validate it: readable PDF with an
    //      unchanged page count,
    //   3. for a same-file save, re-seat the resident document from the
    //      validated candidate BYTES (in-memory buffer) BEFORE the commit —
    //      this closes the device the old document held on the file about to
    //      be replaced so the atomic rename can succeed, and on any later
    //      failure the edit state stays resident and recoverable while no
    //      handle pins the candidate,
    //   4. commit the validated bytes through SafeSave::commitFileToDestination
    //      (bounded copy into QSaveFile + checked commit) — the original is
    //      never deleted before the atomic rename, and a blocked replacement
    //      (open handle, full disk) fails with the original byte-identical.
    //      There is deliberately NO direct-write fallback.
    //   5. the re-seated document is byte-identical to the committed
    //      destination, so the backend is left backed by exactly the committed
    //      document and every candidate file is removable on every path.
    // Signed documents keep their separate writeUpdate (SaveUpdate) incremental
    // contract — they never route through this unsigned full rewrite.
    QString candidate;
    QString err;
    if (!gp::SafeSave::makeUniqueCandidate(&candidate, &err)) {
        qCritical() << "PoDoFoBackend::saveDocument:" << err << "path:" << path;
        return false;
    }
    CandidateFileGuard candidateGuard(candidate);

    const unsigned sourcePageCount = d->document->GetPages().GetCount();
    try {
        d->document->Save(candidate.toUtf8().constData());
    } catch (const PoDoFo::PdfError& e) {
        // E-05: security/IO-critical boundary — log unconditionally.
        qCritical() << "PoDoFoBackend::saveDocument: candidate serialization failed:"
                    << e.what() << "path:" << path;
        return false;
    }

    try {
        PoDoFo::PdfMemDocument reopened;
        reopened.Load(candidate.toUtf8().constData());
        if (reopened.GetPages().GetCount() != sourcePageCount) {
            qCritical() << "PoDoFoBackend::saveDocument: candidate page count mismatch"
                        << sourcePageCount << "->" << reopened.GetPages().GetCount()
                        << "path:" << path;
            return false;
        }
    } catch (const PoDoFo::PdfError& e) {
        qCritical() << "PoDoFoBackend::saveDocument: candidate is not a valid PDF:"
                    << e.what() << "path:" << path;
        return false;
    }

    const QString cur = d->currentFile;
    bool sameFile = !cur.isEmpty() && QString::compare(cur, path, Qt::CaseInsensitive) == 0;
    if (!sameFile && !cur.isEmpty()) {
        // Alias-tolerant identity check (differing casing, 8.3 names,
        // symlinks): replacing the loaded file must always re-seat first.
        const QFileInfo curInfo(cur);
        const QFileInfo dstInfo(path);
        const QString curCanon = curInfo.canonicalFilePath();
        const QString dstCanon = dstInfo.canonicalFilePath();
        sameFile = !curCanon.isEmpty() && curCanon == dstCanon;
    }

    if (sameFile) {
        // Re-seat the resident document from the validated candidate bytes via
        // an in-memory buffer: destroying the previous document closes its
        // device on the file that is about to be replaced (so the atomic
        // rename can succeed), and a buffer-backed document holds no file
        // handle at all — every candidate file is removable on every path.
        // The bytes are stored in d->reseatBuffer (member, not local): the
        // re-seated document keeps parsing from that buffer for its whole
        // lifetime, so the buffer must outlive this call.
        QFile candidateFile(candidate);
        if (!candidateFile.open(QIODevice::ReadOnly)) {
            qCritical() << "PoDoFoBackend::saveDocument: validated candidate became unreadable:"
                        << candidateFile.errorString() << "path:" << path;
            return false;
        }
        d->reseatBuffer = candidateFile.readAll();
        candidateFile.close();
        auto reseeded = std::make_unique<PoDoFo::PdfMemDocument>();
        try {
            reseeded->LoadFromBuffer(
                PoDoFo::bufferview(d->reseatBuffer.constData(),
                                   static_cast<size_t>(d->reseatBuffer.size())));
        } catch (const PoDoFo::PdfError& e) {
            d->reseatBuffer.clear();
            qCritical() << "PoDoFoBackend::saveDocument: cannot re-seat resident document "
                           "from validated candidate:" << e.what() << "path:" << path;
            return false;
        }
        d->document = std::move(reseeded);
    }

    if (!gp::SafeSave::commitFileToDestination(candidate, path, &err)) {
        qCritical() << "PoDoFoBackend::saveDocument:" << err << "path:" << path;
        return false;
    }

    // The resident document (re-seated from the validated candidate bytes for
    // a same-file save) is byte-identical to the committed destination, and no
    // document holds a device on the candidate — the guard can always remove
    // it.

#ifdef QT_DEBUG
    qDebug() << "PoDoFo Engine structurally saved document to:" << path;
#endif
    return true;
}

int PoDoFoBackend::pageCount() const {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return 0;
    return static_cast<int>(d->document->GetPages().GetCount());
}

PdfMetadata PoDoFoBackend::metadata() const {
    QMutexLocker locker(&d->mutex);
    PdfMetadata outMetadata;
    if (!d->document) return outMetadata;
    try {
        auto& metadata = d->document->GetMetadata();
        
        auto t = metadata.GetTitle();
        if (t.has_value()) outMetadata.title = QString::fromStdString(std::string(t.value().GetString()));
        
        auto a = metadata.GetAuthor();
        if (a.has_value()) outMetadata.author = QString::fromStdString(std::string(a.value().GetString()));
        
        auto s = metadata.GetSubject();
        if (s.has_value()) outMetadata.subject = QString::fromStdString(std::string(s.value().GetString()));
        
        auto c = metadata.GetCreator();
        if (c.has_value()) outMetadata.creator = QString::fromStdString(std::string(c.value().GetString()));
        
        auto p = metadata.GetProducer();
        if (p.has_value()) outMetadata.producer = QString::fromStdString(std::string(p.value().GetString()));
        
        QStringList kwList;
        for (const auto& kw : metadata.GetKeywords()) {
            kwList << QString::fromStdString(kw);
        }
        outMetadata.keywords = kwList.join(", ");
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "PoDoFo error during getMetadata:" << e.what();
    }
    return outMetadata;
}

bool PoDoFoBackend::setMetadata(const PdfMetadata &metadata) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& meta = d->document->GetMetadata();
        meta.SetTitle(PoDoFo::PdfString(metadata.title.toUtf8().constData()));
        meta.SetAuthor(PoDoFo::PdfString(metadata.author.toUtf8().constData()));
        meta.SetSubject(PoDoFo::PdfString(metadata.subject.toUtf8().constData()));
        meta.SetCreator(PoDoFo::PdfString(metadata.creator.toUtf8().constData()));
        meta.SetProducer(PoDoFo::PdfString(metadata.producer.toUtf8().constData()));
        
        std::vector<std::string> kwVec;
        QStringList kwList = metadata.keywords.split(',', Qt::SkipEmptyParts);
        for (auto kw : kwList) {
            kwVec.push_back(kw.trimmed().toStdString());
        }
        meta.SetKeywords(kwVec);
        
        meta.SyncXMPMetadata(true);
#ifdef QT_DEBUG
        qDebug() << "Successfully updated document metadata.";
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "PoDoFo error during setMetadata:" << e.what();
        return false;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::writeDocument(const QString &path) {
    return saveDocument(path);
}

bool PoDoFoBackend::writeUpdate(const QString &path) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    // §6 non-negotiable: when signatures exist, a full rewrite changes the byte
    // offsets that every /ByteRange points at and silently invalidates the
    // signatures. Detect signatures and, if present, perform a real PoDoFo
    // incremental update (SaveUpdate appends a new revision, leaving the original
    // bytes — and therefore all signed /ByteRange windows — intact).
    bool hasSignatures = false;
    try {
        for (auto field : d->document->GetFieldsIterator()) {
            if (field != nullptr && field->GetType() == PoDoFo::PdfFieldType::Signature) {
                hasSignatures = true;
                break;
            }
        }
    } catch (const PoDoFo::PdfError& e) {
        qCritical() << "PoDoFoBackend::writeUpdate: failed to inspect signature fields:"
                    << e.what() << "— refusing to write rather than risk invalidating a signature.";
        return false;
    }

    if (!hasSignatures) {
        // No signatures to protect — a full save is safe.
        return saveDocument(path);
    }

    // Incremental update path. SaveUpdate appends to the file at `path`, which must
    // already contain the original document bytes. If we are writing to a different
    // file than the source, copy the source first so the incremental revision is
    // appended onto the exact bytes the signatures were computed over.
    try {
        const QString src = d->currentFile;
        if (!src.isEmpty() && QString::compare(src, path, Qt::CaseInsensitive) != 0) {
            if (QFile::exists(path) && !QFile::remove(path)) {
                qCritical() << "PoDoFoBackend::writeUpdate: cannot overwrite target" << path;
                return false;
            }
            if (!QFile::copy(src, path)) {
                qCritical() << "PoDoFoBackend::writeUpdate: failed to stage source bytes from"
                            << src << "to" << path << "for incremental update.";
                return false;
            }
        }
        // GUI-held-handle coordination: a same-path SaveUpdate appends to the
        // very file the viewer may display. The scope releases the viewer's
        // handle for the append and restores it on every outcome (SafeSave.h).
        const gp::SafeSave::ScopedFileHandleCoordination coordinationScope(path);
        d->document->SaveUpdate(path.toUtf8().constData());
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qCritical() << "PoDoFoBackend::writeUpdate: incremental SaveUpdate failed:"
                    << e.what() << "path:" << path;
        return false;
    } catch (const std::exception& e) {
        qCritical() << "PoDoFoBackend::writeUpdate: incremental save exception:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::hasPdfSignatures() const {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        for (auto field : d->document->GetFieldsIterator()) {
            if (field != nullptr && field->GetType() == PoDoFo::PdfFieldType::Signature)
                return true;
        }
    } catch (const PoDoFo::PdfError&) {
        // Cannot determine — treat conservatively as unsigned
    }
    return false;
}

int PoDoFoBackend::recipientCount() const {
    QMutexLocker locker(&d->mutex);
    if (!d->document || !d->document->IsEncrypted()) return 0;
    try {
        // Walk the trailer to find /Encrypt, then read /Recipients array.
        // PoDoFo 1.1.0 resolves indirect references automatically via FindKey.
        const PoDoFo::PdfObject* encrypt =
            d->document->GetTrailer().GetDictionary().FindKey("Encrypt");
        if (!encrypt) return 0;
        const PoDoFo::PdfObject* recipients =
            encrypt->GetDictionary().FindKey("Recipients");
        if (!recipients || !recipients->IsArray()) return 0;
        return static_cast<int>(recipients->GetArray().size());
    } catch (...) {
        return 0;
    }
}

QString PoDoFoBackend::currentFile() const {
    QMutexLocker locker(&d->mutex);
    return d->currentFile;
}

void PoDoFoBackend::setCurrentFile(const QString &path) {
    QMutexLocker locker(&d->mutex);
    d->currentFile = path;
}

namespace {

// Resolve an object that may be an indirect reference to its real object.
const PoDoFo::PdfObject* resolveRef(PoDoFo::PdfMemDocument* doc, const PoDoFo::PdfObject* obj) {
    using namespace PoDoFo;
    if (obj && obj->IsReference())
        return &doc->GetObjects().MustGetObject(obj->GetReference());
    return obj;
}

// Walk a PDF name-tree node (RFC: ISO 32000 §7.9.6). A node has either a
// flat /Names [key value key value …] array (leaf) or a /Kids array of child
// node references (intermediate). Both forms must be handled — qpdf and many
// producers emit a /Kids hierarchy even for a single entry, which a /Names-only
// reader would miss. `visit` is called with (name, valueObject) per entry;
// returning true stops the walk early.
void walkNameTree(PoDoFo::PdfMemDocument* doc, const PoDoFo::PdfObject* node,
                  int depth,
                  const std::function<bool(const std::string&, const PoDoFo::PdfObject*)>& visit,
                  bool& stop) {
    using namespace PoDoFo;
    if (stop || !node || depth > 64) return;  // depth guard against cyclic refs
    node = resolveRef(doc, node);
    if (!node || !node->IsDictionary()) return;
    const PdfDictionary& dict = node->GetDictionary();

    if (dict.HasKey(PdfName("Names"))) {
        const PdfObject* namesArr = resolveRef(doc, dict.GetKey(PdfName("Names")));
        if (namesArr && namesArr->IsArray()) {
            const auto& arr = namesArr->GetArray();
            for (size_t i = 0; i + 1 < arr.size(); i += 2) {
                const auto& nameVal = arr[i];
                if (!nameVal.IsString()) continue;
                if (visit(std::string(nameVal.GetString().GetString()), &arr[i + 1])) {
                    stop = true;
                    return;
                }
            }
        }
    }

    if (dict.HasKey(PdfName("Kids"))) {
        const PdfObject* kids = resolveRef(doc, dict.GetKey(PdfName("Kids")));
        if (kids && kids->IsArray()) {
            for (const auto& kid : kids->GetArray()) {
                walkNameTree(doc, &kid, depth + 1, visit, stop);
                if (stop) return;
            }
        }
    }
}

// Return the root node of the catalog's EmbeddedFiles name tree, or nullptr.
const PoDoFo::PdfObject* embeddedFilesRoot(PoDoFo::PdfMemDocument* doc) {
    using namespace PoDoFo;
    auto& catalog = doc->GetCatalog();
    if (!catalog.GetDictionary().HasKey(PdfName("Names"))) return nullptr;
    const PdfObject* names = resolveRef(doc, catalog.GetDictionary().GetKey(PdfName("Names")));
    if (!names || !names->IsDictionary()) return nullptr;
    if (!names->GetDictionary().HasKey(PdfName("EmbeddedFiles"))) return nullptr;
    return resolveRef(doc, names->GetDictionary().GetKey(PdfName("EmbeddedFiles")));
}

// Decode the embedded stream of a /Filespec object → bytes (empty on failure).
QByteArray decodeFilespecBytes(PoDoFo::PdfMemDocument* doc, const PoDoFo::PdfObject* fileSpec) {
    using namespace PoDoFo;
    fileSpec = resolveRef(doc, fileSpec);
    if (!fileSpec || !fileSpec->IsDictionary()) return {};

    const PdfObject* efSpec = resolveRef(doc, fileSpec->GetDictionary().GetKey(PdfName("EF")));
    if (!efSpec || !efSpec->IsDictionary()) return {};

    // Prefer /F (file), fall back to /UF (unicode file) stream.
    const PdfDictionary& efDict = efSpec->GetDictionary();
    const PdfObject* streamObj = efDict.GetKey(PdfName("F"));
    if (!streamObj) streamObj = efDict.GetKey(PdfName("UF"));
    streamObj = resolveRef(doc, streamObj);
    if (!streamObj || !streamObj->HasStream()) return {};

    const PdfObjectStream* stream = streamObj->GetStream();
    if (!stream) return {};

    charbuff buf;
    stream->CopyTo(buf);  // decoded (filters applied) bytes
    return QByteArray(buf.data(), static_cast<int>(buf.size()));
}

} // namespace

QStringList PoDoFoBackend::getEmbeddedFiles() {
    QMutexLocker locker(&d->mutex);
    QStringList files;
    if (!d->document) return files;
    try {
        const PoDoFo::PdfObject* root = embeddedFilesRoot(d->document.get());
        if (!root) return files;
        bool stop = false;
        walkNameTree(d->document.get(), root, 0,
            [&files](const std::string& name, const PoDoFo::PdfObject*) {
                files.append(QString::fromStdString(name));
                return false;  // visit every entry
            }, stop);
    } catch (...) {
        // Fallback gracefully
    }
    return files;
}

QByteArray PoDoFoBackend::extractEmbeddedFile(const QString &name) {
    QMutexLocker locker(&d->mutex);
    QByteArray result;
    if (!d->document) return result;
    try {
        const PoDoFo::PdfObject* root = embeddedFilesRoot(d->document.get());
        if (!root) return result;
        const std::string target = name.toStdString();
        bool stop = false;
        walkNameTree(d->document.get(), root, 0,
            [&](const std::string& entryName, const PoDoFo::PdfObject* fileSpec) {
                if (entryName != target) return false;
                result = decodeFilespecBytes(d->document.get(), fileSpec);
                return true;  // found — stop the walk
            }, stop);
    } catch (...) {
        // Fallback gracefully — empty result signals "could not extract".
    }
    return result;
}

QStringList PoDoFoBackend::getLayers() {
    QMutexLocker locker(&d->mutex);
    QStringList layers;
    if (!d->document) return layers;
    try {
        using namespace PoDoFo;
        auto& catalog = d->document->GetCatalog();
        if (catalog.GetDictionary().HasKey(PdfName("OCProperties"))) {
            auto* ocgObj = catalog.GetDictionary().GetKey(PdfName("OCProperties"));
            if (ocgObj && ocgObj->IsDictionary()) {
                auto* ocgsObj = ocgObj->GetDictionary().GetKey(PdfName("OCGs"));
                if (ocgsObj && ocgsObj->IsArray()) {
                    const auto& arr = ocgsObj->GetArray();
                    for (size_t i = 0; i < arr.size(); ++i) {
                        const auto& item = arr[i];
                        const PdfObject* OCG = &item;
                        if (OCG->IsReference()) {
                            OCG = &d->document->GetObjects().MustGetObject(OCG->GetReference());
                        }
                        if (OCG && OCG->IsDictionary()) {
                            auto* nameVal = OCG->GetDictionary().GetKey(PdfName("Name"));
                            if (nameVal && nameVal->IsString()) {
                                layers.append(QString::fromStdString(std::string(nameVal->GetString().GetString())));
                            }
                        }
                    }
                }
            }
        }
    } catch (...) {
        // Fallback gracefully
    }
    return layers;
}

bool PoDoFoBackend::rotatePage(const QString &path, int pageIndex, int degrees) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return false;

        auto& page = pages.GetPageAt(pageIndex);
        int current = static_cast<int>(page.GetRotation());
        page.SetRotation((current + degrees) % 360);
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

QByteArray PoDoFoBackend::extractPageAsBytes(const QString &path, int pageIndex) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return QByteArray();

        PoDoFo::PdfMemDocument tempDoc;
        tempDoc.GetPages().InsertDocumentPageAt(0, doc, pageIndex);

        std::vector<char> buffer;
        PoDoFo::VectorStreamDevice device(buffer);
        tempDoc.Save(device);

        return QByteArray(buffer.data(), static_cast<int>(buffer.size()));
    } catch (...) {
        return QByteArray();
    }
}

bool PoDoFoBackend::insertPageFromBytes(const QString &path, int atIndex, const QByteArray &pageData) {
    QMutexLocker locker(&d->mutex);
    if (pageData.size() > 10 * 1024 * 1024) {
        qCritical() << "SECURITY: Rejected page data exceeding maximum allowed buffer size (10MB).";
        return false;
    }
    try {
        PoDoFo::PdfMemDocument sourceDoc;
        sourceDoc.LoadFromBuffer(PoDoFo::bufferview(pageData.constData(), pageData.size()));
        if (sourceDoc.GetPages().GetCount() == 0) return false;

        auto& doc = d->resolveDocument(path);

        if (doc.GetPages().GetCount() + sourceDoc.GetPages().GetCount() > 10000) {
            qCritical() << "SECURITY: Operation rejected. Page insertion would exceed the 10,000 pages threshold.";
            return false;
        }

        doc.GetPages().InsertDocumentPageAt(atIndex, sourceDoc, 0);
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::deletePage(const QString &path, int pageIndex) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return false;

        pages.RemovePageAt(pageIndex);
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::insertBlankPage(const QString &path, int atIndex) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);

        doc.GetPages().CreatePageAt(atIndex, PoDoFo::PdfPageSize::A4);
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::editTextInline(int pageIndex, const QRectF &rect, const QString &newText,
                                   const QString &fontFamily, int fontSize,
                                   const QColor &color, bool bold,
                                   bool italic, int alignment) {
    QMutexLocker locker(&d->mutex);
    if (!d->document || pageIndex < 0 || (unsigned)pageIndex >= d->document->GetPages().GetCount()) return false;
    
    try {
        PoDoFo::PdfPage& page = d->document->GetPages().GetPageAt(pageIndex);
        
        std::string extractedFontName = "Helvetica";
        double extractedFontSize = 12.0;
        
        try {
            PoDoFo::PdfContentStreamReader reader(page);
            PoDoFo::PdfContent content;
            while (reader.TryReadNext(content)) {
                if (content.GetType() == PoDoFo::PdfContentType::Operator && content.GetKeyword() == "Tf") {
                    const auto& stack = content.GetStack();
                    if (stack.size() >= 2) {
                        if (stack[0].IsName()) {
                            extractedFontName = std::string(stack[0].GetName().GetString());
                        }
                        if (stack[1].IsNumberOrReal()) {
                            extractedFontSize = stack[1].GetReal();
                        }
                    }
                }
            }
            
            if (!extractedFontName.empty() && extractedFontName != "Helvetica") {
                const PoDoFo::PdfObject* fontObj = page.GetResources().GetResource(PoDoFo::PdfResourceType::Font, extractedFontName);
                if (fontObj && fontObj->IsDictionary()) {
                    const auto& fontDict = fontObj->GetDictionary();
                    if (fontDict.HasKey("BaseFont")) {
                        const auto* baseFont = fontDict.GetKey("BaseFont");
                        if (baseFont && baseFont->IsName()) {
                            extractedFontName = std::string(baseFont->GetName().GetString());
                            size_t plusPos = extractedFontName.find('+');
                            if (plusPos != std::string::npos) extractedFontName = extractedFontName.substr(plusPos + 1);
                            if (!extractedFontName.empty() && extractedFontName[0] == '/') extractedFontName = extractedFontName.substr(1);
                            size_t commaPos = extractedFontName.find(',');
                            if (commaPos != std::string::npos) extractedFontName = extractedFontName.substr(0, commaPos);
                            size_t dashPos = extractedFontName.find('-');
                            if (dashPos != std::string::npos) extractedFontName = extractedFontName.substr(0, dashPos);
                        }
                    }
                }
            }

        } catch (...) {
            extractedFontName = "Helvetica";
            extractedFontSize = 12.0;
        }
        if (extractedFontName.empty()) extractedFontName = "Helvetica";
        if (!fontFamily.isEmpty()) {
            extractedFontName = fontFamily.toStdString();
        }
        if (fontSize > 0) {
            extractedFontSize = fontSize;
        }

        PoDoFo::PdfPainter painter;
        painter.SetCanvas(page);
        
        painter.GraphicsState.SetNonStrokingColor(PoDoFo::PdfColor(1.0, 1.0, 1.0));
        PoDoFo::Rect pageRect = page.GetMediaBox();
        double pdfY = pageRect.Height - (rect.y() + rect.height());
        painter.DrawRectangle(rect.x(), pdfY, rect.width(), rect.height(), PoDoFo::PdfPathDrawMode::Fill);
        
        painter.GraphicsState.SetNonStrokingColor(PoDoFo::PdfColor(color.redF(), color.greenF(), color.blueF()));
        
        // Find standard font corresponding to bold/italic if it's a standard one
        const PoDoFo::PdfFont* font = nullptr;
        if (extractedFontName == "Helvetica" || extractedFontName == "Arial" || fontFamily.isEmpty()) {
            if (bold && italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::HelveticaBoldOblique);
            else if (bold) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::HelveticaBold);
            else if (italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::HelveticaOblique);
            else font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        } else if (extractedFontName == "Times" || extractedFontName == "Times New Roman") {
            if (bold && italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::TimesBoldItalic);
            else if (bold) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::TimesBold);
            else if (italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::TimesItalic);
            else font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::TimesRoman);
        } else if (extractedFontName == "Courier") {
            if (bold && italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::CourierBoldOblique);
            else if (bold) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::CourierBold);
            else if (italic) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::CourierOblique);
            else font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Courier);
        }

        if (!font) font = d->document->GetFonts().SearchFont(extractedFontName);
        if (!font) font = &d->document->GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        
        painter.TextState.SetFont(*font, extractedFontSize);
        
        QStringList lines = newText.split('\n');
        double currentY = pdfY + rect.height() - extractedFontSize;
        for (const QString& line : lines) {
            double x = rect.x();
            if (alignment == 1 || alignment == 2) { // Center or Right
                PoDoFo::PdfTextState textState;
                textState.Font = font;
                textState.FontSize = extractedFontSize;
                double textWidth = font->GetStringLength(line.toUtf8().constData(), textState);
                if (alignment == 1) { // Center
                    x += (rect.width() - textWidth) / 2.0;
                } else if (alignment == 2) { // Right
                    x += rect.width() - textWidth;
                }
            }
            painter.DrawText(line.toUtf8().constData(), x, currentY);
            currentY -= (extractedFontSize * 1.2);
        }
        painter.FinishDrawing();
        
#ifdef QT_DEBUG
        qDebug() << "Editing text inline via PoDoFo on page" << pageIndex << "font:" << extractedFontName.c_str() << "size:" << extractedFontSize;
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "PoDoFo error editing text:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::deleteObjectAt(int pageIndex, const QPointF &pos) {
    QMutexLocker locker(&d->mutex);
    QRectF redactionRect(pos.x() - 5, pos.y() - 5, 10, 10);
    if (!applyRedactions(pageIndex, {redactionRect})) return false;
    if (d->currentFile.isEmpty()) return false;
    try {
        if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "deleteObjectAt save error:" << e.what();
        return false;
    }
}

namespace {

double getEncodedStringWidth(const PoDoFo::PdfFont* font, const PoDoFo::PdfString& str, const PoDoFo::PdfTextState& state) {
    // E-1 (evidence ledger 2026-09-05): PdfString::GetString() forces PoDoFo's
    // lazy string evaluation IN PLACE — the raw byte buffer is consumed
    // (PoDoFo: "The raw data buffer has been evaluated to a string") and
    // replaced with a PdfDocEncoding/UTF-8 transcoding that is NOT
    // byte-preserving for glyph-encoded payloads (subset-font Tj strings:
    // observed glyph byte 0x16 'T' -> 0x17 'X', i.e. 'PUBLIC_KEEP_TEXT' ->
    // 'PUBLIC_KEEP_XEXX'). This helper runs for EVERY text-showing operator in
    // the canvas (to advance the pen and test the redaction rect), so
    // evaluating the CALLER'S operand mutated every neighboring Tj that shares
    // the content stream: the operand re-emission at the bottom of
    // redactCanvasRecursively serializes via ToString(), which for an evaluated
    // string writes the transcoded form instead of the original bytes — the
    // excision corrupted lines that intersect NO redaction rect.
    // Fix: evaluate a DEEP copy. NOTE: PdfString's copy constructor is NOT
    // sufficient — PdfString stores its buffer in a std::shared_ptr<StringData>
    // (copy-on-write), so a plain copy shares the state and evaluating it still
    // consumes the caller's raw bytes (proven by probe: shallow-copy evaluation
    // flips the original to evaluated and its ToString() emits the transcoded
    // form). FromRaw(GetRawData()) allocates an independent buffer: the width
    // numbers are identical (same bytes through the same font calls), but the
    // variant in the PdfVariantStack stays raw, so un-redacted operators
    // re-emit byte-exact.
    if (str.IsStringEvaluated()) {
        // Already evaluated (raw buffer consumed) — nothing left to protect.
        return font->GetStringLength(str.GetString(), state);
    }
    PoDoFo::PdfString safe = PoDoFo::PdfString::FromRaw(str.GetRawData(), str.IsHex());
    try {
        double len = 0.0;
        if (font->TryGetEncodedStringLength(safe, state, len)) {
            return len;
        }
    } catch (...) {
        // Fallback
    }
    return font->GetStringLength(safe.GetString(), state);
}

void cleanStructElement(PoDoFo::PdfObject* elem,
                        PoDoFo::PdfReference pageRef,
                        const std::set<int64_t>& redactedMcids,
                        PoDoFo::PdfMemDocument* doc,
                        int depth = 0) {
    if (!elem) return;
    // N-3: cap nesting depth. A crafted structure tree with a /K cycle would
    // otherwise recurse until stack exhaustion. Legitimate tag trees are
    // shallow; 64 levels is far beyond any real document.
    constexpr int kMaxStructDepth = 64;
    if (depth > kMaxStructDepth) {
        qWarning() << "SECURITY: structure-tree recursion exceeded depth"
                   << kMaxStructDepth << "- possible cyclic /K reference; subtree skipped";
        return;
    }
    if (elem->IsReference()) {
        elem = &doc->GetObjects().MustGetObject(elem->GetReference());
    }
    if (!elem->IsDictionary()) return;
    
    auto& dict = elem->GetDictionary();
    bool belongsToPage = false;
    auto* pgKey = dict.FindKey("Pg");
    if (pgKey && pgKey->IsReference() && pgKey->GetReference() == pageRef) {
        belongsToPage = true;
    }
    
    bool childRedacted = false;
    auto* kKey = dict.FindKey("K");
    if (kKey) {
        if (kKey->IsArray()) {
            auto& arr = kKey->GetArray();
            for (unsigned i = 0; i < arr.GetSize(); ) {
                bool removeKid = false;
                auto& kid = arr[i];
                
                if (kid.IsNumber()) {
                    int64_t mcid = kid.GetNumber();
                    if (belongsToPage && redactedMcids.count(mcid)) {
                        removeKid = true;
                        childRedacted = true;
                    }
                } else if (kid.IsDictionary() || kid.IsReference()) {
                    PoDoFo::PdfObject* kidObj = &kid;
                    if (kid.IsReference()) {
                        kidObj = &doc->GetObjects().MustGetObject(kid.GetReference());
                    }
                    if (kidObj->IsDictionary()) {
                        auto& kidDict = kidObj->GetDictionary();
                        auto* typeKey = kidDict.FindKey("Type");
                        if (typeKey && typeKey->IsName() && typeKey->GetName().GetString() == "MCR") {
                            auto* mcrPg = kidDict.FindKey("Pg");
                            auto* mcrMcid = kidDict.FindKey("MCID");
                            if (mcrPg && mcrPg->IsReference() && mcrPg->GetReference() == pageRef &&
                                mcrMcid && mcrMcid->IsNumber() && redactedMcids.count(mcrMcid->GetNumber())) {
                                removeKid = true;
                                childRedacted = true;
                            }
                        } else {
                            cleanStructElement(kidObj, pageRef, redactedMcids, doc, depth + 1);
                            auto* subK = kidDict.FindKey("K");
                            if (subK && subK->IsArray() && subK->GetArray().GetSize() == 0) {
                                removeKid = true;
                                childRedacted = true;
                            }
                        }
                    }
                }
                
                if (removeKid) {
                    arr.RemoveAt(i);
                } else {
                    ++i;
                }
            }
        } else if (kKey->IsNumber()) {
            int64_t mcid = kKey->GetNumber();
            if (belongsToPage && redactedMcids.count(mcid)) {
                dict.RemoveKey("K");
                childRedacted = true;
            }
        } else if (kKey->IsDictionary() || kKey->IsReference()) {
            PoDoFo::PdfObject* kidObj = kKey;
            if (kKey->IsReference()) {
                kidObj = &doc->GetObjects().MustGetObject(kKey->GetReference());
            }
            if (kidObj->IsDictionary()) {
                auto& kidDict = kidObj->GetDictionary();
                auto* typeKey = kidDict.FindKey("Type");
                if (typeKey && typeKey->IsName() && typeKey->GetName().GetString() == "MCR") {
                    auto* mcrPg = kidDict.FindKey("Pg");
                    auto* mcrMcid = kidDict.FindKey("MCID");
                    if (mcrPg && mcrPg->IsReference() && mcrPg->GetReference() == pageRef &&
                        mcrMcid && mcrMcid->IsNumber() && redactedMcids.count(mcrMcid->GetNumber())) {
                        dict.RemoveKey("K");
                        childRedacted = true;
                    }
                } else {
                    cleanStructElement(kidObj, pageRef, redactedMcids, doc, depth + 1);
                    auto* subK = kidDict.FindKey("K");
                    if (subK && subK->IsArray() && subK->GetArray().GetSize() == 0) {
                        dict.RemoveKey("K");
                        childRedacted = true;
                    }
                }
            }
        }
    }
    
    bool hasRedactedContent = childRedacted || (belongsToPage && !redactedMcids.empty());
    if (hasRedactedContent) {
        if (dict.HasKey("ActualText")) dict.RemoveKey("ActualText");
        if (dict.HasKey("Alt")) dict.RemoveKey("Alt");
        if (dict.HasKey("E")) dict.RemoveKey("E");
    }
}

} // anonymous namespace

QRectF PoDoFoBackend::pageCropBox(const QString &path, int pageIndex, bool *ok) {
    QMutexLocker locker(&d->mutex);
    if (ok) *ok = false;
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return QRectF();

        auto& page = pages.GetPageAt(pageIndex);
        // EC05: the EFFECTIVE box — the explicit /CropBox when present,
        // otherwise the MediaBox. Array entries may be real or integer
        // objects depending on the writer; normalize both.
        auto boxNumber = [](const PoDoFo::PdfObject &v) -> double {
            return v.IsNumberOrReal() ? v.GetReal() : 0.0;
        };
        double x = 0, y = 0, w = 0, h = 0;
        if (const PoDoFo::PdfObject *crop = page.GetDictionary().FindKey("CropBox");
                crop && crop->IsArray() && crop->GetArray().GetSize() == 4) {
            const PoDoFo::PdfArray &arr = crop->GetArray();
            x = boxNumber(arr[0]);
            y = boxNumber(arr[1]);
            w = boxNumber(arr[2]);
            h = boxNumber(arr[3]);
        } else {
            const PoDoFo::Rect media = page.GetMediaBox();
            x = media.X; y = media.Y; w = media.Width; h = media.Height;
        }
        if (ok) *ok = true;
        return QRectF(x, y, w, h);
    } catch (...) {
        return QRectF();
    }
}

void PoDoFoBackend::releaseResidentFile(const QString &path) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return;
    const QString cur = d->currentFile;
    bool sameFile = !cur.isEmpty() && QString::compare(cur, path, Qt::CaseInsensitive) == 0;
    if (!sameFile && !cur.isEmpty()) {
        // Alias-tolerant identity check (same rule as saveDocument: differing
        // casing, 8.3 names, symlinks must never leave a device pinned).
        const QFileInfo curInfo(cur);
        const QFileInfo dstInfo(path);
        const QString curCanon = curInfo.canonicalFilePath();
        const QString dstCanon = dstInfo.canonicalFilePath();
        sameFile = !curCanon.isEmpty() && curCanon == dstCanon;
    }
    if (!sameFile) return;
    // GUI-held-handle residual (2026-09-08 persistence lane): the resident
    // parser holds an OS device on its source file for lazy object resolution
    // — the very device the saveDocument transaction re-seats away before its
    // own same-file commit. A shell-side writer that replaces this file
    // through SafeSave (form import) cannot re-seat from inside the engine, so
    // it asks here: dropping the document closes the device, and the next
    // resolveDocument(path) lazily re-loads from disk — the committed result,
    // or the preserved original on a failed replacement; truthful either way.
    d->document.reset();
    d->currentFile.clear();
    d->reseatBuffer.clear();   // the buffer backed the dropped document's lineage
}

bool PoDoFoBackend::cropPage(const QString &path, int pageIndex, const QRectF &cropRect) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return false;
        
        auto& page = pages.GetPageAt(pageIndex);
        PoDoFo::Rect podofoRect(cropRect.x(), cropRect.y(), cropRect.width(), cropRect.height());
        page.GetDictionary().AddKey("CropBox", podofoRect.ToArray());
        
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::resizePage(const QString &path, int pageIndex, const QSizeF &size) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount()) return false;
        
        auto& page = pages.GetPageAt(pageIndex);
        PoDoFo::Rect oldMedia = page.GetMediaBox();
        PoDoFo::Rect newMedia(oldMedia.X, oldMedia.Y, size.width(), size.height());
        page.GetDictionary().AddKey("MediaBox", newMedia.ToArray());
        
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::reorderPages(const QString &path, int fromIndex, int toIndex) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        if (fromIndex < 0 || static_cast<size_t>(fromIndex) >= pages.GetCount()) return false;
        if (toIndex < 0 || static_cast<size_t>(toIndex) >= pages.GetCount()) return false;
        if (fromIndex == toIndex) return true;
        
        // Use a temporary document to extract and reinsert the page
        PoDoFo::PdfMemDocument tempDoc;
        tempDoc.GetPages().InsertDocumentPageAt(0, doc, fromIndex);
        
        pages.RemovePageAt(fromIndex);
        
        // Adjust toIndex after removal if necessary
        if (fromIndex < toIndex) {
            toIndex--;
        }
        
        pages.InsertDocumentPageAt(toIndex, tempDoc, 0);
        
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::reorderAllPages(const QString &path, const QList<int> &permutation) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        const int n = static_cast<int>(pages.GetCount());

        // Validate permutation: must be a bijection of [0, n).
        if (permutation.size() != n) return false;
        QVector<bool> seen(n, false);
        for (int idx : permutation) {
            if (idx < 0 || idx >= n || seen[idx]) return false;
            seen[idx] = true;
        }

        // Extract ALL pages into a temporary document in the DESIRED order.
        // We copy each source page (by original index) into a temp doc, then
        // rebuild the real document's page tree from the temp doc.  This performs
        // the entire permutation without any intermediate writes to disk.
        PoDoFo::PdfMemDocument tempDoc;
        for (int i = 0; i < n; ++i) {
            tempDoc.GetPages().InsertDocumentPageAt(i, doc, permutation[i]);
        }

        // Remove all pages from the original document (back-to-front to keep indices stable).
        for (int i = n - 1; i >= 0; --i) {
            pages.RemovePageAt(i);
        }

        // Re-insert from the temp doc in the correct order.
        for (int i = 0; i < n; ++i) {
            pages.InsertDocumentPageAt(i, tempDoc, i);
        }

        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::addHeaderFooter(const QString &path, const HeaderFooterOptions &options) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        int totalPages = static_cast<int>(pages.GetCount());
        
        std::string fontName = options.fontFamily.isEmpty() ? "Helvetica" : options.fontFamily.toStdString();
        const PoDoFo::PdfFont* font = doc.GetFonts().SearchFont(fontName);
        if (!font) {
            fontName = "Helvetica";
            font = &doc.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        }
        
        for (int i = 0; i < totalPages; ++i) {
            auto& page = pages.GetPageAt(i);
            QString text = options.textTemplate;
            text.replace("{page}", QString::number(i + 1));
            text.replace("{total}", QString::number(totalPages));
            appendEscapedText(doc, page, text, options.position, options.fontSize, fontName);
        }
        
        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}

bool PoDoFoBackend::applyBatesNumbering(const QString &path, const BatesNumberingOptions &options) {
    // §9.9 P1: the legacy two-argument entry point keeps its exact stamping
    // contract; it simply ignores the counter report of the continuity overload.
    return applyBatesNumbering(path, options, nullptr);
}

bool PoDoFoBackend::applyBatesNumbering(const QString &path, const BatesNumberingOptions &options, int *lastNumberOut) {
    QMutexLocker locker(&d->mutex);
    try {
        auto& doc = d->resolveDocument(path);
        auto& pages = doc.GetPages();
        int totalPages = static_cast<int>(pages.GetCount());

        std::string fontName = options.fontFamily.isEmpty() ? "Helvetica" : options.fontFamily.toStdString();
        const PoDoFo::PdfFont* font = doc.GetFonts().SearchFont(fontName);
        if (!font) {
            fontName = "Helvetica";
            font = &doc.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        }

        // Resolve the 1-based inclusive page range (<=0 means open-ended).
        int firstIdx = (options.firstPage > 0) ? options.firstPage - 1 : 0;
        int lastIdx  = (options.lastPage  > 0) ? options.lastPage  - 1 : totalPages - 1;
        firstIdx = std::max(0, firstIdx);
        lastIdx  = std::min(totalPages - 1, lastIdx);

        int currentNumber = options.startNumber;
        for (int i = firstIdx; i <= lastIdx; ++i) {
            auto& page = pages.GetPageAt(i);

            QString numStr = QString::number(currentNumber).rightJustified(options.digitCount, '0');
            QString text = options.prefix + numStr + options.suffix;
            appendEscapedText(doc, page, text, options.position, options.fontSize, fontName);

            currentNumber++;
        }

        // §9.9 P1: report the last number actually consumed. When no page was
        // stamped (empty/out-of-range range) this is startNumber - 1, so a
        // cross-document batch continuing at `last + 1` neither skips nor
        // repeats a number.
        if (lastNumberOut) *lastNumberOut = currentNumber - 1;

        if (!writeUpdate(path)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (...) {
        return false;
    }
}


// A-02: destructively replace an image XObject's pixel data with a single 1x1
// black pixel, so the ORIGINAL image bytes do not survive anywhere in the saved
// file. We rewrite the stream and the geometry/colour keys to a self-consistent
// 1x1 DeviceGray image and strip keys that referenced the old pixels (Filter,
// DecodeParms, SMask, Mask, Decode, alternates). The on-page Do is dropped
// separately by the caller, so the neutralised object is also no longer painted.
static void neutralizeImageXObject(PoDoFo::PdfObject& xobj)
{
    using namespace PoDoFo;
    if (!xobj.IsDictionary()) return;
    auto& dict = xobj.GetDictionary();

    // Remove keys tied to the original pixel encoding/geometry.
    for (const char* k : { "Filter", "DecodeParms", "DP", "SMask", "Mask",
                           "Decode", "Alternates", "ColorKeyMask", "Interpolate" }) {
        if (dict.HasKey(k)) dict.RemoveKey(PdfName(k));
    }

    // Self-consistent 1x1 8-bit DeviceGray image.
    dict.AddKey(PdfName("Width"),            static_cast<int64_t>(1));
    dict.AddKey(PdfName("Height"),           static_cast<int64_t>(1));
    dict.AddKey(PdfName("BitsPerComponent"), static_cast<int64_t>(8));
    dict.AddKey(PdfName("ColorSpace"),       PdfName("DeviceGray"));

    // Overwrite the stream with a single black pixel (raw, unfiltered).
    auto& stream = xobj.GetOrCreateStream();
    const char pixel[1] = { '\0' };
    stream.SetData(bufferview(pixel, sizeof(pixel)), true /*raw*/);
}

// CTM for the redaction canvas recursion — forward-declared so it can be
// used as a default parameter value inside the helper struct below.
struct RedactCtm { double a=1,b=0,c=0,d=1,e=0,f=0; };

// NF-2: Pass the active resource dictionary explicitly so that when we
// recurse into a Form XObject that has its own /Resources dict, Do-name
// lookups are resolved against that Form's resources, not the page's.
// parentCtm: the accumulated CTM from the parent canvas at the point the
// Form XObject's Do was encountered.  Inside the Form we start with this
// CTM so that `cm` and image-bbox calculations are in page space.
void redactCanvasRecursively(PoDoFo::PdfObject& canvasObj,
                             const std::vector<PoDoFo::Rect>& pdfRects,
                             PoDoFo::PdfPage& page,
                             PoDoFo::PdfMemDocument* document,
                             std::set<int64_t>& redactedMcids,
                             PoDoFo::PdfObject* activeResources = nullptr,
                             RedactCtm parentCtm = RedactCtm{},
                             int depth = 0)
{
    using namespace PoDoFo;

    // N-3: cap nesting depth. A crafted PDF with cyclic or deeply nested Form
    // XObject references would otherwise exhaust the stack. 32 levels is far
    // beyond any legitimate document (typical nesting is 1-3).
    constexpr int kMaxCanvasDepth = 32;
    if (depth > kMaxCanvasDepth) {
        qWarning() << "SECURITY: redaction canvas recursion exceeded depth"
                   << kMaxCanvasDepth << "- possible cyclic Form XObject; subtree skipped";
        return;
    }

    // Resolve the active resource dictionary for this canvas:
    // - If the caller supplied one (Form XObject recursion), use it.
    // - Otherwise fall back to the page's own resources.
    PdfObject* canvasResources = activeResources;
    if (!canvasResources) {
        // Top-level call: use page resources.
        canvasResources = &page.GetResources().GetObject();
    }

    std::string streamStr;
    if (canvasObj.HasStream()) {
        auto* streamObj = canvasObj.GetStream();
        if (streamObj) {
            PoDoFo::charbuff buf;
            streamObj->CopyTo(buf);
            streamStr.assign(buf.data(), buf.size());
        }
    } else {
        auto* contentsObj = page.GetContents();
        if (contentsObj) {
            PoDoFo::charbuff buf;
            contentsObj->CopyTo(buf);
            streamStr.assign(buf.data(), buf.size());
        }
    }

    auto device = std::make_shared<PoDoFo::SpanStreamDevice>(streamStr);
    PdfContentStreamReader reader(device);
    PdfContent content;
    std::ostringstream newStream;

    bool inTextBlock = false;
    double leading = 0.0;

    // F-02 fix: the scalar textX/textY cursor alone cannot model rotated/scaled/
    // skewed text — "a b c d e f Tm" carries a full affine text matrix whose linear
    // part (a,b,c,d) was previously discarded, letting non-axis-aligned glyph runs
    // escape the redaction rect. We track the full text matrix (Tm) and text line
    // matrix (Tlm) per PDF 9.4.2, plus a horizontal pen offset (sum of glyph advances
    // since the line origin). A baseline point at pen offset t then maps to device as
    // [t 0 1] x Tm x CTM (full affine), which is what isIntersectingSpan now tests.
    RedactCtm tm;   // current text matrix (Tm)
    RedactCtm tlm;  // current text line matrix (Tlm)
    double penX = 0.0; // horizontal advance within the current line, in text space
    
    // Text state parameters
    double currentFontSize = 12.0;
    double currentCharSpacing = 0.0;
    double currentWordSpacing = 0.0;
    double currentFontScale = 1.0;
    std::string currentFontName = "Helvetica";
    int currentRenderingMode = 0; // Tr
    
    int64_t currentMcid = -1;

    // A-02: track the graphics-state CTM so an image's placement is computed from
    // its own `cm` matrix (the normal case), not the text cursor. A PDF affine
    // matrix is [a b c d e f]; image space is the unit square [0,1]x[0,1], so the
    // four transformed corners give the image's device-space bounding box.
    // NF-2 fix: initialise from parentCtm so that Form XObject recursion inherits
    // the parent canvas's accumulated transformation (e.g. the `cm` that placed
    // the Form on the page), keeping all image bbox calculations in page space.
    using Ctm = RedactCtm;
    Ctm ctm = parentCtm;           // current transformation matrix (inherited from parent)
    std::vector<Ctm> ctmStack;     // q/Q save/restore stack

    // result = m2 x m1 (apply m1 then m2), per PDF 8.3.4 matrix concatenation.
    auto concat = [](const Ctm& m1, const Ctm& m2) -> Ctm {
        Ctm r;
        r.a = m1.a * m2.a + m1.b * m2.c;
        r.b = m1.a * m2.b + m1.b * m2.d;
        r.c = m1.c * m2.a + m1.d * m2.c;
        r.d = m1.c * m2.b + m1.d * m2.d;
        r.e = m1.e * m2.a + m1.f * m2.c + m2.e;
        r.f = m1.e * m2.b + m1.f * m2.d + m2.f;
        return r;
    };

    // F-02 fix: map text-space points through the FULL text matrix (Tm) and then
    // the CTM — device = [x y 1] x Tm x CTM — instead of treating (x,y) as a
    // horizontal span in CTM only. penStart/penEnd are horizontal pen offsets along
    // the baseline (text space, line-relative); the glyph run's true device extent
    // is the axis-aligned bbox of the two transformed endpoints. This correctly
    // catches rotated/scaled/skewed runs that the scalar-cursor model let leak.
    auto mapTextToDevice = [&](double x, double y, double& dx, double& dy) {
        // text space -> page/canvas space via Tm
        double px = tm.a * x + tm.c * y + tm.e;
        double py = tm.b * x + tm.d * y + tm.f;
        // page space -> device via CTM
        dx = ctm.a * px + ctm.c * py + ctm.e;
        dy = ctm.b * px + ctm.d * py + ctm.f;
    };

    auto isIntersectingSpan = [&](double penStart, double penEnd) -> bool {
        double outX1, outY1, outX2, outY2;
        mapTextToDevice(penStart, 0.0, outX1, outY1);
        mapTextToDevice(penEnd,   0.0, outX2, outY2);

        double minX = std::min(outX1, outX2);
        double maxX = std::max(outX1, outX2);
        double minY = std::min(outY1, outY2);
        double maxY = std::max(outY1, outY2);

        for (const auto& r : pdfRects) {
            if (maxX >= r.X && minX <= (r.X + r.Width) &&
                maxY >= r.Y && minY <= (r.Y + r.Height)) {
                return true;
            }
        }
        return false;
    };

    // A-02: does the CURRENT CTM's image bbox (unit square mapped through ctm)
    // intersect any redaction rect? Uses an axis-aligned bbox of the 4 corners.
    auto imageBboxIntersects = [&]() -> bool {
        const double xs[4] = {0, 1, 0, 1};
        const double ys[4] = {0, 0, 1, 1};
        double minX = 1e300, minY = 1e300, maxX = -1e300, maxY = -1e300;
        for (int k = 0; k < 4; ++k) {
            double dx = ctm.a * xs[k] + ctm.c * ys[k] + ctm.e;
            double dy = ctm.b * xs[k] + ctm.d * ys[k] + ctm.f;
            minX = std::min(minX, dx); maxX = std::max(maxX, dx);
            minY = std::min(minY, dy); maxY = std::max(maxY, dy);
        }
        for (const auto& r : pdfRects) {
            if (maxX >= r.X && minX <= (r.X + r.Width) &&
                maxY >= r.Y && minY <= (r.Y + r.Height))
                return true;
        }
        return false;
    };

    while (reader.TryReadNext(content)) {
        if (content.GetType() == PdfContentType::Operator) {
            std::string_view kw = content.GetKeyword();
            const auto& stack = content.GetStack();
            
            if (kw == "BT") {
                inTextBlock = true;
                // F-02: BT resets Tm and Tlm to identity (PDF 9.4.1).
                tm = RedactCtm{}; tlm = RedactCtm{}; penX = 0.0;
                newStream << "BT\n";
                continue;
            }
            if (kw == "ET") {
                inTextBlock = false;
                newStream << "ET\n";
                continue;
            }

            // A-02: graphics-state CTM tracking (q/Q/cm). Stack index 0 == last
            // pushed operand, so "a b c d e f cm" gives stack[5..0] = a..f.
            if (kw == "q") {
                ctmStack.push_back(ctm);
            } else if (kw == "Q") {
                if (!ctmStack.empty()) { ctm = ctmStack.back(); ctmStack.pop_back(); }
            } else if (kw == "cm" && stack.size() >= 6 &&
                       stack[0].IsNumberOrReal() && stack[1].IsNumberOrReal() &&
                       stack[2].IsNumberOrReal() && stack[3].IsNumberOrReal() &&
                       stack[4].IsNumberOrReal() && stack[5].IsNumberOrReal()) {
                Ctm m;
                m.a = stack[5].GetReal(); m.b = stack[4].GetReal();
                m.c = stack[3].GetReal(); m.d = stack[2].GetReal();
                m.e = stack[1].GetReal(); m.f = stack[0].GetReal();
                ctm = concat(m, ctm);   // new CTM = cm-matrix x oldCTM
            }

            if (kw == "TL" && stack.size() > 0) {
                if (stack[0].IsNumberOrReal()) leading = stack[0].GetReal();
            }
            if (kw == "T*" && inTextBlock) {
                // F-02: T* is equivalent to "0 -leading Td": Tlm = translate(0,-leading) x Tlm, Tm = Tlm.
                RedactCtm tr; tr.e = 0.0; tr.f = -leading;
                tlm = concat(tr, tlm); tm = tlm; penX = 0.0;
            }
            if (kw == "Tm" && stack.size() >= 6) {
                // PdfVariantStack index 0 = top of stack = last pushed operand.
                // "a b c d e f Tm" pushes in order a..f, so stack[0]=f, stack[1]=e, ... stack[5]=a.
                // F-02: capture the FULL text matrix (a,b,c,d,e,f). Tm sets both Tm and Tlm.
                RedactCtm m;
                if (stack[5].IsNumberOrReal()) m.a = stack[5].GetReal();
                if (stack[4].IsNumberOrReal()) m.b = stack[4].GetReal();
                if (stack[3].IsNumberOrReal()) m.c = stack[3].GetReal();
                if (stack[2].IsNumberOrReal()) m.d = stack[2].GetReal();
                if (stack[1].IsNumberOrReal()) m.e = stack[1].GetReal();
                if (stack[0].IsNumberOrReal()) m.f = stack[0].GetReal();
                tm = m; tlm = m; penX = 0.0;
            } else if ((kw == "Td" || kw == "TD") && stack.size() >= 2) {
                // "tx ty Td" pushes tx first, ty second, so stack[0]=ty, stack[1]=tx.
                double tx = 0.0, ty = 0.0;
                if (stack[1].IsNumberOrReal()) { tx = stack[1].GetReal(); }
                if (stack[0].IsNumberOrReal()) {
                    ty = stack[0].GetReal();
                    if (kw == "TD") leading = -ty;
                }
                // F-02: Td/TD: Tlm = translate(tx,ty) x Tlm, Tm = Tlm (PDF 9.4.2).
                RedactCtm tr; tr.e = tx; tr.f = ty;
                tlm = concat(tr, tlm); tm = tlm; penX = 0.0;
            }
            
            // Track Text State Parameters
            if (kw == "Tf" && stack.size() >= 2) {
                // "font size Tf": the font NAME is pushed first (stack[1]), the
                // size is pushed last (stack[0]). The previous slot order read the
                // size as the font name and skipped both (guards failed), silently
                // keeping the Helvetica/12 defaults for every font and size — the
                // basis of the excision-gap advance computation.
                if (stack[1].IsName()) {
                    currentFontName = stack[1].GetName().GetString();
                }
                if (stack[0].IsNumberOrReal()) {
                    currentFontSize = stack[0].GetReal();
                }
            } else if (kw == "Tc" && stack.size() >= 1) {
                if (stack[0].IsNumberOrReal()) currentCharSpacing = stack[0].GetReal();
            } else if (kw == "Tw" && stack.size() >= 1) {
                if (stack[0].IsNumberOrReal()) currentWordSpacing = stack[0].GetReal();
            } else if (kw == "Tz" && stack.size() >= 1) {
                if (stack[0].IsNumberOrReal()) currentFontScale = stack[0].GetReal() / 100.0;
            } else if (kw == "Tr" && stack.size() >= 1) {
                if (stack[0].IsNumberOrReal()) currentRenderingMode = static_cast<int>(stack[0].GetReal());
            }
            
            // Track MCID
            if (kw == "BDC" && stack.size() >= 2) {
                const auto& prop = stack[1];
                if (prop.IsDictionary()) {
                    auto* mcidObj = prop.GetDictionary().FindKey("MCID");
                    if (mcidObj && mcidObj->IsNumber()) {
                        currentMcid = mcidObj->GetNumber();
                    }
                } else if (prop.IsName()) {
                    // NF-2: resolve Properties from the current canvas resources.
                    auto* propDictObj = (canvasResources && canvasResources->IsDictionary())
                                       ? canvasResources->GetDictionary().FindKey("Properties")
                                       : nullptr;
                    if (propDictObj && propDictObj->IsDictionary()) {
                        auto* subDictObj = propDictObj->GetDictionary().FindKey(prop.GetName());
                        if (subDictObj) {
                            if (subDictObj->IsReference())
                                subDictObj = &document->GetObjects().MustGetObject(subDictObj->GetReference());
                            if (subDictObj->IsDictionary()) {
                                auto* mcidObj = subDictObj->GetDictionary().FindKey("MCID");
                                if (mcidObj && mcidObj->IsNumber()) {
                                    currentMcid = mcidObj->GetNumber();
                                }
                            }
                        }
                    }
                }
            } else if (kw == "EMC") {
                currentMcid = -1;
            }
            
            bool isTextOp = (kw == "Tj" || kw == "TJ" || kw == "'" || kw == "\"");
            if (isTextOp) {
                // Resolve font — NF-2: use canvasResources (may be a Form XObject's
                // /Resources) so fonts local to a Form are found correctly.
                const PdfFont* resolvedFont = nullptr;
                auto* fontDict = (canvasResources && canvasResources->IsDictionary())
                                 ? canvasResources->GetDictionary().FindKey("Font")
                                 : nullptr;
                if (fontDict && fontDict->IsDictionary()) {
                    auto* fontObj = fontDict->GetDictionary().FindKey(currentFontName);
                    if (fontObj) {
                        if (fontObj->IsReference())
                            fontObj = &document->GetObjects().MustGetObject(fontObj->GetReference());
                        if (fontObj->IsDictionary()) {
                            auto* baseFont = fontObj->GetDictionary().FindKey("BaseFont");
                            if (baseFont && baseFont->IsName()) {
                                std::string baseFontName = std::string(baseFont->GetName().GetString());
                                size_t plusPos = baseFontName.find('+');
                                if (plusPos != std::string::npos) baseFontName = baseFontName.substr(plusPos + 1);
                                if (!baseFontName.empty() && baseFontName[0] == '/') baseFontName = baseFontName.substr(1);
                                size_t commaPos = baseFontName.find(',');
                                if (commaPos != std::string::npos) baseFontName = baseFontName.substr(0, commaPos);
                                size_t dashPos = baseFontName.find('-');
                                if (dashPos != std::string::npos) baseFontName = baseFontName.substr(0, dashPos);
                                resolvedFont = document->GetFonts().SearchFont(baseFontName);
                            }
                        }
                    }
                }
                if (!resolvedFont) {
                    resolvedFont = &document->GetFonts().GetStandard14Font(PdfStandard14FontType::Helvetica);
                }
                
                PdfTextState textState;
                textState.Font = resolvedFont;
                textState.FontSize = currentFontSize;
                textState.FontScale = currentFontScale;
                textState.CharSpacing = currentCharSpacing;
                textState.WordSpacing = currentWordSpacing;
                
                double totalAdvance = 0.0;
                if (kw == "Tj" && stack.size() >= 1) {
                    if (stack[0].IsString()) {
                        totalAdvance = getEncodedStringWidth(resolvedFont, stack[0].GetString(), textState);
                    }
                } else if (kw == "TJ" && stack.size() >= 1) {
                    if (stack[0].IsArray()) {
                        for (const auto& item : stack[0].GetArray()) {
                            if (item.IsString()) {
                                totalAdvance += getEncodedStringWidth(resolvedFont, item.GetString(), textState);
                            } else if (item.IsNumberOrReal()) {
                                totalAdvance -= (item.GetReal() / 1000.0) * currentFontSize * currentFontScale;
                            }
                        }
                    }
                } else if (kw == "'" && stack.size() >= 1) {
                    if (stack[0].IsString()) {
                        totalAdvance = getEncodedStringWidth(resolvedFont, stack[0].GetString(), textState);
                    }
                } else if (kw == "\"" && stack.size() >= 3) {
                    if (stack[0].IsNumberOrReal()) currentWordSpacing = stack[0].GetReal();
                    if (stack[1].IsNumberOrReal()) currentCharSpacing = stack[1].GetReal();
                    textState.CharSpacing = currentCharSpacing;
                    textState.WordSpacing = currentWordSpacing;
                    if (stack[2].IsString()) {
                        totalAdvance = getEncodedStringWidth(resolvedFont, stack[2].GetString(), textState);
                    }
                }
                
                if (kw == "'" || kw == "\"") {
                    // F-02: ' and " perform a T* (new line) before showing text.
                    RedactCtm tr; tr.e = 0.0; tr.f = -leading;
                    tlm = concat(tr, tlm); tm = tlm; penX = 0.0;
                }

                // F-02: the glyph run occupies pen offsets [penX, penX+totalAdvance]
                // along the baseline of the current text matrix Tm (full affine).
                if (inTextBlock && isIntersectingSpan(penX, penX + totalAdvance)) {
                    // Record redacted MCID if active
                    if (currentMcid != -1) {
                        redactedMcids.insert(currentMcid);
                    }

                    // Tr==3 (invisible text): operator is scrubbed without any cursor-advance
                    // substitution. Invisible glyphs produce no visual output, so there is no
                    // visible gap to preserve. Dropping the operator entirely is safe — the
                    // OCR text layer is removed and no glyph-advance side-channel is emitted.
                    if (currentRenderingMode == 3) {
                        // For ' and " operators that advance the line, we still need the
                        // text-position side-effect (T* equivalent) so downstream text stays
                        // correctly positioned, but we suppress any glyph string output.
                        if (kw == "'") {
                            newStream << "T*\n";
                        } else if (kw == "\"") {
                            newStream << stack[0].GetReal() << " Tw\n";
                            newStream << stack[1].GetReal() << " Tc\n";
                            newStream << "T*\n";
                        }
                        penX += totalAdvance;
                        continue;
                    }
                    // Edact-Ray defense (PETS 2023, Bland et al.): emit numeric-only TJ gap.
                    // [N] TJ moves cursor by -(N/1000)*fontSize*fontScale text-space units.
                    // N = -totalAdvance * 1000 / scale gives exact sum-of-advances, no glyph emitted.
                    // An attacker can measure the total gap width but cannot reconstruct individual
                    // character widths from it, blocking the glyph-advance side-channel attack.
                    double scale = currentFontSize * currentFontScale;

                    if (kw == "'") {
                        newStream << "T*\n";
                    } else if (kw == "\"") {
                        newStream << stack[0].GetReal() << " Tw\n";
                        newStream << stack[1].GetReal() << " Tc\n";
                        newStream << "T*\n";
                    }

                    if (std::abs(totalAdvance) > 1e-10 && std::abs(scale) > 1e-5) {
                        double N = -totalAdvance * 1000.0 / scale;
                        newStream << "[ " << N << " ] TJ\n";
                    }
                    // totalAdvance ≈ 0 or scale ≈ 0: emit nothing (safe — no glyph, no cursor shift).
                    penX += totalAdvance;
                    continue;
                }

                penX += totalAdvance;
            }
            
            if (kw == "Do" && stack.size() > 0 && stack[0].IsName()) {
                std::string xobjName(stack[0].GetName().GetString());

                // NF-2: Use the CURRENT canvas's resource dictionary (not always
                // the page dict) so that names defined in a Form XObject's own
                // /Resources are resolved correctly during recursion.
                PdfObject* xobj = nullptr;
                if (canvasResources && canvasResources->IsDictionary()) {
                    auto* xobjectDict = canvasResources->GetDictionary().FindKey("XObject");
                    if (xobjectDict && xobjectDict->IsDictionary()) {
                        auto* xobjRef = xobjectDict->GetDictionary().FindKey(xobjName);
                        if (xobjRef) {
                            xobj = xobjRef;
                            if (xobj->IsReference())
                                xobj = &document->GetObjects().MustGetObject(xobj->GetReference());
                        }
                    }
                }

                std::string subtypeName;
                if (xobj && xobj->IsDictionary()) {
                    auto& dict = xobj->GetDictionary();
                    auto* subtype = dict.FindKey("Subtype");
                    if (subtype && subtype->IsName())
                        subtypeName = std::string(subtype->GetName().GetString());
                }

                if (subtypeName == "Image") {
                    // A-02: test the IMAGE's own placement (unit square through the
                    // current CTM), not the text cursor. If it intersects a redaction
                    // rect: (1) drop the Do so the image is not painted, and
                    // (2) excise the underlying pixels — replacing the image XObject
                    // stream with a 1x1 transparent pixel — so the original bytes do
                    // NOT survive in the saved file (the NSA "Redacting with
                    // Confidence" failure class). Dropping only the Do would leave the
                    // image object recoverable with any extraction tool.
                    if (imageBboxIntersects()) {
                        if (currentMcid != -1) redactedMcids.insert(currentMcid);
                        // NF-2: Also neutralize any /SMask image referenced by this
                        // image XObject — an SMask can carry original pixel data that
                        // would survive if only the base image is neutralized.
                        auto& imgDict = xobj->GetDictionary();
                        auto* smaskRef = imgDict.FindKey("SMask");
                        if (smaskRef) {
                            PdfObject* smaskObj = smaskRef;
                            if (smaskObj->IsReference())
                                smaskObj = &document->GetObjects().MustGetObject(smaskObj->GetReference());
                            if (smaskObj && smaskObj->IsDictionary())
                                neutralizeImageXObject(*smaskObj);
                        }
                        neutralizeImageXObject(*xobj);
                        continue;   // drop the Do operator
                    }
                    // Non-intersecting image: emit the Do unchanged (falls through).
                } else if (subtypeName == "Form") {
                    // NF-2: Form XObject — recurse and pass the Form's own /Resources
                    // dict (if it has one) so that Do-name lookups inside the Form
                    // resolve against its local resource namespace.
                    PdfObject* formResources = nullptr;
                    if (xobj && xobj->IsDictionary()) {
                        auto* fres = xobj->GetDictionary().FindKey("Resources");
                        if (fres) {
                            formResources = fres;
                            if (formResources->IsReference())
                                formResources = &document->GetObjects().MustGetObject(formResources->GetReference());
                        }
                    }
                    // Fall back to the current canvas resources if the Form has none.
                    // NF-2 fix: pass ctm so the child recursion knows the page-space
                    // position where this Form XObject was placed (via `cm` before Do).
                    redactCanvasRecursively(*xobj, pdfRects, page, document, redactedMcids,
                                           formResources ? formResources : canvasResources,
                                           ctm, depth + 1);
                }
            }
            
            // Re-emit operands in ORIGINAL source order. PdfVariantStack's
            // begin()/end() iterate from the TOP of the operand stack (index 0 ==
            // last-pushed operand), so the previous forward range-for REVERSED the
            // operands of every multi-operand operator ("50 700 Td" was re-emitted
            // as "700 50 Td", "/F1 12 Tf" as "12 /F1 Tf"). That corrupted every
            // redacted content stream — text jumped to the wrong position and
            // Pdfium text extraction failed outright on the saved output. rbegin()
            // walks the stack bottom-up, i.e. the order the operands appeared in
            // the source stream.
            for (auto it = stack.rbegin(); it != stack.rend(); ++it) {
                std::string out;
                it->ToString(out);
                newStream << out << " ";
            }
            newStream << kw << "\n";
        }
    }
    
    if (canvasObj.HasStream()) {
        auto& stream = canvasObj.GetOrCreateStream();
        stream.SetData(newStream.str());
    } else {
        auto* contentsObj = page.GetContents();
        if (contentsObj) {
            contentsObj->Reset();
            if (contentsObj->GetObject().IsArray()) {
                auto& stream = contentsObj->CreateStreamForAppending();
                stream.SetData(newStream.str());
            } else {
                auto& stream = contentsObj->GetObject().GetOrCreateStream();
                stream.SetData(newStream.str());
            }
        }
    }
}

bool PoDoFoBackend::applyRedactions(int pageIndex, const QList<QRectF> &rects) {
    QMutexLocker locker(&d->mutex);
    if (!d->document || pageIndex < 0 || (unsigned)pageIndex >= d->document->GetPages().GetCount()) return false;

    try {
        // F-05: the audit log is OPT-IN and OFF by default. When co-located with
        // the output it leaked the redacted-region coordinates and a SHA-256 of
        // the UN-redacted source (a fingerprint that can confirm the original
        // content) right next to the redacted file under the source's default
        // ACL. We now only produce the log when the user explicitly enables it
        // (env GLYPHPDF_REDACTION_AUDIT=1), write it to a per-user app-data dir
        // rather than beside the source, and omit the pre-redaction hash and the
        // exact coordinates (only the region count is recorded).
        const bool auditLogEnabled = []() {
            const char* v = std::getenv("GLYPHPDF_REDACTION_AUDIT");
            return v && v[0] && v[0] != '0';
        }();

        PoDoFo::PdfPage& page = d->document->GetPages().GetPageAt(pageIndex);
        double pageHeight = page.GetMediaBox().Height;

        std::vector<PoDoFo::Rect> pdfRects;
        for (const auto& r : rects) {
            pdfRects.push_back(PoDoFo::Rect(r.x(), pageHeight - r.y() - r.height(), r.width(), r.height()));
        }

        std::set<int64_t> redactedMcids;
        auto* contentsObj = page.GetContents();
        bool streamFilterApplied = false;
        if (contentsObj) {
            PoDoFo::charbuff streamBuf;
            contentsObj->CopyTo(streamBuf);
            std::string streamStr(streamBuf.data(), streamBuf.size());

            bool hasInlineImage = (streamStr.find("\nID ") != std::string::npos
                                || streamStr.find("\nID\n") != std::string::npos
                                || streamStr.find(" ID ") != std::string::npos);
            bool hasBinaryContent = false;
            for (size_t i = 0; i < std::min(streamStr.size(), size_t(512)); ++i) {
                unsigned char c = static_cast<unsigned char>(streamStr[i]);
                if (c == 0 || (c < 9 && c != 0)) { hasBinaryContent = true; break; }
            }

            if (hasInlineImage || hasBinaryContent) {
                qWarning() << "Redaction: stream contains inline images or binary data on page"
                           << pageIndex << "— skipping content surgery, applying visual overlay only.";
            } else {
                redactCanvasRecursively(page.GetObject(), pdfRects, page, d->document.get(), redactedMcids);
                streamFilterApplied = true;
            }
        }

        if (!streamFilterApplied && contentsObj) {
            qCritical() << "SECURITY: Redaction on page" << pageIndex
                        << "failed to apply content stream surgery due to unparseable or binary content."
                           " Aborting operation to prevent insecure visual-only overlay.";
            return false;
        }

        // D3: Tagged PDF structure tree sanitization
        auto& catalog = d->document->GetCatalog();
        auto* structTreeRootObj = catalog.GetDictionary().FindKey("StructTreeRoot");
        if (structTreeRootObj && !redactedMcids.empty()) {
            if (structTreeRootObj->IsReference()) {
                structTreeRootObj = &d->document->GetObjects().MustGetObject(structTreeRootObj->GetReference());
            }
            if (structTreeRootObj->IsDictionary()) {
                auto& rootDict = structTreeRootObj->GetDictionary();
                auto* kKey = rootDict.FindKey("K");
                if (kKey) {
                    PoDoFo::PdfReference pageRef = page.GetObject().GetReference();
                    if (kKey->IsArray()) {
                        for (auto& kid : kKey->GetArray()) {
                            cleanStructElement(&kid, pageRef, redactedMcids, d->document.get());
                        }
                    } else {
                        cleanStructElement(kKey, pageRef, redactedMcids, d->document.get());
                    }
                }
            }
        }

        PoDoFo::PdfPainter painter;
        painter.SetCanvas(page);
        painter.GraphicsState.SetNonStrokingColor(PoDoFo::PdfColor(0.0, 0.0, 0.0));
        for (const auto& r : pdfRects) {
            painter.DrawRectangle(r.X, r.Y, r.Width, r.Height, PoDoFo::PdfPathDrawMode::Fill);
        }
        painter.FinishDrawing();

        // NF-2: Walk annotation /AP streams BEFORE removing annotations that
        // intersect the redaction rect.  An annotation's /AP (appearance) dictionary
        // can reference Form XObjects that in turn contain image XObjects.  Those
        // images must be neutralized so their bytes do not survive in the saved file.
        auto& annos = page.GetAnnotations();
        std::vector<unsigned> toRemove;
        for (unsigned i = 0; i < annos.GetCount(); ++i) {
            auto& anno = annos.GetAnnotAt(i);
            auto r = anno.GetRect();
            bool intersects = false;
            for (const auto& redRect : pdfRects) {
                if (r.X < (redRect.X + redRect.Width) && (r.X + r.Width) > redRect.X &&
                    r.Y < (redRect.Y + redRect.Height) && (r.Y + r.Height) > redRect.Y) {
                    intersects = true;
                    break;
                }
            }
            if (intersects) {
                // Walk /AP -> /N (normal appearance) Form XObject for image excision.
                auto& annoObj = anno.GetObject();
                if (annoObj.IsDictionary()) {
                    auto* apRef = annoObj.GetDictionary().FindKey("AP");
                    if (apRef) {
                        PoDoFo::PdfObject* apObj = apRef;
                        if (apObj->IsReference())
                            apObj = &d->document->GetObjects().MustGetObject(apObj->GetReference());
                        if (apObj && apObj->IsDictionary()) {
                            auto* nRef = apObj->GetDictionary().FindKey("N");
                            if (nRef) {
                                PoDoFo::PdfObject* nObj = nRef;
                                if (nObj->IsReference())
                                    nObj = &d->document->GetObjects().MustGetObject(nObj->GetReference());
                                if (nObj && nObj->IsDictionary() && nObj->HasStream()) {
                                    // /N is a Form XObject — recurse to neutralize images inside it.
                                    PoDoFo::PdfObject* apResources = nullptr;
                                    auto* apRes = nObj->GetDictionary().FindKey("Resources");
                                    if (apRes) {
                                        apResources = apRes;
                                        if (apResources->IsReference())
                                            apResources = &d->document->GetObjects().MustGetObject(apResources->GetReference());
                                    }
                                    redactCanvasRecursively(*nObj, pdfRects, page, d->document.get(),
                                                           redactedMcids, apResources);
                                }
                            }
                        }
                    }
                }
                toRemove.push_back(i);
            }
        }
        for (auto it = toRemove.rbegin(); it != toRemove.rend(); ++it) {
            annos.RemoveAnnotAt(*it);
        }

        // F-05: JSON audit log — OPT-IN, OFF by default. When enabled, write to a
        // per-user app-data location (NOT beside the source) and record only the
        // region COUNT plus the after-hash. No before_sha256 and no exact
        // coordinates, so the log cannot fingerprint the original or reveal what
        // was hidden where.
        if (auditLogEnabled && !d->currentFile.isEmpty()) {
            std::vector<char> afterBuffer;
            PoDoFo::VectorStreamDevice afterDevice(afterBuffer);
            d->document->Save(afterDevice);
            QByteArray afterHash = QCryptographicHash::hash(
                QByteArray(afterBuffer.data(), static_cast<int>(afterBuffer.size())),
                QCryptographicHash::Sha256).toHex();

            QString logDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
            if (logDir.isEmpty())
                logDir = QStandardPaths::writableLocation(QStandardPaths::AppConfigLocation);
            if (!logDir.isEmpty() && QDir().mkpath(logDir)) {
                QString logPath = QDir(logDir).filePath("redaction-audit.json");
                QJsonArray logArray;
                QFile logFile(logPath);
                if (logFile.exists() && logFile.open(QIODevice::ReadOnly)) {
                    QJsonDocument doc = QJsonDocument::fromJson(logFile.readAll());
                    if (doc.isArray()) {
                        logArray = doc.array();
                    }
                    logFile.close();
                }

                QJsonObject entry;
                entry["timestamp"] = QDateTime::currentDateTimeUtc().toString(Qt::ISODate);
                entry["page"] = pageIndex;
                // Identify the document by name only; do NOT store a hash of the
                // un-redacted source.
                entry["file"] = QFileInfo(d->currentFile).fileName();
                entry["region_count"] = static_cast<int>(rects.size());

                QJsonArray ops;
                ops.append("excised_text_operators");
                if (!redactedMcids.empty()) {
                    ops.append("scrubbed_structure_elements");
                }
                entry["operations"] = ops;
                entry["after_sha256"] = QString(afterHash);

                logArray.append(entry);

                if (logFile.open(QIODevice::WriteOnly)) {
                    logFile.write(QJsonDocument(logArray).toJson(QJsonDocument::Indented));
                    logFile.close();
                }
            }
        }

        return true;
    } catch (const PoDoFo::PdfError& e) {
        qCritical() << "SECURITY: Redaction failed on page" << pageIndex << "-" << e.what()
                    << "— document state may be inconsistent, do NOT save.";
        return false;
    } catch (const std::exception& e) {
        qCritical() << "SECURITY: General exception during redaction on page" << pageIndex << "-" << e.what();
        return false;
    } catch (...) {
        qCritical() << "SECURITY: Unknown exception during redaction on page" << pageIndex;
        return false;
    }
}

// ── E-1 repair (ledger row E-1-residual, commit fee597b) ─────────────────────
// Two writer gaps kept every exported PDF/A artifact from full conformance:
//   * 6.2.4.3-4 / 6.2.3.3-3 — exportPdfA wrote /OutputIntents with
//     /S GTS_PDFA1 but NO /DestOutputProfile, so veraPDF failed every
//     artifact's device-colour-space rule ("colour space is used without
//     output intent profile"; the fixtures' text uses the implicit default
//     DeviceGray fill): 6.2.4.3-4 under ISO 19005-2/3 (2B/2U/3B/3U),
//     6.2.3.3-3 under ISO 19005-1 (1B). Fix: embed an sRGB ICC profile
//     stream as /DestOutputProfile at EVERY level. ISO 19005-1 does not
//     mandate the profile for PDF/A-1B, but veraPDF's 6.2.3.3-3 fails the
//     implicit-DeviceGray fill when the output intent carries none
//     (observed pre-repair), and 19005-1 permits DestOutputProfile — so
//     the profile is attached for 1B too (probe-verified: 0 failed rules
//     at 1b and 2b once attached).
//   * 6.3.5-3 — PoDoFo 0.10.4 embeds standard-14 fonts as Type0/
//     CIDFontType0 subsets (FontFile3, CIDFontType0C) but never writes the
//     FontDescriptor /CIDSet that ISO 19005-1 6.3.5 requires; veraPDF
//     flagged "A CIDSet entry in the Font descriptor is missing or does
//     not correctly identify all glyphs present in the embedded font
//     subset and used for rendering" on every 1b export. Fix: derive the
//     exact CID population from the CIDFont's own /W array (PoDoFo emits
//     one width entry per CID in the subset — verified on a real export:
//     CIDs 0..10, W covers all 11) and write a complete CIDSet bit stream
//     (bit for CID n at byte n/8, bit 7-(n%8)).

// Deterministic minimal sRGB IEC61966-2.1 ICC profile, version 2.1
// (ICC.1:2001-10), matrix/TRC display profile ('mntr' / 'RGB ' / 'XYZ ').
// 500 bytes: 128-byte header + tag table of 9 tags (desc, cprt, wtpt,
// rXYZ, gXYZ, bXYZ, rTRC, gTRC, bTRC). Tone reproduction is the classic
// single-entry 'curv' form (g = 2.2, u8Fixed8) of the well-known minimal
// sRGB profiles; colorants are the IEC 61966-2-1 sRGB primaries
// Bradford-adapted to the D50 PCS:
//   wtpt 0.9642 1.0 0.8249 | rXYZ 0.4360 0.2225 0.0139
//   gXYZ 0.3851 0.7169 0.0971 | bXYZ 0.1431 0.0606 0.7141
// Validated before wiring: lcms2 (PIL ImageCms) opens it as
// "sRGB IEC61966-2.1" / RGB, and veraPDF 1.30.2 accepts it as the
// DestOutputProfile of real exported artifacts with 0 failed rules
// (probed at flavours 1b and 2b before this change was written).
static std::vector<unsigned char> buildSrgbIec6196621ProfileV2() {
    auto s15f16 = [](double v) -> uint32_t {
        return static_cast<uint32_t>(std::lround(v * 65536.0));
    };
    auto put32 = [](std::vector<unsigned char>& out, uint32_t v) {
        out.push_back(static_cast<unsigned char>(v >> 24));
        out.push_back(static_cast<unsigned char>(v >> 16));
        out.push_back(static_cast<unsigned char>(v >> 8));
        out.push_back(static_cast<unsigned char>(v));
    };
    auto putTagSig = [](std::vector<unsigned char>& out, const char* s) {
        out.insert(out.end(), s, s + 4);
    };

    // Tag payloads (each starts with its 4cc type signature + 4 reserved 0s).
    std::vector<unsigned char> desc; // textDescriptionType (ICC v2 form)
    {
        const char* name = "sRGB IEC61966-2.1";
        const uint32_t asciiLen = sizeof("sRGB IEC61966-2.1"); // text + NUL
        putTagSig(desc, "desc");
        put32(desc, 0);
        put32(desc, asciiLen);
        desc.insert(desc.end(), name, name + asciiLen);
        put32(desc, 0);                 // unicode language code
        put32(desc, 0);                 // unicode count
        desc.push_back(0);              // scriptcode code
        desc.push_back(0);              // scriptcode count
        desc.insert(desc.end(), 67, 0); // scriptcode description
    }
    std::vector<unsigned char> cprt; // textType
    {
        const char txt[] = "Public Domain"; // + trailing NUL per spec
        putTagSig(cprt, "text");
        put32(cprt, 0);
        cprt.insert(cprt.end(), txt, txt + sizeof(txt));
    }
    auto xyzTag = [&](double x, double y, double z) {
        std::vector<unsigned char> t;
        putTagSig(t, "XYZ ");
        put32(t, 0);
        put32(t, s15f16(x)); put32(t, s15f16(y)); put32(t, s15f16(z));
        return t;
    };
    auto curvTag = [&](double gamma) { // curveType, count=1 → u8Fixed8 gamma
        std::vector<unsigned char> t;
        putTagSig(t, "curv");
        put32(t, 0);
        put32(t, 1);
        const uint16_t g = static_cast<uint16_t>(std::lround(gamma * 256.0));
        t.push_back(static_cast<unsigned char>(g >> 8));
        t.push_back(static_cast<unsigned char>(g));
        return t;
    };

    std::vector<std::pair<const char*, std::vector<unsigned char>>> tags = {
        { "desc", std::move(desc) },
        { "cprt", std::move(cprt) },
        { "wtpt", xyzTag(0.9642, 1.0, 0.8249) },
        { "rXYZ", xyzTag(0.4360, 0.2225, 0.0139) },
        { "gXYZ", xyzTag(0.3851, 0.7169, 0.0971) },
        { "bXYZ", xyzTag(0.1431, 0.0606, 0.7141) },
        { "rTRC", curvTag(2.2) },
        { "gTRC", curvTag(2.2) },
        { "bTRC", curvTag(2.2) },
    };

    // Layout: 128-byte header, tag table (count + 12 bytes per tag),
    // payloads 4-byte aligned.
    const uint32_t headerSize = 128;
    uint32_t off = headerSize + 4u + static_cast<uint32_t>(12u * tags.size());
    std::vector<uint32_t> offsets;
    offsets.reserve(tags.size());
    for (const auto& t : tags) {
        off = (off + 3u) & ~3u;
        offsets.push_back(off);
        off += static_cast<uint32_t>(t.second.size());
    }
    const uint32_t total = (off + 3u) & ~3u;

    std::vector<unsigned char> out;
    out.reserve(total);
    put32(out, total);
    putTagSig(out, "none");        // preferred CMM: none
    put32(out, 0x02100000u);       // version 2.1.0
    putTagSig(out, "mntr");        // device class: colour display
    putTagSig(out, "RGB ");        // data colour space
    putTagSig(out, "XYZ ");        // PCS
    put32(out, 0); put32(out, 0); put32(out, 0); // creation date (unset)
    putTagSig(out, "acsp");        // profile signature
    put32(out, 0);                 // platform: none
    put32(out, 0);                 // flags: not embedded, usable standalone
    put32(out, 0);                 // device manufacturer: none
    put32(out, 0);                 // device model: none
    put32(out, 0); put32(out, 0);  // device attributes
    put32(out, 0);                 // rendering intent: perceptual
    put32(out, s15f16(0.9642));    // PCS illuminant: D50
    put32(out, s15f16(1.0));
    put32(out, s15f16(0.8249));
    put32(out, 0);                 // profile creator: none
    out.insert(out.end(), 44, 0);  // reserved — header totals 128 bytes
    Q_ASSERT(out.size() == headerSize);

    put32(out, static_cast<uint32_t>(tags.size()));
    for (size_t i = 0; i < tags.size(); ++i) {
        putTagSig(out, tags[i].first);
        put32(out, offsets[i]);
        put32(out, static_cast<uint32_t>(tags[i].second.size()));
    }
    for (size_t i = 0; i < tags.size(); ++i) {
        while (out.size() < offsets[i]) out.push_back(0);
        out.insert(out.end(), tags[i].second.begin(), tags[i].second.end());
    }
    while (out.size() < total) out.push_back(0);
    return out;
}

// E-1 (6.3.5-3): give every embedded composite-font subset a COMPLETE
// /CIDSet, derived from its own /W array. Pure gap-filler — a
// FontDescriptor that already carries a CIDSet is left untouched.
static void ensureCompleteCidSets(PoDoFo::PdfMemDocument& doc) {
    using namespace PoDoFo;
    auto& objects = doc.GetObjects();
    for (auto* objPtr : objects) {
        if (!objPtr || !objPtr->IsDictionary()) continue;
        const auto& obj = *objPtr;
        const auto* subtype = obj.GetDictionary().FindKey(PdfName("Subtype"));
        if (!subtype || !subtype->IsName() || subtype->GetName() != PdfName("Type0"))
            continue;
        const auto* descendants =
            obj.GetDictionary().FindKey(PdfName("DescendantFonts"));
        if (!descendants || !descendants->IsArray()) continue;
        for (const auto& dref : descendants->GetArray()) {
            PdfObject* desc = nullptr;
            if (dref.IsReference())
                desc = &objects.MustGetObject(dref.GetReference());
            else if (dref.IsDictionary())
                desc = const_cast<PdfObject*>(&dref);
            if (!desc || !desc->IsDictionary()) continue;
            const auto* wArr = desc->GetDictionary().FindKey(PdfName("W"));
            PdfObject* fd = desc->GetDictionary().FindKey(PdfName("FontDescriptor"));
            if (!wArr || !wArr->IsArray() || !fd || !fd->IsDictionary()) continue;
            if (fd->GetDictionary().HasKey(PdfName("CIDSet"))) continue;

            // /W is either "c [w1 w2 ...]" (start CID + one width per CID)
            // or "c1 c2 w" (inclusive range). Collect the CID population it
            // identifies.
            std::set<int64_t> cids;
            const PdfArray& w = wArr->GetArray();
            for (size_t i = 0; i < w.GetSize(); ++i) {
                const auto& a = w[i];
                if (!a.IsNumber()) continue;
                const int64_t c = a.GetNumber();
                if (i + 1 < w.GetSize() && w[i + 1].IsArray()) {
                    for (int64_t cid = c;
                         cid < c + static_cast<int64_t>(w[i + 1].GetArray().GetSize());
                         ++cid)
                        cids.insert(cid);
                    ++i;
                } else if (i + 2 < w.GetSize() && w[i + 1].IsNumber()
                           && w[i + 2].IsNumber() && w[i + 1].GetNumber() >= c) {
                    for (int64_t cid = c; cid <= w[i + 1].GetNumber(); ++cid)
                        cids.insert(cid);
                    i += 2;
                }
            }
            if (cids.empty()) continue;

            const int64_t maxCid = *cids.rbegin();
            std::vector<unsigned char> bits(
                static_cast<size_t>(maxCid / 8) + 1, 0);
            for (int64_t cid : cids)
                bits[static_cast<size_t>(cid) / 8] |=
                    static_cast<unsigned char>(0x80u >> (cid % 8));

            PdfObject& cidSetObj = objects.CreateDictionaryObject();
            cidSetObj.GetOrCreateStream().SetData(
                bufferview(reinterpret_cast<const char*>(bits.data()),
                           bits.size()));
            fd->GetDictionary().AddKeyIndirect(PdfName("CIDSet"), cidSetObj);
        }
    }
}

bool PoDoFoBackend::exportPdfA(const QString &outputPath, int conformanceLevel) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    try {
        using namespace PoDoFo;

        PdfALevel pdfaLevel;
        PdfVersion pdfVersion;
        // The complete level → (PdfALevel, base PDF version) mapping, in one
        // switch. The base version is fixed by each ISO 19005 part's base
        // standard and is NOT free: PDF/A-1 ← PDF 1.4 (ISO 19005-1), PDF/A-2
        // ← PDF 1.7 (ISO 19005-2 ← ISO 32000-1), PDF/A-3 ← PDF 1.7 (ISO
        // 19005-3 ← ISO 32000-1). PDF 2.0 is the PDF/A-4 family (ISO
        // 19005-4) — writing it under a PDF/A-3 identity produced artifacts
        // declaring a base standard the conformance level cannot have (N03).
        switch (conformanceLevel) {
            case 2:
                pdfaLevel = PdfALevel::L2B;
                pdfVersion = PdfVersion::V1_7;
                break;
            case 3:
                pdfaLevel = PdfALevel::L3B;
                pdfVersion = PdfVersion::V1_7;
                break;
            // §9.12 finding (TestBatchOpsCoverage): the batch combo offers
            // PDF/A-2U/3U; silently downgrading them to L1B was an
            // availability lie — map them for real.
            case 4:
                pdfaLevel = PdfALevel::L2U;
                pdfVersion = PdfVersion::V1_7;
                break;
            case 5:
                pdfaLevel = PdfALevel::L3U;
                pdfVersion = PdfVersion::V1_7;
                break;
            default:
                pdfaLevel = PdfALevel::L1B;
                pdfVersion = PdfVersion::V1_4;
                break;
        }

        auto& metadata = d->document->GetMetadata();
        metadata.SetPdfVersion(pdfVersion);
        metadata.SetPdfALevel(pdfaLevel);
        metadata.SetProducer(PdfString("PDF Workstation Pro (PoDoFo)"));
        metadata.SetCreator(PdfString("PDF Workstation Pro"));
        metadata.SyncXMPMetadata(true);

        auto& catalog = d->document->GetCatalog();
        auto& objects = d->document->GetObjects();
        auto& intentObj = objects.CreateDictionaryObject();
        intentObj.GetDictionary().AddKey(PdfName("Type"), PdfName("OutputIntent"));
        intentObj.GetDictionary().AddKey(PdfName("S"), PdfName("GTS_PDFA1"));
        intentObj.GetDictionary().AddKey(PdfName("OutputConditionIdentifier"), PdfString("sRGB IEC61966-2.1"));
        intentObj.GetDictionary().AddKey(PdfName("RegistryName"), PdfString("http://www.color.org"));
        intentObj.GetDictionary().AddKey(PdfName("Info"), PdfString("sRGB IEC61966-2.1"));

        auto& intentArrayObj = catalog.GetDictionary().AddKey(PdfName("OutputIntents"), PdfArray());
        intentArrayObj.GetArray().AddIndirect(intentObj);

        // E-1 (6.2.4.3-4 / 6.2.3.3-3): embed the output-intent ICC stream at
        // EVERY level. ISO 19005-1 does not REQUIRE a DestOutputProfile for
        // PDF/A-1B — but the fixtures' text draws with the implicit default
        // DeviceGray fill, and veraPDF's 6.2.3.3-3 fails any artifact using
        // DeviceGray whose output intent carries no DestOutputProfile
        // (observed pre-repair: "DeviceGray colour space is used without
        // output intent profile" on every flavour; verified post-probe:
        // attaching the sRGB ICC stream yields 0 failed rules at 1b AND 2b).
        // ISO 19005-1 permits (does not forbid) DestOutputProfile, so the
        // identifier-only 1B form was the gap, not the specified shape.
        // 2B/2U/3B/3U additionally fail 6.2.4.3-4 without it.
        {
            // Deterministic profile — built once per process.
            static const std::vector<unsigned char> srgbProfile =
                buildSrgbIec6196621ProfileV2();
            auto& iccObj = objects.CreateDictionaryObject();
            iccObj.GetDictionary().AddKey(PdfName("N"),
                                          PdfObject(static_cast<int64_t>(3)));
            iccObj.GetOrCreateStream().SetData(
                bufferview(reinterpret_cast<const char*>(srgbProfile.data()),
                           srgbProfile.size()));
            intentObj.GetDictionary().AddKeyIndirect(
                PdfName("DestOutputProfile"), iccObj);
        }

        // E-1 (6.3.5-3): complete /CIDSet on every embedded composite-font
        // subset (required under ISO 19005-1; harmless under 19005-2/3).
        ensureCompleteCidSets(*d->document);

        if (!writeUpdate(outputPath)) throw std::runtime_error("writeUpdate failed");
#ifdef QT_DEBUG
        qDebug() << "Successfully exported PDF/A-" << conformanceLevel << "b to:" << outputPath;
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        // E-05/E-12: security/compliance path — log unconditionally.
        qCritical() << "PoDoFoBackend::exportPdfA failed (PdfError):" << e.what()
                    << "path:" << outputPath;
        return false;
    } catch (const std::exception& e) {
        qCritical() << "PoDoFoBackend::exportPdfA failed:" << e.what()
                    << "path:" << outputPath;
        return false;
    }
}

bool PoDoFoBackend::encryptDocument(const QString &userPassword, const QString &ownerPassword,
                         const DocumentPermissions& permsStruct) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto perms = static_cast<PoDoFo::PdfPermissions>(0);
        if (permsStruct.print) perms = perms | PoDoFo::PdfPermissions::Print;
        if (permsStruct.printHighQuality) perms = perms | PoDoFo::PdfPermissions::HighPrint;
        if (permsStruct.copy) perms = perms | PoDoFo::PdfPermissions::Copy;
        if (permsStruct.modify) perms = perms | PoDoFo::PdfPermissions::Edit;
        if (permsStruct.annotate) perms = perms | PoDoFo::PdfPermissions::EditNotes;
        if (permsStruct.fillForms) perms = perms | PoDoFo::PdfPermissions::FillAndSign;
        if (permsStruct.accessibility) perms = perms | PoDoFo::PdfPermissions::Accessible;
        if (permsStruct.assemble) perms = perms | PoDoFo::PdfPermissions::DocAssembly;

        d->document->SetEncrypted(
            userPassword.toUtf8().constData(), 
            ownerPassword.toUtf8().constData(),
            perms,
            PoDoFo::PdfEncryptionAlgorithm::AESV3R6
        );
#ifdef QT_DEBUG
        qDebug() << "Applied AES-256 encryption to document.";
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        // E-05/E-12: encryption is security-critical — a failed SetEncrypted in
        // Release previously produced no log, only a silent boolean no-op.
        qCritical() << "PoDoFoBackend::encryptDocument failed:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::removeEncryption(const QString &ownerPassword) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        // First check if it's actually encrypted
        if (!d->document->IsEncrypted()) {
            return true; // Already decrypted
        }
        
        // Remove encryption
        d->document->SetEncrypt(nullptr);
#ifdef QT_DEBUG
        qDebug() << "Removed encryption from document.";
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error removing encryption:" << e.what();
        return false;
    }
}

// §9.13 P0 (reuse): the full hidden-data scrub shared by Sanitize Document
// and the Compress flow's "strip metadata" option. Operates in place on the
// document; saving is the caller's job.
static void sanitizeDocumentContents(PoDoFo::PdfMemDocument& doc)
{
    using namespace PoDoFo;

    auto& trailer = doc.GetTrailer();
    if (trailer.GetDictionary().HasKey("Info")) {
        trailer.GetDictionary().RemoveKey("Info");
    }

    auto& catalog = doc.GetCatalog();
    if (catalog.GetDictionary().HasKey(PdfName("Metadata"))) {
        catalog.GetDictionary().RemoveKey(PdfName("Metadata"));
    }
    if (catalog.GetDictionary().HasKey(PdfName("PieceInfo"))) {
        catalog.GetDictionary().RemoveKey(PdfName("PieceInfo"));
    }
    if (catalog.GetDictionary().HasKey(PdfName("MarkInfo"))) {
        catalog.GetDictionary().RemoveKey(PdfName("MarkInfo"));
    }
    if (catalog.GetDictionary().HasKey(PdfName("OutputIntents"))) {
        catalog.GetDictionary().RemoveKey(PdfName("OutputIntents"));
    }

    if (catalog.GetDictionary().HasKey(PdfName("Names"))) {
        auto* namesObj = catalog.GetDictionary().FindKey(PdfName("Names"));
        if (namesObj && namesObj->IsReference()) {
            namesObj = &doc.GetObjects().MustGetObject(namesObj->GetReference());
        }
        if (namesObj && namesObj->IsDictionary()) {
            auto& namesDict = namesObj->GetDictionary();
            if (namesDict.HasKey(PdfName("EmbeddedFiles"))) {
                namesDict.RemoveKey(PdfName("EmbeddedFiles"));
            }
            if (namesDict.HasKey(PdfName("JavaScript"))) {
                namesDict.RemoveKey(PdfName("JavaScript"));
            }
        }
    }

    if (catalog.GetDictionary().HasKey(PdfName("OpenAction"))) {
        catalog.GetDictionary().RemoveKey(PdfName("OpenAction"));
    }
    if (catalog.GetDictionary().HasKey(PdfName("AA"))) {
        catalog.GetDictionary().RemoveKey(PdfName("AA"));
    }

    // D5: Extended sanitization passes
    // 16. Structure Tree Root sanitization: recursively walk and remove Alt, ActualText, E from all elements
    auto* structTreeRootObj = catalog.GetDictionary().FindKey("StructTreeRoot");
    if (structTreeRootObj) {
        // §9.13 F3: depth cap — a crafted StructTreeRoot whose /K references
        // itself recursed without bound and exhausted the stack (same cyclic-
        // /K class as kMaxStructDepth in cleanStructElement).
        constexpr int kMaxSanitizeStructDepth = 64;
        std::function<void(PoDoFo::PdfObject*, int)> sanitizeAllStructElements =
            [&](PoDoFo::PdfObject* elem, int depth) {
            if (!elem || depth > kMaxSanitizeStructDepth) return;
            if (elem->IsReference()) {
                elem = &doc.GetObjects().MustGetObject(elem->GetReference());
            }
            if (!elem->IsDictionary()) return;

            auto& dict = elem->GetDictionary();
            if (dict.HasKey("ActualText")) dict.RemoveKey("ActualText");
            if (dict.HasKey("Alt")) dict.RemoveKey("Alt");
            if (dict.HasKey("E")) dict.RemoveKey("E");

            auto* kKey = dict.FindKey("K");
            if (kKey) {
                if (kKey->IsArray()) {
                    for (auto& kid : kKey->GetArray()) {
                        sanitizeAllStructElements(&kid, depth + 1);
                    }
                } else {
                    sanitizeAllStructElements(kKey, depth + 1);
                }
            }
        };
        sanitizeAllStructElements(structTreeRootObj, 0);
    }

    // 17. Flatten optional content layers by removing OCProperties
    if (catalog.GetDictionary().HasKey(PdfName("OCProperties"))) {
        catalog.GetDictionary().RemoveKey(PdfName("OCProperties"));
    }

    // 18. Remove Outlines (bookmarks)
    if (catalog.GetDictionary().HasKey(PdfName("Outlines"))) {
        catalog.GetDictionary().RemoveKey(PdfName("Outlines"));
    }

    // 20. Remove Collection portfolio
    if (catalog.GetDictionary().HasKey(PdfName("Collection"))) {
        catalog.GetDictionary().RemoveKey(PdfName("Collection"));
    }

    auto& pages = doc.GetPages();
    for (unsigned pi = 0; pi < pages.GetCount(); ++pi) {
        auto& pg = pages.GetPageAt(pi);
        if (pg.GetDictionary().HasKey(PdfName("AA"))) {
            pg.GetDictionary().RemoveKey(PdfName("AA"));
        }
        if (pg.GetDictionary().HasKey(PdfName("A"))) {
            pg.GetDictionary().RemoveKey(PdfName("A"));
        }
        if (pg.GetDictionary().HasKey(PdfName("PieceInfo"))) {
            pg.GetDictionary().RemoveKey(PdfName("PieceInfo"));
        }
        if (pg.GetDictionary().HasKey(PdfName("Thumb"))) {
            pg.GetDictionary().RemoveKey(PdfName("Thumb"));
        }
        if (pg.GetDictionary().HasKey(PdfName("Metadata"))) {
            pg.GetDictionary().RemoveKey(PdfName("Metadata"));
        }

        // Sanitize page annotations
        auto& annos = pg.GetAnnotations();
        std::vector<unsigned> toRemoveAnnos;
        for (unsigned ai = 0; ai < annos.GetCount(); ++ai) {
            auto& anno = annos.GetAnnotAt(ai);
            auto& dict = anno.GetDictionary();
            // 23. Remove annotation contents & rich text
            if (dict.HasKey("Contents")) dict.RemoveKey("Contents");
            if (dict.HasKey("RC")) dict.RemoveKey("RC");

            // 24. Strip dangerous annotation actions. Link/Widget annotations
            // carry actions in /A and additional actions in /AA. A /Launch,
            // /URI, /SubmitForm, /ImportData, /GoToR, /JavaScript, /Sound,
            // /Movie or /Rendition action is an exfiltration / code-exec
            // vector, so remove /A entirely for those. /AA is always removed
            // (it has no benign use in a sanitized document). Internal /GoTo
            // navigation is preserved.
            if (dict.HasKey("AA")) dict.RemoveKey("AA");
            auto* actionObj = dict.FindKey("A");
            if (actionObj) {
                PoDoFo::PdfObject* resolvedAction = actionObj;
                if (resolvedAction->IsReference())
                    resolvedAction = &doc.GetObjects().MustGetObject(resolvedAction->GetReference());
                bool dangerous = true; // default-deny: unknown action types are stripped
                if (resolvedAction && resolvedAction->IsDictionary()) {
                    auto* sObj = resolvedAction->GetDictionary().FindKey("S");
                    if (sObj && sObj->IsName()) {
                        const std::string s = std::string(sObj->GetName().GetString());
                        // Preserve only benign internal goto navigation. Everything
                        // else (Launch/URI/SubmitForm/ImportData/GoToR/JavaScript/
                        // Sound/Movie/Rendition/Named) is stripped.
                        if (s == "GoTo") dangerous = false;
                    }
                }
                if (dangerous) dict.RemoveKey("A");
            }

            // 19. Remove RichMedia, Movie, Screen annotations
            auto* subtypeObj = dict.FindKey("Subtype");
            if (subtypeObj && subtypeObj->IsName()) {
                std::string subtypeName = std::string(subtypeObj->GetName().GetString());
                if (subtypeName == "RichMedia" || subtypeName == "Screen" || subtypeName == "Movie") {
                    toRemoveAnnos.push_back(ai);
                }
            }
        }
        for (auto it = toRemoveAnnos.rbegin(); it != toRemoveAnnos.rend(); ++it) {
            annos.RemoveAnnotAt(*it);
        }
    }

    // 22. Clear AcroForm field values
    for (auto field : doc.GetFieldsIterator()) {
        auto& fieldDict = field->GetDictionary();
        if (fieldDict.HasKey("V")) fieldDict.RemoveKey("V");
        if (fieldDict.HasKey("DV")) fieldDict.RemoveKey("DV");
    }

    // 21. Trailer ID second element randomization
    // Re-fetch the trailer reference: `trailer` above was taken before
    // ~20 steps of document surgery. /ID entries are BINARY strings per
    // the PDF spec, so use PdfString::FromRaw — the text-string ctor
    // runs encoding validation over the random bytes, which is both
    // wrong semantically and was implicated in an intermittent crash
    // (AssertMutable AV on CI). Aligned quint32 buffer instead of a
    // reinterpret_cast over a char vector.
    {
        auto& trailerNow = doc.GetTrailer();
        auto* idObj = trailerNow.GetDictionary().FindKey("ID");
        if (idObj && idObj->IsArray()) {
            auto& idArr = idObj->GetArray();
            if (idArr.GetSize() >= 2) {
                quint32 randomWords[4];
                QRandomGenerator::system()->fillRange(randomWords, 4);
                idArr[1] = PdfObject(PdfString::FromRaw(
                    PoDoFo::bufferview(reinterpret_cast<const char*>(randomWords), 16)));
            }
        }
    }
}

bool PoDoFoBackend::sanitizeDocument(const QString &outputPath) {
    QMutexLocker locker(&d->mutex);
    if (!d->document || outputPath.isEmpty()) return false;

    const QFileInfo outputInfo(outputPath);
    if (!d->currentFile.isEmpty()) {
        const QFileInfo sourceInfo(d->currentFile);
        const QString sourcePath = sourceInfo.canonicalFilePath().isEmpty()
            ? sourceInfo.absoluteFilePath()
            : sourceInfo.canonicalFilePath();
        const QString targetPath = outputInfo.canonicalFilePath().isEmpty()
            ? outputInfo.absoluteFilePath()
            : outputInfo.canonicalFilePath();
        if (QString::compare(sourcePath, targetPath, Qt::CaseInsensitive) == 0) {
            qWarning() << "Refusing to sanitize in place:" << outputPath;
            return false;
        }
    }

    try {
        // §9.13 P0: single shared scrub implementation (see helper above).
        sanitizeDocumentContents(*d->document);

        const QString outputDir = outputInfo.absoluteDir().absolutePath();
        QString tempPath;
        {
            QTemporaryFile tempFile(outputDir + "/.sanitize_XXXXXX.pdf");
            tempFile.setAutoRemove(false);
            if (!tempFile.open()) {
                qWarning() << "Unable to create temporary sanitized output in:" << outputDir;
                return false;
            }
            tempPath = tempFile.fileName();
        }

        d->document->Save(tempPath.toUtf8().constData(), PoDoFo::PdfSaveOptions::Clean);

#ifdef HAS_QPDF
        try {
            qpdf_data pdf = qpdf_init();
            if (qpdf_read(pdf, tempPath.toUtf8().constData(), nullptr) == 0 &&
                qpdf_init_write(pdf, outputPath.toUtf8().constData()) == 0) {
                qpdf_set_stream_data_mode(pdf, qpdf_s_compress);
                if (qpdf_write(pdf) == 0) {
                    QFile::remove(tempPath);
                    qpdf_cleanup(&pdf);
                } else {
                    qpdf_cleanup(&pdf);
                    throw std::runtime_error("qpdf_write failed");
                }
            } else {
                qpdf_cleanup(&pdf);
                throw std::runtime_error("qpdf_read or qpdf_init_write failed");
            }
        } catch (const std::exception& e) {
            qWarning() << "QPDF sanitization rebuild failed, falling back to basic save:" << e.what();
            if (QFileInfo::exists(outputPath) && !QFile::remove(outputPath)) {
                QFile::remove(tempPath);
                return false;
            }
            if (!QFile::rename(tempPath, outputPath)) {
                QFile::remove(tempPath);
                return false;
            }
        }
#else
        if (QFileInfo::exists(outputPath) && !QFile::remove(outputPath)) {
            QFile::remove(tempPath);
            return false;
        }
        if (!QFile::rename(tempPath, outputPath)) {
            QFile::remove(tempPath);
            return false;
        }
#endif

#ifdef QT_DEBUG
        qDebug() << "Successfully sanitized document to:" << outputPath;
#endif
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "PoDoFo error during sanitize:" << e.what();
        return false;
    } catch (const std::exception& e) {
        qWarning() << "Error during sanitize:" << e.what();
        return false;
    }
}

namespace {

bool rewriteImageMatrix(PoDoFo::PdfPage& page, const std::string& xobjName,
                        double a, double b, double c, double d, double e, double f)
{
    auto* contentsObj = page.GetContents();
    if (!contentsObj) return false;
    
    PoDoFo::charbuff streamBuf;
    contentsObj->CopyTo(streamBuf);
    std::string content(streamBuf.data(), streamBuf.size());

    // Use PdfContentStreamReader to identify the cm->Do sequence
    PoDoFo::PdfContentStreamReader reader(page);
    PoDoFo::PdfContent pdfContent;
    
    // Track the last cm we saw; when we hit the target Do, we know which cm to replace
    int cmCount = 0;     // sequence number of cm operators
    int targetCmIdx = -1; // which cm to replace
    
    // First pass: identify which cm precedes our Do
    int lastCmIdx = -1;
    while (reader.TryReadNext(pdfContent)) {
        if (pdfContent.GetType() == PoDoFo::PdfContentType::Operator) {
            auto kw = pdfContent.GetKeyword();
            const auto& stack = pdfContent.GetStack();
            if (kw == "cm" && stack.size() >= 6) {
                lastCmIdx = cmCount;
                cmCount++;
            } else if (kw == "Do" && stack.size() >= 1) {
                std::string name(stack[0].GetName().GetString());
                if (name == xobjName && lastCmIdx >= 0) {
                    targetCmIdx = lastCmIdx;
                    break;
                }
            }
        }
    }
    
    if (targetCmIdx < 0) return false;
    
    // Second pass: find the Nth cm in raw content and replace it
    int currentCm = 0;
    size_t pos = 0;
    while (pos < content.size()) {
        // Find next " cm" or "\ncm" token
        size_t cmPos = content.find(" cm", pos);
        size_t cmPos2 = content.find("\ncm", pos);
        if (cmPos == std::string::npos && cmPos2 == std::string::npos) break;
        
        size_t foundPos;
        size_t cmEndOffset;
        if (cmPos != std::string::npos && (cmPos2 == std::string::npos || cmPos < cmPos2)) {
            foundPos = cmPos;
            cmEndOffset = 3; // " cm"
        } else {
            foundPos = cmPos2;
            cmEndOffset = 3; // "\ncm"
        }
        
        if (currentCm == targetCmIdx) {
            // Find the start of this cm line (the 6 numbers before it)
            size_t lineStart = content.rfind('\n', foundPos);
            if (lineStart == std::string::npos) lineStart = 0;
            else lineStart++;
            
            char buf[256];
            std::snprintf(buf, sizeof(buf), "%.6f %.6f %.6f %.6f %.6f %.6f cm",
                          a, b, c, d, e, f);
            content.replace(lineStart, foundPos + cmEndOffset - lineStart, buf);
            
            contentsObj->Reset();
            auto& stream = contentsObj->GetObject().GetOrCreateStream();
            stream.SetData(content);
            return true;
        }
        
        currentCm++;
        pos = foundPos + cmEndOffset;
    }
    
    return false;
}

} // anonymous namespace

QList<PdfImageInfo> PoDoFoBackend::listImages(int pageIndex) {
    QMutexLocker locker(&d->mutex);
    QList<PdfImageInfo> result;
    if (!d->document) return result;

    try {
        auto& pages = d->document->GetPages();
        if (pageIndex < 0 || static_cast<size_t>(pageIndex) >= pages.GetCount())
            return result;

        auto& page = pages.GetPageAt(pageIndex);
        auto resources = page.GetResources();

        auto* xobjectDict = resources.GetDictionary().FindKey("XObject");
        if (!xobjectDict || !xobjectDict->IsDictionary()) return result;

        struct XObjEntry { QString name; int w; int h; };
        QMap<QString, XObjEntry> imageXObjects;

        for (auto& kv : xobjectDict->GetDictionary()) {
            auto* obj = &kv.second;
            if (obj->IsReference())
                obj = &d->document->GetObjects().MustGetObject(obj->GetReference());
            if (!obj->IsDictionary()) continue;
            auto& dict = obj->GetDictionary();
            auto* subtype = dict.FindKey("Subtype");
            if (!subtype || subtype->GetName().GetString() != "Image") continue;

            XObjEntry entry;
            entry.name = QString::fromStdString(std::string(kv.first.GetString()));
            auto* widthObj = dict.FindKey("Width");
            auto* heightObj = dict.FindKey("Height");
            entry.w = widthObj && widthObj->IsNumber() ? static_cast<int>(widthObj->GetNumber()) : 0;
            entry.h = heightObj && heightObj->IsNumber() ? static_cast<int>(heightObj->GetNumber()) : 0;
            imageXObjects[entry.name] = entry;
        }

        if (imageXObjects.isEmpty()) return result;

        PoDoFo::PdfContentStreamReader reader(page);
        PoDoFo::PdfContent content;

        struct Matrix { double a,b,c,d,e,f; };
        Matrix ctm = {1,0,0,1,0,0};
        QList<Matrix> matrixStack;

        auto multiply = [](const Matrix& m1, const Matrix& m2) -> Matrix {
            return {
                m1.a*m2.a + m1.b*m2.c,
                m1.a*m2.b + m1.b*m2.d,
                m1.c*m2.a + m1.d*m2.c,
                m1.c*m2.b + m1.d*m2.d,
                m1.e*m2.a + m1.f*m2.c + m2.e,
                m1.e*m2.b + m1.f*m2.d + m2.f
            };
        };

        while (reader.TryReadNext(content)) {
            // Step-3 EC03 prerequisite (discovered by the round-trip test):
            // PoDoFo 1.x HANDLES a non-form XObject Do itself and reports it as
            // PdfContentType::DoXObject (name in content->Name) — it never
            // surfaces as a plain "Do" Operator on a page-based reader. The
            // Operator branch below alone therefore registered no image
            // placements at all, which left the whole §9.2 image-edit family
            // (list → move/resize/rotate/replace/delete) unable to see images.
            const bool imageDo = content.GetType() == PoDoFo::PdfContentType::DoXObject;
            if (imageDo || content.GetType() == PoDoFo::PdfContentType::Operator) {
                auto kw = content.GetKeyword();
                const auto& stack = content.GetStack();

                if (imageDo) {
                    QString name;
                    if (content->Name != nullptr)
                        name = QString::fromStdString(std::string(content->Name->GetString()));
                    else if (stack.size() >= 1)
                        name = QString::fromStdString(std::string(stack[0].GetName().GetString()));
                    if (imageXObjects.contains(name)) {
                        auto& entry = imageXObjects[name];
                        PdfImageInfo info;
                        info.pageIndex = pageIndex;
                        info.xobjectName = name;
                        double w = std::sqrt(ctm.a * ctm.a + ctm.b * ctm.b);
                        double h = std::sqrt(ctm.c * ctm.c + ctm.d * ctm.d);
                        double rot = std::atan2(ctm.b, ctm.a) * 180.0 / M_PI;
                        info.placement = QRectF(ctm.e, ctm.f, w, h);
                        info.rotation = rot;
                        info.widthPx = entry.w;
                        info.heightPx = entry.h;
                        result.append(info);
                    }
                } else if (kw == "q") {
                    matrixStack.append(ctm);
                } else if (kw == "Q" && !matrixStack.isEmpty()) {
                    ctm = matrixStack.takeLast();
                } else if (kw == "cm" && stack.size() >= 6) {
                    Matrix cm;
                    cm.a = stack[0].IsNumberOrReal() ? stack[0].GetReal() : 0;
                    cm.b = stack[1].IsNumberOrReal() ? stack[1].GetReal() : 0;
                    cm.c = stack[2].IsNumberOrReal() ? stack[2].GetReal() : 0;
                    cm.d = stack[3].IsNumberOrReal() ? stack[3].GetReal() : 0;
                    cm.e = stack[4].IsNumberOrReal() ? stack[4].GetReal() : 0;
                    cm.f = stack[5].IsNumberOrReal() ? stack[5].GetReal() : 0;
                    ctm = multiply(cm, ctm);
                }
            }
        }
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "listImages error:" << e.what();
    }
    return result;
}

bool PoDoFoBackend::moveImage(int pageIndex, const QString &xobjectName, double dx, double dy) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& page = d->document->GetPages().GetPageAt(pageIndex);
        
        PdfImageInfo* target = d->findImageByName(pageIndex, xobjectName, this);
        if (!target) return false;
        
        double radians = target->rotation * M_PI / 180.0;
        double w = target->placement.width();
        double h = target->placement.height();
        double newE = target->placement.x() + dx;
        double newF = target->placement.y() + dy;
        double cosR = std::cos(radians), sinR = std::sin(radians);
        
        bool ok = rewriteImageMatrix(page,
            xobjectName.toStdString(),
            w * cosR, w * sinR,
            -h * sinR, h * cosR,
            newE, newF);
        
        if (ok) if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return ok;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "moveImage error:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::resizeImage(int pageIndex, const QString &xobjectName, double newWidth, double newHeight) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& page = d->document->GetPages().GetPageAt(pageIndex);
        
        PdfImageInfo* target = d->findImageByName(pageIndex, xobjectName, this);
        if (!target) return false;
        
        double radians = target->rotation * M_PI / 180.0;
        double cosR = std::cos(radians), sinR = std::sin(radians);
        
        bool ok = rewriteImageMatrix(page,
            xobjectName.toStdString(),
            newWidth * cosR, newWidth * sinR,
            -newHeight * sinR, newHeight * cosR,
            target->placement.x(), target->placement.y());
        
        if (ok) if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return ok;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "resizeImage error:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::rotateImage(int pageIndex, const QString &xobjectName, double degrees) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& page = d->document->GetPages().GetPageAt(pageIndex);
        
        PdfImageInfo* target = d->findImageByName(pageIndex, xobjectName, this);
        if (!target) return false;
        
        double newRot = (target->rotation + degrees) * M_PI / 180.0;
        double w = target->placement.width();
        double h = target->placement.height();
        double cosR = std::cos(newRot), sinR = std::sin(newRot);
        
        double cx = target->placement.x() + w * std::cos(target->rotation * M_PI / 180.0) / 2.0;
        double cy = target->placement.y() + w * std::sin(target->rotation * M_PI / 180.0) / 2.0;
        double newE = cx - (w * cosR + h * (-sinR)) / 2.0;
        double newF = cy - (w * sinR + h * cosR) / 2.0;
        
        bool ok = rewriteImageMatrix(page,
            xobjectName.toStdString(),
            w * cosR, w * sinR,
            -h * sinR, h * cosR,
            newE, newF);
        
        if (ok) if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return ok;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "rotateImage error:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::replaceImage(int pageIndex, const QString &xobjectName, const QString &newImagePath) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& page = d->document->GetPages().GetPageAt(pageIndex);
        auto resources = page.GetResources();
        
        auto* xobjectDict = resources.GetDictionary().FindKey("XObject");
        if (!xobjectDict || !xobjectDict->IsDictionary()) return false;
        
        std::string name = xobjectName.toStdString();
        auto* xobjRef = xobjectDict->GetDictionary().FindKey(name);
        if (!xobjRef) return false;
        
        PoDoFo::PdfObject* xobj = xobjRef;
        if (xobj->IsReference())
            xobj = &d->document->GetObjects().MustGetObject(xobj->GetReference());
        
        QImage newImg(newImagePath);
        if (newImg.isNull()) return false;
        if (newImg.width() > 10000 || newImg.height() > 10000) {
            qCritical() << "SECURITY: Rejected replacement image exceeding max dimensions (10,000 x 10,000).";
            return false;
        }
        newImg = newImg.convertToFormat(QImage::Format_RGB888);
        
        auto& dict = xobj->GetDictionary();
        dict.AddKey("Width", PoDoFo::PdfObject(static_cast<int64_t>(newImg.width())));
        dict.AddKey("Height", PoDoFo::PdfObject(static_cast<int64_t>(newImg.height())));
        dict.AddKey("BitsPerComponent", PoDoFo::PdfObject(static_cast<int64_t>(8)));
        dict.AddKey("ColorSpace", PoDoFo::PdfName("DeviceRGB"));
        
        std::vector<char> rgbData;
        rgbData.reserve(static_cast<qint64>(newImg.width()) * newImg.height() * 3);
        for (int y = 0; y < newImg.height(); ++y) {
            const uchar* scanline = newImg.constScanLine(y);
            for (int x = 0; x < newImg.width(); ++x) {
                rgbData.push_back(static_cast<char>(scanline[x * 3 + 0]));
                rgbData.push_back(static_cast<char>(scanline[x * 3 + 1]));
                rgbData.push_back(static_cast<char>(scanline[x * 3 + 2]));
            }
        }
        
        auto& stream = xobj->GetOrCreateStream();
        stream.SetData(PoDoFo::bufferview(rgbData.data(), rgbData.size()));
        
        dict.RemoveKey("Filter");
        dict.RemoveKey("DecodeParms");
        
        if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "replaceImage error:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::deleteImage(int pageIndex, const QString &xobjectName) {
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;
    try {
        auto& page = d->document->GetPages().GetPageAt(pageIndex);
        
        // Validate the xobject exists in the page's content stream using the tokenizer
        {
            PoDoFo::PdfContentStreamReader reader(page);
            PoDoFo::PdfContent pdfContent;
            bool found = false;
            while (reader.TryReadNext(pdfContent)) {
                // EC03 (step-3 round-trip test): PoDoFo 1.x HANDLES a non-form
                // XObject Do itself and reports it as PdfContentType::DoXObject
                // (name in content->Name) — it never surfaces as a plain "Do"
                // Operator on a page-based reader. The Operator-only scan used
                // here left deleteImage unable to see any image placement, so
                // every deletion was refused. Same asymmetry, same fix as the
                // listImages scan; the plain-Operator branch stays as the
                // fallback (form-XObject draws still report as "Do").
                const bool imageDo = pdfContent.GetType() == PoDoFo::PdfContentType::DoXObject;
                if (imageDo || pdfContent.GetType() == PoDoFo::PdfContentType::Operator) {
                    QString name;
                    if (imageDo) {
                        if (pdfContent->Name != nullptr)
                            name = QString::fromStdString(std::string(pdfContent->Name->GetString()));
                        else if (pdfContent.GetStack().size() >= 1)
                            name = QString::fromStdString(std::string(pdfContent.GetStack()[0].GetName().GetString()));
                    } else if (pdfContent.GetKeyword() == "Do" && pdfContent.GetStack().size() >= 1) {
                        name = QString::fromStdString(std::string(pdfContent.GetStack()[0].GetName().GetString()));
                    }
                    if (name == xobjectName) {
                        found = true;
                        break;
                    }
                }
            }
            if (!found) return false;
        }
        
        auto* contentsObj = page.GetContents();
        if (!contentsObj) return false;
        
        PoDoFo::charbuff streamBuf;
        contentsObj->CopyTo(streamBuf);
        std::string content(streamBuf.data(), streamBuf.size());
        
        std::string doTarget = "/" + xobjectName.toStdString() + " Do";
        size_t doPos = content.find(doTarget);
        if (doPos == std::string::npos) return false;
        
        // Find enclosing q..Q block
        size_t qStart = content.rfind("\nq\n", doPos);
        if (qStart == std::string::npos) qStart = content.rfind("\nq ", doPos);
        size_t qEnd = content.find("\nQ", doPos);
        
        if (qStart != std::string::npos && qEnd != std::string::npos) {
            content.erase(qStart, (qEnd + 2) - qStart);
        } else {
            size_t lineStart = content.rfind('\n', doPos);
            size_t lineEnd = content.find('\n', doPos);
            if (lineStart != std::string::npos && lineEnd != std::string::npos)
                content.erase(lineStart, lineEnd - lineStart);
        }
        
        // EC03 round-trip fix: PdfContents::Reset() installs a fresh (initially
        // empty) ARRAY container, so GetObject() is an array and a direct
        // GetOrCreateStream() threw "Tried to get stream of non-dictionary
        // object" — the deletion was never persisted while the RESIDENT
        // content was already mutated (a half-mutation the viewer could show
        // but the file never carried). Write through both container shapes,
        // the same rule the redaction/annotation writers use.
        contentsObj->Reset();
        if (contentsObj->GetObject().IsArray()) {
            auto& stream = contentsObj->CreateStreamForAppending();
            stream.SetData(content);
        } else {
            auto& stream = contentsObj->GetObject().GetOrCreateStream();
            stream.SetData(content);
        }
        
        if (!writeUpdate(d->currentFile)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "deleteImage error:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::linearizeDocument(const QString &outputPath)
{
    QMutexLocker locker(&d->mutex);
#ifdef HAS_QPDF
    try {
        std::vector<char> buffer;
        if (d->document) {
            PoDoFo::VectorStreamDevice device(buffer);
            d->document->Save(device);
        } else if (!d->currentFile.isEmpty()) {
            QFile file(d->currentFile);
            if (file.open(QIODevice::ReadOnly)) {
                QByteArray data = file.readAll();
                buffer.assign(data.begin(), data.end());
            }
        }

        if (buffer.empty()) return false;

        qpdf_data pdf = qpdf_init();
        if (qpdf_read_memory(pdf, "input.pdf", buffer.data(), buffer.size(), nullptr) == 0 &&
            qpdf_init_write(pdf, outputPath.toUtf8().constData()) == 0) {
            qpdf_set_linearization(pdf, 1);
            if (qpdf_write(pdf) == 0) {
                qpdf_cleanup(&pdf);
#ifdef QT_DEBUG
                qDebug() << "QPDF API successfully linearized document to:" << outputPath;
#endif
                return true;
            }
        }
        qpdf_cleanup(&pdf);
        return false;
    } catch (const std::exception& e) {
        qWarning() << "QPDF linearization error:" << e.what();
        return false;
    }
#else
    Q_UNUSED(outputPath)
    qWarning() << "Linearization not available — built without qpdf";
    return false;
#endif
}

// ── M6-PROMPT-4 D3 helpers ──────────────────────────────────────────────────
namespace {

// Write the original Djot source into the annotation's private data dictionary
// at /PieceInfo /GlyphPDF /Private /DjotSource. ISO 32000-1 §14.5 reserves
// /PieceInfo for application-private data keyed by a registered prefix; we use
// "GlyphPDF". The Djot text is escaped via pdfEscapeLiteralString (the M1
// content-stream-injection-defence helper) before being stored as a PdfString,
// so no Djot byte can break out of the string object.
//
// This sidecar is what makes the GlyphPDF→PDF→GlyphPDF roundtrip lossless; it
// is never read by Acrobat/Foxit (they consume /Contents + /RC instead).
void writeDjotPieceInfo(PoDoFo::PdfMemDocument& doc,
                        PoDoFo::PdfDictionary& annotDict,
                        const QString& djotSource)
{
    if (djotSource.isEmpty()) return;

    // /PieceInfo << /GlyphPDF << /LastModified (D:...) /Private << ... >> >> >>
    auto& pieceInfoObj = doc.GetObjects().CreateDictionaryObject();
    auto& glyphObj     = doc.GetObjects().CreateDictionaryObject();
    auto& privateObj   = doc.GetObjects().CreateDictionaryObject();

    const std::string raw = djotSource.toUtf8().toStdString();
    privateObj.GetDictionary().AddKey("DjotSource", PoDoFo::PdfString(raw));

    QString stamp = QStringLiteral("D:") +
        QDateTime::currentDateTimeUtc().toString(QStringLiteral("yyyyMMddhhmmss")) +
        QStringLiteral("Z");
    glyphObj.GetDictionary().AddKey("LastModified",
        PoDoFo::PdfString(stamp.toStdString()));
    glyphObj.GetDictionary().AddKeyIndirect("Private", privateObj);

    pieceInfoObj.GetDictionary().AddKeyIndirect("GlyphPDF", glyphObj);
    annotDict.AddKeyIndirect("PieceInfo", pieceInfoObj);
}

// ── M6-P5 D2: review-state ↔ PDF /State name (ISO 32000 §12.5.6.4) ──────────
// The PDF Review state model uses the names Accepted / Rejected / Cancelled /
// Completed / None. We map our ReviewState::Open onto the spec name "None"
// (Acrobat's default "Open" review state) and keep the others verbatim. The
// inverse mapping in extractAnnotations restores the enum on reload.
static const char* reviewStateToPdfName(ReviewState s)
{
    switch (s) {
    case ReviewState::Accepted:  return "Accepted";
    case ReviewState::Rejected:  return "Rejected";
    case ReviewState::Cancelled: return "Cancelled";
    case ReviewState::Completed: return "Completed";
    case ReviewState::Open:      return "None";  // Acrobat "Open" == /State (None)
    default:                     return nullptr; // ReviewState::None → no /State key
    }
}

static ReviewState pdfNameToReviewState(const std::string& name)
{
    if (name == "Accepted")  return ReviewState::Accepted;
    if (name == "Rejected")  return ReviewState::Rejected;
    if (name == "Cancelled") return ReviewState::Cancelled;
    if (name == "Completed") return ReviewState::Completed;
    if (name == "None")      return ReviewState::Open;
    return ReviewState::None;
}

} // anonymous namespace

// AR-7 D1: helper — apply in-memory AnnotationItem list to any PdfMemDocument.
// Shared by the normal (backend-doc) and in-place (local-doc) paths.
static void applyAnnotationsToDoc(PoDoFo::PdfMemDocument& doc,
                                  const QList<AnnotationItem>& annotations)
{
    QMap<QString, PoDoFo::PdfObject*> idToObjectMap;
    QList<AnnotationItem> commentsToLink;

    QMap<int, QList<AnnotationItem>> pageAnnos;
    for (const auto& anno : annotations)
        pageAnnos[anno.pageIndex].append(anno);

    for (auto it = pageAnnos.constBegin(); it != pageAnnos.constEnd(); ++it) {
        int pageIdx = it.key();
        if (pageIdx < 0 || static_cast<unsigned>(pageIdx) >= doc.GetPages().GetCount()) continue;

        auto& page = doc.GetPages().GetPageAt(pageIdx);
        double pageHeight = page.GetMediaBox().Height;

        for (const auto& anno : it.value()) {
            QRectF bounds = anno.rect;
            if (anno.mode == ToolMode::DrawFreehand || anno.mode == ToolMode::AddSignature
                || gp::measure::isMeasureToolMode(anno.mode)) {
                if (!anno.points.isEmpty()) {
                    bounds = QRectF(anno.points.first(), anno.points.first());
                    for (const auto& p : anno.points) bounds = bounds.united(QRectF(p, p));
                }
            }
            PoDoFo::Rect pdfRect(bounds.x(), pageHeight - bounds.y() - bounds.height(), bounds.width(), bounds.height());

            PoDoFo::PdfAnnotationType annotType = PoDoFo::PdfAnnotationType::Text;
            if (anno.mode == ToolMode::Strikeout)  annotType = PoDoFo::PdfAnnotationType::StrikeOut;
            else if (anno.mode == ToolMode::Squiggly)  annotType = PoDoFo::PdfAnnotationType::Squiggly;
            else if (anno.mode == ToolMode::Underline) annotType = PoDoFo::PdfAnnotationType::Underline;
            else if (anno.mode == ToolMode::Highlight) annotType = PoDoFo::PdfAnnotationType::Highlight;
            else if (anno.mode == ToolMode::Stamp)     annotType = PoDoFo::PdfAnnotationType::Stamp;
            else if (anno.mode == ToolMode::Callout)   annotType = PoDoFo::PdfAnnotationType::FreeText;
            // §9.3 P0: shapes/freehand must persist as their REAL PDF subtypes
            // (/Square, /Circle, /Line, /Ink) — they used to fall through to
            // invisible Text notes, silently discarding visible work on save.
            else if (anno.mode == ToolMode::DrawRectangle) annotType = PoDoFo::PdfAnnotationType::Square;
            else if (anno.mode == ToolMode::DrawEllipse)   annotType = PoDoFo::PdfAnnotationType::Circle;
            else if (anno.mode == ToolMode::DrawLine || anno.mode == ToolMode::DrawArrow
                     || anno.mode == ToolMode::MeasureDistance)
                annotType = PoDoFo::PdfAnnotationType::Line;
            // T1 measurement: perimeter → /PolyLine, area → /Polygon. These are
            // the ISO 32000-1 subtypes whose dictionaries define /Measure and
            // /Vertices (Tables 175/178); /Square does NOT carry /Measure there,
            // so area rides /Polygon exactly like Acrobat's measure tools.
            else if (anno.mode == ToolMode::MeasurePerimeter)
                annotType = PoDoFo::PdfAnnotationType::PolyLine;
            else if (anno.mode == ToolMode::MeasureArea)
                annotType = PoDoFo::PdfAnnotationType::Polygon;
            else if (anno.mode == ToolMode::DrawFreehand || anno.mode == ToolMode::AddSignature)
                annotType = PoDoFo::PdfAnnotationType::Ink;
            // §9.7 P0: signature-picker Type/Upload modes persist as /Stamp
            // annotations carrying a real image appearance stream (below) —
            // the closest standard subtype to "a graphic placed on the page".
            else if (anno.mode == ToolMode::AddSignatureTyped || anno.mode == ToolMode::AddSignatureUpload)
                annotType = PoDoFo::PdfAnnotationType::Stamp;

            auto& annot = page.GetAnnotations().CreateAnnot(annotType, pdfRect);
            PoDoFo::PdfDictionary& dict = annot.GetDictionary();

            // /Contents + /RC + /PieceInfo (Djot dual-write, M6-P4 D3)
            const QString djot = !anno.djotSource.isEmpty() ? anno.djotSource : anno.text;
            if (!djot.isEmpty()) {
                const QString plain = !anno.djotSource.isEmpty()
                                          ? pdfws_djot::djotToPlainText(anno.djotSource)
                                          : anno.text;
                dict.AddKey("Contents", PoDoFo::PdfString(plain.toStdString()));
                if (!anno.djotSource.isEmpty()) {
                    const QString rc = pdfws_djot::djotToXhtml(anno.djotSource);
                    dict.AddKey("RC", PoDoFo::PdfString(rc.toStdString()));
                }
                writeDjotPieceInfo(doc, dict, anno.djotSource);
            }
            if (!anno.author.isEmpty())
                dict.AddKey("T", PoDoFo::PdfString(anno.author.toStdString()));
            if (!anno.creationDate.isEmpty()) {
                QString dateStr = "D:" + anno.creationDate;
                dict.AddKey("CreationDate", PoDoFo::PdfString(dateStr.toStdString()));
            }

            PoDoFo::PdfArray colorArr;
            colorArr.Add(anno.color.redF());
            colorArr.Add(anno.color.greenF());
            colorArr.Add(anno.color.blueF());
            dict.AddKey("C", colorArr);

            // §9.3 P0: subtype-specific geometry so the shapes survive save/reload.
            if (annotType == PoDoFo::PdfAnnotationType::Ink) {
                // /InkList: array of strokes; each stroke is an array of points
                // in PDF user space (y flipped to bottom-left origin).
                PoDoFo::PdfArray inkList;
                PoDoFo::PdfArray stroke;
                for (const auto& p : anno.points) {
                    stroke.Add(p.x());
                    stroke.Add(pageHeight - p.y());
                }
                inkList.Add(PoDoFo::PdfObject(stroke));
                dict.AddKey("InkList", inkList);
            } else if (annotType == PoDoFo::PdfAnnotationType::Line) {
                // /L: line endpoints [x1 y1 x2 y2] in PDF user space.
                QPointF p1 = bounds.topLeft();
                QPointF p2 = bounds.bottomRight();
                if (!anno.points.isEmpty()) {
                    p1 = anno.points.first();
                    p2  = anno.points.last();
                }
                PoDoFo::PdfArray lineArr;
                lineArr.Add(p1.x());
                lineArr.Add(pageHeight - p1.y());
                lineArr.Add(p2.x());
                lineArr.Add(pageHeight - p2.y());
                dict.AddKey("L", lineArr);
            } else if (annotType == PoDoFo::PdfAnnotationType::PolyLine
                       || annotType == PoDoFo::PdfAnnotationType::Polygon) {
                // T1 measurement: /Vertices is the flat [x0 y0 x1 y1 …] array in
                // PDF user space (PolyLine = open path, Polygon = closed shape).
                PoDoFo::PdfArray verts;
                for (const auto& p : anno.points) {
                    verts.Add(p.x());
                    verts.Add(pageHeight - p.y());
                }
                dict.AddKey("Vertices", verts);
            }

            // ── T1: ISO 32000-1 §12.9 measurement dictionary ────────────────
            // Verified against the ISO 32000-1:2008 text (Tables 261–263):
            //   /Subtype /RL (rectilinear), /R = REQUIRED human scale-ratio
            //   string, /X /D /A = number-format ARRAYS whose elements are
            //   << /U (unit) /C factor /D precision >> dictionaries. The first
            //   /X element's /C is real-units per default user space unit —
            //   exactly MeasureCore's unitsPerPt (spec example "/R (1in = 0.1
            //   mi)" ⇒ /C 0.00139 = 0.1/72). /A's factor converts from
            //   (largest X unit)²; we keep areas in the same unit family, so
            //   the factor is 1 and consumers square the X factor.
            // Every measurement carries its TRUE unit system: an uncalibrated
            // measurement is written with /C 1 and (pt) — never omitted, never
            // dressed up as a real-world claim (negative control contract).
            if (gp::measure::isMeasureToolMode(anno.mode)) {
                const char* intent = (anno.mode == ToolMode::MeasureDistance) ? "LineDimension"
                                   : (anno.mode == ToolMode::MeasurePerimeter) ? "PolyLineDimension"
                                                                               : "PolygonDimension";
                dict.AddKey("IT", PoDoFo::PdfName(intent));

                QString unit = anno.measureUnit.isEmpty() ? QStringLiteral("pt") : anno.measureUnit;
                QString areaUnit = anno.measureAreaUnit.isEmpty()
                    ? QStringLiteral("pt\u00B2") : anno.measureAreaUnit;
                double upp = anno.measureUnitsPerPt;
                const bool calibrated = anno.measureCalibrated
                    && std::isfinite(upp) && upp > 0.0 && !(unit == QStringLiteral("pt"));
                if (!calibrated) { upp = 1.0; unit = QStringLiteral("pt"); areaUnit = QStringLiteral("pt\u00B2"); }
                const QString ratio = anno.measureRatio.isEmpty()
                    ? (calibrated ? QStringLiteral("1 pt = %1 %2").arg(QString::number(upp, 'g', 6), unit)
                                  : QStringLiteral("1 pt = 1 pt"))
                    : anno.measureRatio;

                // One-element number-format array: << /U (unit) /C factor /D 100 >>
                // (/D 100 = hundredths precision per Table 263's default).
                auto numberFormat = [](const QString& label, double factor) {
                    PoDoFo::PdfArray arr;
                    PoDoFo::PdfDictionary fmt;
                    fmt.AddKey("U", PoDoFo::PdfString(label.toStdString()));
                    fmt.AddKey("C", PoDoFo::PdfObject(factor));
                    fmt.AddKey("D", PoDoFo::PdfObject(static_cast<int64_t>(100)));
                    arr.Add(PoDoFo::PdfObject(fmt));
                    return arr;
                };

                PoDoFo::PdfDictionary m;
                m.AddKey("Type", PoDoFo::PdfName("Measure"));
                m.AddKey("Subtype", PoDoFo::PdfName("RL"));
                m.AddKey("R", PoDoFo::PdfString(ratio.toStdString()));
                m.AddKey("X", numberFormat(unit, upp));       // real units per user-space unit
                m.AddKey("D", numberFormat(unit, 1.0));       // distances in the same unit
                m.AddKey("A", numberFormat(areaUnit, 1.0));   // areas: consumers square X's factor
                dict.AddKey("Measure", m);
            }

            // ── §9.7 P0: signature-picker Type/Upload image appearance ─────
            // The signature raster becomes a PDF image XObject (alpha kept via
            // an 8-bit /SMask), drawn by a form appearance stream that
            // letterboxes it inside the placed rect — the same math as
            // AnnotationLayer's fitInsideRect, so reload matches the screen.
            // /GlyphSigMode drives the inverse mapping in extractAnnotations;
            // other readers ignore the private key. A failure here must not
            // abort the save — the annot still persists, visibility degrades
            // to the gray-box AP written for image-less stamps below.
            const bool sigImageAnno =
                (anno.mode == ToolMode::AddSignatureTyped || anno.mode == ToolMode::AddSignatureUpload);
            bool sigImageApWritten = false;
            if (sigImageAnno) {
                dict.AddKey("GlyphSigMode",
                            PoDoFo::PdfName(anno.mode == ToolMode::AddSignatureTyped ? "Typed" : "Upload"));
                const QImage rgba = anno.image.convertToFormat(QImage::Format_RGBA8888);
                const int imgW = rgba.width();
                const int imgH = rgba.height();
                if (imgW > 0 && imgH > 0) {
                    try {
                        // Pack RGB24 + a separate alpha plane (replaceImage
                        // packs scanlines the same way — PdfImage has no
                        // stride-per-pixel concept for RGBA source buffers).
                        std::vector<char> rgb(static_cast<size_t>(imgW) * imgH * 3);
                        std::vector<char> alpha(static_cast<size_t>(imgW) * imgH);
                        for (int y = 0; y < imgH; ++y) {
                            const uchar *line = rgba.constScanLine(y);
                            for (int x = 0; x < imgW; ++x) {
                                const size_t o = static_cast<size_t>(y) * imgW + x;
                                rgb[o * 3 + 0] = static_cast<char>(line[x * 4 + 0]);
                                rgb[o * 3 + 1] = static_cast<char>(line[x * 4 + 1]);
                                rgb[o * 3 + 2] = static_cast<char>(line[x * 4 + 2]);
                                alpha[o]       = static_cast<char>(line[x * 4 + 3]);
                            }
                        }
                        auto image = doc.CreateImage();
                        image->SetData(PoDoFo::bufferview(rgb.data(), rgb.size()),
                                       static_cast<unsigned>(imgW), static_cast<unsigned>(imgH),
                                       PoDoFo::PdfPixelFormat::RGB24, imgW * 3);
                        auto mask = doc.CreateImage();
                        mask->SetData(PoDoFo::bufferview(alpha.data(), alpha.size()),
                                      static_cast<unsigned>(imgW), static_cast<unsigned>(imgH),
                                      PoDoFo::PdfPixelFormat::Grayscale, imgW);
                        image->SetSoftMask(*mask);

                        // §9.7: draw through PdfPainter — form contents and
                        // resource registration are painter-managed (the
                        // direct AddResource/GetOrCreateContentsStream APIs
                        // are private in PoDoFo 1.1).
                        const double W = bounds.width();
                        const double H = bounds.height();
                        const double scale = (W > 0.0 && H > 0.0)
                            ? std::min(W / imgW, H / imgH) : 1.0;
                        const double fw = imgW * scale;
                        const double fh = imgH * scale;
                        const double ox = (W - fw) / 2.0;
                        const double oy = (H - fh) / 2.0;
                        auto form = doc.CreateXObjectForm(
                            PoDoFo::Rect(0, 0, W, H));
                        {
                            PoDoFo::PdfPainter painter;
                            painter.SetCanvas(*form);
                            painter.DrawImage(*image, ox, oy, fw / imgW, fh / imgH);
                            painter.FinishDrawing();
                        }
                        annot.SetAppearanceStream(*form);
                        sigImageApWritten = true;
                    } catch (const std::exception &e) {
                        qWarning() << "signature image appearance stream:" << e.what();
                    }
                }
            }

            if (!anno.id.isEmpty()) {
                dict.AddKey("NM", PoDoFo::PdfString(anno.id.toStdString()));
                idToObjectMap[anno.id] = &annot.GetObject();
                if (!anno.parentId.isEmpty())
                    commentsToLink.append(anno);
                if (const char* stateName = reviewStateToPdfName(anno.reviewState)) {
                    dict.AddKey("State", PoDoFo::PdfString(stateName));
                    dict.AddKey("StateModel", PoDoFo::PdfString("Review"));
                }
            }

            // Appearance streams for Stamp / Callout / Strikeout / Squiggly —
            // and the gray-box fallback for signature-image annots whose image
            // was missing or failed to embed (§9.7: visible, never invisible).
            if (anno.mode == ToolMode::Stamp || anno.mode == ToolMode::Callout ||
                anno.mode == ToolMode::Strikeout || anno.mode == ToolMode::Squiggly ||
                (sigImageAnno && !sigImageApWritten)) {
                auto& streamObj = doc.GetObjects().CreateDictionaryObject();
                streamObj.GetDictionary().AddKey("Type", PoDoFo::PdfName("XObject"));
                streamObj.GetDictionary().AddKey("Subtype", PoDoFo::PdfName("Form"));
                PoDoFo::PdfArray bboxArray;
                bboxArray.Add(PoDoFo::PdfObject(static_cast<int64_t>(0)));
                bboxArray.Add(PoDoFo::PdfObject(static_cast<int64_t>(0)));
                bboxArray.Add(PoDoFo::PdfObject(static_cast<int64_t>(bounds.width())));
                bboxArray.Add(PoDoFo::PdfObject(static_cast<int64_t>(bounds.height())));
                streamObj.GetDictionary().AddKey("BBox", bboxArray);
                std::string streamContent;
                if (anno.mode == ToolMode::Strikeout) {
                    double midY = bounds.height() / 2.0;
                    streamContent = std::to_string(anno.color.redF()) + " " +
                                    std::to_string(anno.color.greenF()) + " " +
                                    std::to_string(anno.color.blueF()) + " RG\n";
                    streamContent += "1 w\n0 " + std::to_string(midY) + " m\n" +
                                     std::to_string(bounds.width()) + " " + std::to_string(midY) + " l\nS\n";
                } else if (anno.mode == ToolMode::Squiggly) {
                    streamContent = std::to_string(anno.color.redF()) + " " +
                                    std::to_string(anno.color.greenF()) + " " +
                                    std::to_string(anno.color.blueF()) + " RG\n";
                    streamContent += "1 w\n0 2 m\n";
                    for (double x = 2; x < bounds.width(); x += 2)
                        streamContent += std::to_string(x) + " " +
                                         (std::fmod(x, 4) == 0 ? "0" : "4") + " l\n";
                    streamContent += "S\n";
                } else {
                    streamContent = "0.8 0.8 0.8 rg\n0 0 " + std::to_string(bounds.width()) + " " +
                                    std::to_string(bounds.height()) + " re\nf\n";
                    if (!anno.text.isEmpty())
                        streamContent += "0 0 0 rg\nBT\n/Helv 12 Tf\n2 " +
                                         std::to_string(bounds.height() - 14) + " Td\n(" +
                                         pdfEscapeLiteralString(anno.text) + ") Tj\nET\n";
                }
                streamObj.GetOrCreateStream().SetData(
                    PoDoFo::bufferview(streamContent.data(), streamContent.size()));
                dict.AddKey("AP", PoDoFo::PdfDictionary());
                auto* apDict = dict.FindKey("AP");
                apDict->GetDictionary().AddKey("N", streamObj.GetIndirectReference());
            }
        }
    }

    // /IRT linking pass (M6-P5 D2)
    for (const auto& anno : commentsToLink) {
        if (idToObjectMap.contains(anno.id) && idToObjectMap.contains(anno.parentId)) {
            PoDoFo::PdfObject* childObj  = idToObjectMap[anno.id];
            PoDoFo::PdfObject* parentObj = idToObjectMap[anno.parentId];
            childObj->GetDictionary().AddKeyIndirect("IRT", *parentObj);
            childObj->GetDictionary().AddKey("RT", PoDoFo::PdfName("R"));
        }
    }
}

bool PoDoFoBackend::embedAnnotations(const QString &inputPath, const QString &outputPath, const QList<AnnotationItem> &annotations)
{
    QMutexLocker locker(&d->mutex);
    try {
        // AR-7 D1: In-place save (inputPath == outputPath). The previous
        // dedicated branch loaded a separate local PdfMemDocument and swapped
        // the result in with a raw QFile::remove + QFile::rename — a boundary
        // OUTSIDE the SafeSave coordination, so any handle held on the
        // destination (the viewer's QPdfDocument, or this backend's own
        // resident parser device) turned the remove into "cannot remove
        // original for in-place replace" and the save failed even though the
        // document was perfectly writable (ARC03 close-with-save repro).
        // The embed now routes through the SAME choke point as every other
        // same-path write: resolveDocument + writeUpdate — unsigned documents
        // take the saveDocument transaction (unique candidate → validation →
        // same-file re-seat closes the parser device → SafeSave commit, whose
        // coordinator parks/restores the viewer handle), and signed documents
        // keep the coordination-scoped SaveUpdate append that preserves every
        // /ByteRange. A failed replacement leaves the original byte-identical;
        // there is deliberately no remove-then-rename fallback.
        auto& doc = d->resolveDocument(inputPath);
        applyAnnotationsToDoc(doc, annotations);
        if (!writeUpdate(outputPath)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error embedding annotations:" << e.what();
        return false;
    } catch (const std::exception& e) {
        // resolveDocument() / writeUpdate() raise std::runtime_error; never let it escape
        // to terminate() (was the 0xc0000409 crash in TestAnnotationDjot).
        qWarning() << "Error embedding annotations:" << e.what();
        return false;
    }
}

// ── M6-PROMPT-4 D4: load annotations back from a PDF ────────────────────────
QList<AnnotationItem> PoDoFoBackend::extractAnnotations(const QString &inputPath)
{
    QList<AnnotationItem> result;
    try {
        PoDoFo::PdfMemDocument doc;
        doc.Load(inputPath.toUtf8().constData());

        // PoDoFo 1.1.0 PdfString::GetString() returns std::string_view.
        auto svToQString = [](std::string_view sv) {
            return QString::fromUtf8(sv.data(), static_cast<int>(sv.size()));
        };

        const unsigned pageCount = doc.GetPages().GetCount();
        for (unsigned p = 0; p < pageCount; ++p) {
            auto& page = doc.GetPages().GetPageAt(p);
            const double pageHeight = page.GetMediaBox().Height;
            auto& annos = page.GetAnnotations();
            const unsigned annoCount = annos.GetCount();

            for (unsigned a = 0; a < annoCount; ++a) {
                auto& annot = annos.GetAnnotAt(a);
                const PoDoFo::PdfDictionary& dict = annot.GetDictionary();

                AnnotationItem item;
                item.pageIndex = static_cast<int>(p);

                // ── Subtype → ToolMode (inverse of embedAnnotations) ──────────
                item.mode = ToolMode::AddComment;
                // T1: /Measure (or a dimension /IT intent) marks a measurement
                // annotation. Without it, plain shape annots keep their legacy
                // mapping — a DrawLine from §9.3 must never become a measure.
                bool hasMeasure = dict.FindKey("Measure") != nullptr;
                QString intentName;
                if (const auto* it = dict.FindKey("IT"); it && it->IsName())
                    intentName = QString::fromLatin1(it->GetName().GetString().data(),
                                                     static_cast<int>(it->GetName().GetString().size()));
                const bool dimensionIntent = intentName == QLatin1String("LineDimension")
                    || intentName == QLatin1String("PolyLineDimension")
                    || intentName == QLatin1String("PolygonDimension");
                if (const auto* sub = dict.FindKey("Subtype")) {
                    if (sub->IsName()) {
                        const std::string s{sub->GetName().GetString()};
                        if      (s == "StrikeOut") item.mode = ToolMode::Strikeout;
                        else if (s == "Squiggly")  item.mode = ToolMode::Squiggly;
                        else if (s == "Underline") item.mode = ToolMode::Underline;
                        else if (s == "Highlight") item.mode = ToolMode::Highlight;
                        else if (s == "Stamp") {
                            item.mode = ToolMode::Stamp;
                            // §9.7 P0: signature-picker Type/Upload annots are
                            // /Stamp with a /GlyphSigMode marker; map them back
                            // to their real tools. Other writers never set it.
                            if (const auto* gk = dict.FindKey("GlyphSigMode")) {
                                if (gk->IsName()) {
                                    const std::string gs{gk->GetName().GetString()};
                                    if (gs == "Typed")  item.mode = ToolMode::AddSignatureTyped;
                                    if (gs == "Upload") item.mode = ToolMode::AddSignatureUpload;
                                }
                            }
                        }
                        else if (s == "FreeText")  item.mode = ToolMode::Callout;
                        else if (s == "Text")      item.mode = ToolMode::AddComment;
                        // §9.3 P0: real shape/ink subtypes round-trip to their
                        // original tools instead of degrading to comments.
                        else if (s == "Square")    item.mode = ToolMode::DrawRectangle;
                        else if (s == "Circle")    item.mode = ToolMode::DrawEllipse;
                        else if (s == "Line")      item.mode = ToolMode::DrawLine;
                        else if (s == "Ink")       item.mode = ToolMode::DrawFreehand;

                        // ── T1: measurement identity (verified ISO 32000-1
                        // carriers: /Line, /PolyLine, /Polygon with /Measure).
                        if (hasMeasure || dimensionIntent) {
                            if (s == "Line")     item.mode = ToolMode::MeasureDistance;
                            if (s == "PolyLine") item.mode = ToolMode::MeasurePerimeter;
                            if (s == "Polygon")  item.mode = ToolMode::MeasureArea;
                        }
                    }
                }

                // ── Rect (PDF bottom-left origin → top-left QRectF) ───────────
                if (const auto* rectObj = dict.FindKey("Rect")) {
                    if (rectObj->IsArray()) {
                        const auto& arr = rectObj->GetArray();
                        if (arr.size() == 4) {
                            if (!arr[0].IsNumberOrReal() || !arr[1].IsNumberOrReal() ||
                                !arr[2].IsNumberOrReal() || !arr[3].IsNumberOrReal())
                                continue;
                            const double x0 = arr[0].GetReal();
                            const double y0 = arr[1].GetReal();
                            const double x1 = arr[2].GetReal();
                            const double y1 = arr[3].GetReal();
                            const double w = x1 - x0;
                            const double h = y1 - y0;
                            item.rect = QRectF(x0, pageHeight - y1, w, h);
                        }
                    }
                }

                // ── §9.3 P0: shape/ink geometry round-trip ────────────────────
                if (item.mode == ToolMode::DrawFreehand) {
                    if (const auto* ink = dict.FindKey("InkList")) {
                        if (ink->IsArray() && !ink->GetArray().IsEmpty()) {
                            const auto& strokeObj = ink->GetArray()[0];
                            if (strokeObj.IsArray()) {
                                const auto& pts = strokeObj.GetArray();
                                for (size_t k = 0; k + 1 < pts.size(); k += 2) {
                                    if (pts[k].IsNumberOrReal() && pts[k+1].IsNumberOrReal())
                                        item.points.append(QPointF(pts[k].GetReal(),
                                                                   pageHeight - pts[k+1].GetReal()));
                                }
                            }
                        }
                    }
                } else if (item.mode == ToolMode::DrawLine || item.mode == ToolMode::MeasureDistance) {
                    if (const auto* l = dict.FindKey("L")) {
                        if (l->IsArray() && l->GetArray().size() == 4) {
                            const auto& ln = l->GetArray();
                            if (ln[0].IsNumberOrReal() && ln[1].IsNumberOrReal() &&
                                ln[2].IsNumberOrReal() && ln[3].IsNumberOrReal()) {
                                item.points.append(QPointF(ln[0].GetReal(), pageHeight - ln[1].GetReal()));
                                item.points.append(QPointF(ln[2].GetReal(), pageHeight - ln[3].GetReal()));
                            }
                        }
                    }
                } else if (item.mode == ToolMode::MeasurePerimeter
                           || item.mode == ToolMode::MeasureArea) {
                    // T1: /Vertices is the flat [x0 y0 x1 y1 …] array (Table 178).
                    if (const auto* v = dict.FindKey("Vertices")) {
                        if (v->IsArray()) {
                            const auto& pts = v->GetArray();
                            for (size_t k = 0; k + 1 < pts.size(); k += 2) {
                                if (pts[k].IsNumberOrReal() && pts[k+1].IsNumberOrReal())
                                    item.points.append(QPointF(pts[k].GetReal(),
                                                               pageHeight - pts[k+1].GetReal()));
                            }
                        }
                    }
                }

                // ── T1: restore the ISO 32000-1 /Measure calibration ─────────
                // /X[0]/C is the real-units-per-user-space-unit factor; /A[0]/U
                // the area unit label; /R the human scale text. Malformed input
                // degrades to the truthful uncalibrated-pt defaults.
                if (const auto* mo = dict.FindKey("Measure"); mo && mo->IsDictionary()) {
                    const PoDoFo::PdfDictionary& md = mo->GetDictionary();
                    const PoDoFo::PdfObject* xArr = md.FindKey("X");
                    if (xArr && xArr->IsArray() && !xArr->GetArray().IsEmpty()) {
                        const PoDoFo::PdfObject& x0 = xArr->GetArray()[0];
                        if (x0.IsDictionary()) {
                            if (const PoDoFo::PdfObject* c = x0.GetDictionary().FindKey("C");
                                c && c->IsNumberOrReal())
                                item.measureUnitsPerPt = c->GetReal();
                            if (const PoDoFo::PdfObject* u = x0.GetDictionary().FindKey("U");
                                u && u->IsString())
                                item.measureUnit = svToQString(u->GetString().GetString());
                        }
                    }
                    if (const PoDoFo::PdfObject* aArr = md.FindKey("A");
                        aArr && aArr->IsArray() && !aArr->GetArray().IsEmpty()) {
                        const PoDoFo::PdfObject& a0 = aArr->GetArray()[0];
                        if (a0.IsDictionary()) {
                            if (const PoDoFo::PdfObject* u = a0.GetDictionary().FindKey("U");
                                u && u->IsString())
                                item.measureAreaUnit = svToQString(u->GetString().GetString());
                        }
                    }
                    if (const PoDoFo::PdfObject* r = md.FindKey("R"); r && r->IsString())
                        item.measureRatio = svToQString(r->GetString().GetString());

                    if (!(item.measureUnitsPerPt > 0.0) || !std::isfinite(item.measureUnitsPerPt))
                        item.measureUnitsPerPt = 1.0;
                    // The negative control, inverted: C==1 with the pt label IS
                    // the uncalibrated scale — report it as such, nothing more.
                    item.measureCalibrated = !(item.measureUnitsPerPt == 1.0
                                               && item.measureUnit == QLatin1String("pt"));
                    if (item.measureUnit.isEmpty())
                        item.measureUnit = QStringLiteral("pt");
                    if (item.measureAreaUnit.isEmpty())
                        item.measureAreaUnit = QStringLiteral("pt\u00B2");
                }

                // ── §9.7 P0: restore the signature raster from the appearance ─
                // The AP form's /Resources /XObject "Im0" is the image we
                // embedded (DeviceRGB + 8-bit /SMask). Untrusted input is
                // handled defensively: dimensions are sanity-capped and any
                // mismatch simply leaves item.image null (the layer then paints
                // its dashed placeholder — the annot itself still round-trips).
                if (item.mode == ToolMode::AddSignatureTyped || item.mode == ToolMode::AddSignatureUpload) {
                    auto resolveObj = [&doc](const PoDoFo::PdfObject *obj)
                        -> const PoDoFo::PdfObject * {
                        while (obj && obj->IsReference())
                            obj = doc.GetObjects().GetObject(obj->GetReference());
                        return obj;
                    };
                    if (const PoDoFo::PdfObject *apObj = resolveObj(
                            annot.GetAppearanceStream(PoDoFo::PdfAppearanceType::Normal))) {
                        if (apObj->IsDictionary()) {
                            const PoDoFo::PdfObject *res =
                                resolveObj(apObj->GetDictionary().FindKey("Resources"));
                            const PoDoFo::PdfObject *xobjs =
                                res && res->IsDictionary()
                                    ? resolveObj(res->GetDictionary().FindKey("XObject"))
                                    : nullptr;
                            // The embedded signature raster is the AP form's
                            // image XObject — writers name the resource key
                            // differently (our painter picks its own name,
                            // other viewers arbitrary), so scan for the first
                            // entry whose target is /Subtype /Image instead of
                            // hardcoding a key.
                            const PoDoFo::PdfObject *imgObj = nullptr;
                            if (xobjs && xobjs->IsDictionary()) {
                                for (const auto &entry : xobjs->GetDictionary()) {
                                    const PoDoFo::PdfObject *cand =
                                        resolveObj(&entry.second);
                                    if (cand && cand->IsDictionary()) {
                                        const PoDoFo::PdfObject *st =
                                            cand->GetDictionary().FindKey("Subtype");
                                        if (st && st->IsName()
                                            && st->GetName().GetString() == "Image") {
                                            imgObj = cand;
                                            break;
                                        }
                                    }
                                }
                            }
                            if (imgObj && imgObj->IsDictionary()) {
                                const PoDoFo::PdfDictionary &idict = imgObj->GetDictionary();
                                const auto num = [&idict](const char *key) -> int64_t {
                                    if (const PoDoFo::PdfObject *o = idict.FindKey(key);
                                        o && o->IsNumber())
                                        return o->GetNumber();
                                    return 0;
                                };
                                const int64_t imgW = num("Width");
                                const int64_t imgH = num("Height");
                                const int64_t bpc  = num("BitsPerComponent");
                                // Defensive caps: extraction parses untrusted
                                // files; never allocate for absurd dimensions.
                                if (imgW > 0 && imgH > 0 && imgW <= 10000 && imgH <= 10000 && bpc == 8) {
                                    try {
                                        const PoDoFo::charbuff rgb = imgObj->GetStream()->GetCopy();
                                        if (rgb.size() == static_cast<size_t>(imgW) * imgH * 3) {
                                            QImage restored(static_cast<int>(imgW),
                                                            static_cast<int>(imgH),
                                                            QImage::Format_RGBA8888);
                                            for (int y = 0; y < static_cast<int>(imgH); ++y) {
                                                uchar *dst = restored.scanLine(y);
                                                std::copy(rgb.data() + static_cast<size_t>(y) * imgW * 3,
                                                          rgb.data() + static_cast<size_t>(y + 1) * imgW * 3,
                                                          dst);
                                                for (int x = 0; x < static_cast<int>(imgW); ++x)
                                                    dst[x * 4 + 3] = 255;  // opaque until /SMask says otherwise
                                            }
                                            if (const PoDoFo::PdfObject *smObj =
                                                    resolveObj(idict.FindKey("SMask"))) {
                                                if (smObj->IsDictionary()) {
                                                    const PoDoFo::charbuff alpha =
                                                        smObj->GetStream()->GetCopy();
                                                    if (alpha.size() == static_cast<size_t>(imgW) * imgH) {
                                                        for (int y = 0; y < static_cast<int>(imgH); ++y) {
                                                            uchar *dst = restored.scanLine(y);
                                                            for (int x = 0; x < static_cast<int>(imgW); ++x)
                                                                dst[x * 4 + 3] =
                                                                    static_cast<uchar>(alpha[static_cast<size_t>(y) * imgW + x]);
                                                        }
                                                    }
                                                }
                                            }
                                            item.image = restored;
                                        }
                                    } catch (const std::exception &e) {
                                        qWarning() << "signature image restore:" << e.what();
                                    }
                                }
                            }
                        }
                    }
                }

                // ── /Contents → plain-text fallback ───────────────────────────
                QString contents;
                if (const auto* cObj = dict.FindKey("Contents")) {
                    if (cObj->IsString())
                        contents = svToQString(cObj->GetString().GetString());
                }
                item.text = contents;

                // ── Identity / author / dates ─────────────────────────────────
                if (const auto* nm = dict.FindKey("NM"))
                    if (nm->IsString())
                        item.id = svToQString(nm->GetString().GetString());
                if (const auto* t = dict.FindKey("T"))
                    if (t->IsString())
                        item.author = svToQString(t->GetString().GetString());
                if (const auto* cd = dict.FindKey("CreationDate"))
                    if (cd->IsString())
                        item.creationDate = svToQString(cd->GetString().GetString());

                // ── djotSource restore: /PieceInfo /GlyphPDF /Private/DjotSource
                // takes priority; else derive a trivial djotSource from the
                // plain-text /Contents (D4). ──────────────────────────────────
                QString djotSource;
                if (const auto* pieceInfo = dict.FindKey("PieceInfo")) {
                    if (pieceInfo->IsDictionary()) {
                        if (const auto* glyph = pieceInfo->GetDictionary().FindKey("GlyphPDF")) {
                            if (glyph->IsDictionary()) {
                                if (const auto* priv = glyph->GetDictionary().FindKey("Private")) {
                                    if (priv->IsDictionary()) {
                                        if (const auto* ds = priv->GetDictionary().FindKey("DjotSource")) {
                                            if (ds->IsString()) {
                                                djotSource = QString::fromUtf8(
                                                    ds->GetString().GetString().data(),
                                                    static_cast<int>(ds->GetString().GetString().size()));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                // Fall back to trivial djotSource derived from plain text.
                item.djotSource = djotSource.isEmpty() ? contents : djotSource;

                // ── M6-P5 D2: review state ← /State (StateModel Review) ────────
                if (const auto* st = dict.FindKey("State")) {
                    if (st->IsString())
                        item.reviewState =
                            pdfNameToReviewState(std::string(st->GetString().GetString()));
                }

                // ── M6-P5 D2: thread parent ← /IRT → parent /NM ────────────────
                // /IRT is an indirect reference to the parent annotation; its
                // /NM carries the parent id we stored on save. FindKey resolves
                // the reference, so we read the parent's /NM directly.
                if (const auto* irt = dict.FindKey("IRT")) {
                    if (irt->IsDictionary()) {
                        if (const auto* pnm = irt->GetDictionary().FindKey("NM")) {
                            if (pnm->IsString())
                                item.parentId = svToQString(pnm->GetString().GetString());
                        }
                    }
                }

                result.append(item);
            }
        }

        // ── M6-P5 D2: rebuild parent.replies from the restored parentId links
        // so the in-memory thread model is symmetric after a reload (mirrors
        // what the composer maintains when replies are authored live). ────────
        QMap<QString, int> idToIndex;
        for (int i = 0; i < result.size(); ++i)
            if (!result[i].id.isEmpty())
                idToIndex.insert(result[i].id, i);
        for (const auto& child : result) {
            if (child.parentId.isEmpty()) continue;
            auto it = idToIndex.constFind(child.parentId);
            if (it != idToIndex.constEnd() && !child.id.isEmpty()
                && !result[it.value()].replies.contains(child.id)) {
                result[it.value()].replies.append(child.id);
            }
        }
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error extracting annotations:" << e.what();
    }
    return result;
}

// ── §9.1 P0: clickable link annotations (URI + internal GoTo) ──────────────
QList<PdfLinkInfo> PoDoFoBackend::extractLinks(const QString &inputPath, int pageIndex)
{
    QList<PdfLinkInfo> links;
    try {
        PoDoFo::PdfMemDocument doc;
        doc.Load(inputPath.toUtf8().constData());
        if (pageIndex < 0 || static_cast<unsigned>(pageIndex) >= doc.GetPages().GetCount())
            return links;

        auto& page = doc.GetPages().GetPageAt(pageIndex);
        const double pageHeight = page.GetMediaBox().Height;
        auto& annos = page.GetAnnotations();

        auto resolveDestPage = [&](const PoDoFo::PdfObject* dest) -> int {
            // /Dest arrays look like [pageRef /XYZ x y z]; the page ref is
            // element 0. Named destinations are not resolved here.
            if (!dest || !dest->IsArray() || dest->GetArray().GetSize() < 1)
                return -1;
            const auto& first = dest->GetArray()[0];
            if (!first.IsReference()) return -1;
            const PoDoFo::PdfObject* target =
                &doc.GetObjects().MustGetObject(first.GetReference());
            if (!target || !target->IsDictionary()) return -1;
            auto& pages = doc.GetPages();
            for (unsigned i = 0; i < pages.GetCount(); ++i)
                if (&pages.GetPageAt(i).GetObject() == target)
                    return static_cast<int>(i);
            return -1;
        };

        for (unsigned a = 0; a < annos.GetCount(); ++a) {
            auto& annot = annos.GetAnnotAt(a);
            const PoDoFo::PdfDictionary& dict = annot.GetDictionary();
            auto* sub = dict.FindKey("Subtype");
            if (!sub || !sub->IsName()
                || std::string(sub->GetName().GetString()) != "Link")
                continue;

            PdfLinkInfo info;
            if (const auto* rectObj = dict.FindKey("Rect"); rectObj && rectObj->IsArray()) {
                const auto& r = rectObj->GetArray();
                if (r.GetSize() == 4 && r[0].IsNumberOrReal() && r[1].IsNumberOrReal()
                    && r[2].IsNumberOrReal() && r[3].IsNumberOrReal()) {
                    const double x0 = r[0].GetReal(), y0 = r[1].GetReal();
                    const double x1 = r[2].GetReal(), y1 = r[3].GetReal();
                    info.rect = QRectF(x0, pageHeight - y1, x1 - x0, y1 - y0);
                }
            }
            if (!info.rect.isValid()) continue;

            // Action-based link (/A): URI or GoTo.
            if (const auto* aObj = dict.FindKey("A")) {
                const PoDoFo::PdfObject* action = aObj;
                if (action->IsReference())
                    action = &doc.GetObjects().MustGetObject(action->GetReference());
                if (action && action->IsDictionary()) {
                    auto& ad = action->GetDictionary();
                    auto* s = ad.FindKey("S");
                    if (s && s->IsName()) {
                        const std::string stype(s->GetName().GetString());
                        if (stype == "URI") {
                            if (auto* uri = ad.FindKey("URI"); uri && uri->IsString()) {
                                info.isUri = true;
                                info.uri = QString::fromUtf8(uri->GetString().GetString().data(),
                                                             static_cast<int>(uri->GetString().GetString().size()));
                            }
                        } else if (stype == "GoTo") {
                            info.targetPage = resolveDestPage(ad.FindKey("D"));
                        }
                    }
                }
            }
            // Direct destination (/Dest) when there is no /A GoTo.
            if (!info.isUri && info.targetPage < 0)
                info.targetPage = resolveDestPage(dict.FindKey("Dest"));

            if (info.isUri || info.targetPage >= 0)
                links.append(info);
        }
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "extractLinks error:" << e.what();
    }
    return links;
}

// ── Watermarking (Session 13) ──────────────────────────────────────────────

bool PoDoFoBackend::addTextWatermark(const TextWatermarkOptions &options)
{
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    try {
        auto& doc = *d->document;
        unsigned int pageCount = doc.GetPages().GetCount();
        int from = (options.pageFrom < 0) ? 0 : options.pageFrom;
        int to = (options.pageTo < 0) ? static_cast<int>(pageCount) - 1 : options.pageTo;
        to = qMin(to, static_cast<int>(pageCount) - 1);

        // Create a shared ExtGState for transparency
        auto& gsObj = doc.GetObjects().CreateDictionaryObject();
        gsObj.GetDictionary().AddKey("Type", PoDoFo::PdfName("ExtGState"));
        gsObj.GetDictionary().AddKey("ca", static_cast<double>(options.opacity));
        gsObj.GetDictionary().AddKey("CA", static_cast<double>(options.opacity));

        // §9.11 P0: honor the user-selected font family instead of hard-coding
        // Helvetica. Resolve order: installed/system font matching the family,
        // then the PDF base-14 font of the same name (the WatermarkDialog offers
        // exactly these PS names), then Helvetica — same fallback shape as
        // addHeaderFooter.
        constexpr const char* kFontResource = "GS_WM_Font";
        std::string fontName = options.fontFamily.isEmpty() ? "Helvetica"
                                                            : options.fontFamily.toStdString();
        const PoDoFo::PdfFont* font = doc.GetFonts().SearchFont(fontName);
        if (!font) {
            // Map base-14 PostScript names to PoDoFo's guaranteed standard-14 set.
            using S14 = PoDoFo::PdfStandard14FontType;
            static const std::unordered_map<std::string, S14> kBase14 = {
                {"Helvetica", S14::Helvetica},          {"Courier", S14::Courier},
                {"Times-Roman", S14::TimesRoman},       {"Symbol", S14::Symbol},
                {"ZapfDingbats", S14::ZapfDingbats},
            };
            auto it = kBase14.find(fontName);
            if (it != kBase14.end()) {
                font = &doc.GetFonts().GetStandard14Font(it->second);
            }
        }
        if (!font) {
            fontName = "Helvetica";
            font = &doc.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        }

        for (int i = from; i <= to; ++i) {
            auto& page = doc.GetPages().GetPageAt(i);
            PoDoFo::Rect mediaBox = page.GetMediaBox();
            double pw = mediaBox.Width;
            double ph = mediaBox.Height;

            // Register the ExtGState in the page resources
            auto* resDict = page.GetDictionary().FindKey("Resources");
            if (!resDict) {
                page.GetDictionary().AddKey("Resources", PoDoFo::PdfDictionary());
                resDict = page.GetDictionary().FindKey("Resources");
            }
            auto* gsDict = resDict->GetDictionary().FindKey("ExtGState");
            if (!gsDict) {
                resDict->GetDictionary().AddKey("ExtGState", PoDoFo::PdfDictionary());
                gsDict = resDict->GetDictionary().FindKey("ExtGState");
            }
            gsDict->GetDictionary().AddKeyIndirect("GS_WM", gsObj);

            // Use PdfPainter to draw the watermark text
            PoDoFo::PdfPainter painter;
            painter.SetCanvas(page);

            painter.TextState.SetFont(*font, static_cast<float>(options.fontSize));
            painter.GraphicsState.SetNonStrokingColor(PoDoFo::PdfColor(
                options.color.redF(), options.color.greenF(), options.color.blueF()));

            // Build the content manually for ExtGState + rotation
            // We need to inject raw operators since PdfPainter doesn't expose ExtGState directly
            painter.FinishDrawing();

            double cx = pw / 2.0;
            double cy = ph / 2.0;
            double radians = options.rotationDeg * M_PI / 180.0;
            double cosA = std::cos(radians);
            double sinA = std::sin(radians);

            std::ostringstream wm;
            wm << "q\n";
            wm << "/GS_WM gs\n";
            wm << "BT\n";
            wm << "/" << kFontResource << " " << options.fontSize << " Tf\n";
            wm << options.color.redF() << " " << options.color.greenF() << " " << options.color.blueF() << " rg\n";
            wm << cosA << " " << sinA << " " << -sinA << " " << cosA << " " << cx << " " << cy << " Tm\n";
            // §9.11 P0: center using real glyph advances, not a char-count estimate.
            const QByteArray wmUtf8 = options.text.toUtf8();
            PoDoFo::PdfTextState ts;
            ts.Font = font;
            ts.FontSize = static_cast<double>(options.fontSize);
            const double textWidth = font->GetStringLength(wmUtf8.constData(), ts);
            wm << -(textWidth / 2.0) << " " << -(options.fontSize / 2.0) << " Td\n";
            wm << "(" << pdfEscapeLiteralString(options.text) << ") Tj\n";
            wm << "ET\n";
            wm << "Q\n";

            // Register the resolved watermark font in page fonts (§9.11 P0).
            ensureStandardFontResource(doc, page, kFontResource, fontName);

            appendPageContent(doc, page, wm.str());
        }

        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error adding text watermark:" << e.what();
        return false;
    }
}

bool PoDoFoBackend::addImageWatermark(const ImageWatermarkOptions &options)
{
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    try {
        auto& doc = *d->document;
        unsigned int pageCount = doc.GetPages().GetCount();
        int from = (options.pageFrom < 0) ? 0 : options.pageFrom;
        int to = (options.pageTo < 0) ? static_cast<int>(pageCount) - 1 : options.pageTo;
        to = qMin(to, static_cast<int>(pageCount) - 1);

        // Load the image as a QImage for raw pixel data
        QImage img(options.imagePath);
        if (img.isNull()) {
            qWarning() << "addImageWatermark: failed to load image" << options.imagePath;
            return false;
        }
        if (img.width() > 10000 || img.height() > 10000) {
            qCritical() << "SECURITY: Rejected watermark image exceeding max dimensions (10,000 x 10,000).";
            return false;
        }
        img = img.convertToFormat(QImage::Format_RGB888);

        // Create image XObject
        auto& imgObj = doc.GetObjects().CreateDictionaryObject();
        imgObj.GetDictionary().AddKey("Type", PoDoFo::PdfName("XObject"));
        imgObj.GetDictionary().AddKey("Subtype", PoDoFo::PdfName("Image"));
        imgObj.GetDictionary().AddKey("Width", static_cast<int64_t>(img.width()));
        imgObj.GetDictionary().AddKey("Height", static_cast<int64_t>(img.height()));
        imgObj.GetDictionary().AddKey("ColorSpace", PoDoFo::PdfName("DeviceRGB"));
        imgObj.GetDictionary().AddKey("BitsPerComponent", static_cast<int64_t>(8));

        // Write raw RGB data to stream
        QByteArray rawData;
        rawData.reserve(static_cast<qint64>(img.width()) * img.height() * 3);
        for (int y = 0; y < img.height(); ++y) {
            const uchar *line = img.constScanLine(y);
            rawData.append(reinterpret_cast<const char*>(line), img.width() * 3);
        }
        PoDoFo::charbuff imgBuf(std::string_view(rawData.constData(), rawData.size()));
        imgObj.GetOrCreateStream().SetData(imgBuf);

        // Create ExtGState for opacity
        auto& gsObj = doc.GetObjects().CreateDictionaryObject();
        gsObj.GetDictionary().AddKey("Type", PoDoFo::PdfName("ExtGState"));
        gsObj.GetDictionary().AddKey("ca", static_cast<double>(options.opacity));
        gsObj.GetDictionary().AddKey("CA", static_cast<double>(options.opacity));

        for (int i = from; i <= to; ++i) {
            auto& page = doc.GetPages().GetPageAt(i);
            PoDoFo::Rect mediaBox = page.GetMediaBox();
            double pw = mediaBox.Width;
            double ph = mediaBox.Height;

            // Register resources
            auto* resDict = page.GetDictionary().FindKey("Resources");
            if (!resDict) {
                page.GetDictionary().AddKey("Resources", PoDoFo::PdfDictionary());
                resDict = page.GetDictionary().FindKey("Resources");
            }
            auto* xobjDict = resDict->GetDictionary().FindKey("XObject");
            if (!xobjDict) {
                resDict->GetDictionary().AddKey("XObject", PoDoFo::PdfDictionary());
                xobjDict = resDict->GetDictionary().FindKey("XObject");
            }
            xobjDict->GetDictionary().AddKeyIndirect("WM_Img", imgObj);

            auto* gsDict = resDict->GetDictionary().FindKey("ExtGState");
            if (!gsDict) {
                resDict->GetDictionary().AddKey("ExtGState", PoDoFo::PdfDictionary());
                gsDict = resDict->GetDictionary().FindKey("ExtGState");
            }
            gsDict->GetDictionary().AddKeyIndirect("GS_WMI", gsObj);

            // Calculate placement
            double imgW = pw * options.scale;
            double imgH = imgW * (static_cast<double>(img.height()) / img.width());
            double x = 0, y = 0;

            switch (options.position) {
            case ImageWatermarkOptions::Center:
                x = (pw - imgW) / 2.0;
                y = (ph - imgH) / 2.0;
                break;
            case ImageWatermarkOptions::TopLeft:
                x = 20; y = ph - imgH - 20;
                break;
            case ImageWatermarkOptions::TopRight:
                x = pw - imgW - 20; y = ph - imgH - 20;
                break;
            case ImageWatermarkOptions::BottomLeft:
                x = 20; y = 20;
                break;
            case ImageWatermarkOptions::BottomRight:
                x = pw - imgW - 20; y = 20;
                break;
            case ImageWatermarkOptions::Tile: {
                // Tile: handled below with multiple draw calls
                x = 0; y = 0;
                break;
            }
            }

            // Build content stream operators
            std::ostringstream ops;
            ops << "q\n";
            ops << "/GS_WMI gs\n";

            if (options.position == ImageWatermarkOptions::Tile) {
                double tileSpacingX = imgW * 1.5;
                double tileSpacingY = imgH * 1.5;
                for (double ty = 0; ty < ph; ty += tileSpacingY) {
                    for (double tx = 0; tx < pw; tx += tileSpacingX) {
                        ops << imgW << " 0 0 " << imgH << " " << tx << " " << ty << " cm\n";
                        ops << "/WM_Img Do\n";
                        // Reset CTM for next tile
                        ops << "Q\nq\n/GS_WMI gs\n";
                    }
                }
            } else {
                ops << imgW << " 0 0 " << imgH << " " << x << " " << y << " cm\n";
                ops << "/WM_Img Do\n";
            }
            ops << "Q\n";

            // Append to existing content stream
            auto* contentsObj = page.GetContents();
            if (!contentsObj) {
                auto& newContents = doc.GetObjects().CreateDictionaryObject();
                page.GetDictionary().AddKeyIndirect("Contents", newContents);
                contentsObj = page.GetContents();
            }

            std::string existingStream;
            if (contentsObj->GetObject().IsArray()) {
                auto& arr = contentsObj->GetObject().GetArray();
                for (size_t idx = 0; idx < arr.GetSize(); ++idx) {
                    auto& ref = arr[idx];
                    if (ref.IsReference()) {
                        auto& partObj = doc.GetObjects().MustGetObject(ref.GetReference());
                        if (partObj.IsDictionary() && partObj.HasStream()) {
                            PoDoFo::charbuff buf;
                            partObj.GetOrCreateStream().CopyTo(buf);
                            existingStream.append(buf.data(), buf.size());
                            existingStream.append("\n");
                        }
                    }
                }
            } else if (contentsObj->GetObject().IsDictionary() && contentsObj->GetObject().HasStream()) {
                PoDoFo::charbuff buf;
                contentsObj->GetObject().GetOrCreateStream().CopyTo(buf);
                existingStream.assign(buf.data(), buf.size());
            }
            std::string newStream = existingStream + "\n" + ops.str();
            PoDoFo::charbuff newBuf(newStream);
            contentsObj->GetObject().GetOrCreateStream().SetData(newBuf);
        }

        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error adding image watermark:" << e.what();
        return false;
    }
}

// ── Optimization (Session 13) ──────────────────────────────────────────────

// §9.13 P1: read-only reachability walk mirroring the mark phase of PoDoFo's
// PdfIndirectObjectList::CollectGarbage — collect everything transitively
// referenced from the trailer (/Root → page tree, /Contents, /Resources incl.
// XObjects, /Annots, AcroForm, /StructTreeRoot, /Outlines, /Names — anything
// reachable arrives here through the object graph). Returns the sum of RAW
// (encoded) stream byte sizes over all UNREACHABLE objects: exactly the bytes
// a garbage-collecting save drops from the output. Raw bytes match the image
// accounting above — CopyTo(raw) cannot expand media filters and would throw
// on JPEG payloads. An estimate must never mutate the document, so this does
// NOT sweep; it only measures.
static qint64 unreachableStreamBytes(PoDoFo::PdfMemDocument &doc)
{
    auto& objects = doc.GetObjects();
    std::set<PoDoFo::PdfReference> reachable;
    std::vector<PoDoFo::PdfObject*> stack;
    stack.push_back(&doc.GetTrailer().GetObject());
    while (!stack.empty()) {
        PoDoFo::PdfObject* o = stack.back();
        stack.pop_back();
        if (o == nullptr) continue;
        if (o->IsReference()) {
            // Mark indirect targets once; cycles and shared objects terminate.
            if (!reachable.insert(o->GetReference()).second) continue;
            PoDoFo::PdfObject* target = objects.GetObject(o->GetReference());
            if (target) stack.push_back(target);
            continue;
        }
        if (o->IsDictionary()) {
            for (auto& kv : o->GetDictionary())
                stack.push_back(&kv.second);
        } else if (o->IsArray()) {
            for (auto& v : o->GetArray())
                stack.push_back(&v);
        }
    }

    qint64 garbage = 0;
    for (auto obj : objects) {
        if (reachable.find(obj->GetIndirectReference()) != reachable.end()) continue;
        if (!obj->HasStream()) continue;
        try {
            PoDoFo::charbuff buf;
            obj->GetOrCreateStream().CopyTo(buf, /*raw=*/true);
            garbage += static_cast<qint64>(buf.size());
        } catch (const PoDoFo::PdfError&) {
            // Unreadable stream: claim nothing for it (conservative).
        }
    }
    return garbage;
}

OptimizeEstimate PoDoFoBackend::estimateOptimization(const OptimizeOptions &options)
{
    QMutexLocker locker(&d->mutex);
    OptimizeEstimate est;
    if (!d->document) return est;

    try {
        auto& doc = *d->document;
        QFileInfo fi(d->currentFile);
        est.originalBytes = fi.size();

        // Scan all objects for images and fonts
        QSet<QByteArray> imageHashes;
        auto& objects = doc.GetObjects();

        for (auto obj : objects) {
            if (!obj->IsDictionary()) continue;

            auto& dict = obj->GetDictionary();

            // Check for image XObjects
            if (dict.HasKey("Subtype")) {
                auto subtype = dict.FindKey("Subtype");
                if (subtype && subtype->IsName() && subtype->GetName().GetString() == "Image") {
                    est.imageCount++;

                    if (obj->HasStream()) {
                        PoDoFo::charbuff buf;
                        // Raw (encoded) bytes: CopyTo() cannot expand media
                        // filters (/DCTDecode) and would throw on JPEG PDFs.
                        obj->GetOrCreateStream().CopyTo(buf, /*raw=*/true);
                        qint64 streamSize = static_cast<qint64>(buf.size());
                        est.imageTotalBytes += streamSize;

                        if (options.deduplicateImages) {
                            QByteArray hash = QCryptographicHash::hash(
                                QByteArray(buf.data(), static_cast<int>(qMin(streamSize, qint64(4096)))),
                                QCryptographicHash::Md5);
                            if (imageHashes.contains(hash)) {
                                est.duplicateImages++;
                            } else {
                                imageHashes.insert(hash);
                            }
                        }
                    }
                }
            }

            // Check for font objects
            if (dict.HasKey("Type")) {
                auto typeObj = dict.FindKey("Type");
                if (typeObj && typeObj->IsName() && typeObj->GetName().GetString() == "Font") {
                    est.fontCount++;
                }
            }
        }

        // Estimate savings
        qint64 savings = 0;

        if (options.downsampleImages && est.imageTotalBytes > 0) {
            // Rough: downsample from 300 to 150 DPI = ~75% reduction in image data
            double dpiRatio = static_cast<double>(options.targetDpi) / 300.0;
            double areaRatio = dpiRatio * dpiRatio;
            savings += static_cast<qint64>(est.imageTotalBytes * (1.0 - areaRatio));
        }

        if (options.deduplicateImages && est.duplicateImages > 0) {
            qint64 avgImageSize = (est.imageCount > 0) ? est.imageTotalBytes / est.imageCount : 0;
            savings += est.duplicateImages * avgImageSize;
        }

        if (options.subsetFonts && est.fontCount > 0) {
            // §9.13 P0: font subsetting does NOT run in the write path
            // (optimizeDocument) yet — only downsample, dedup and metadata
            // stripping are implemented. Claiming savings here would overstate
            // the estimate on every real PDF, so it is zeroed out until the
            // pass actually runs. // upgrade path: re-enable when subsetFonts
            // lands in optimizeDocument.
            // savings += est.fontCount * 15000;
        }

        if (options.removeUnusedObjects && est.originalBytes > 0) {
            // §9.13 P1: the sweep is REAL now — optimizeDocument Phase 4 runs
            // PoDoFo's trailer-rooted mark-and-sweep when this option is set —
            // so the estimate reports measured garbage instead of the former
            // fixed ~5% claim (which was zeroed out precisely because the
            // write path did not implement the pass). Signed documents claim
            // nothing: writeUpdate() appends an incremental revision there and
            // the original bytes — garbage included — always remain on disk.
            bool signedDoc = false;
            try {
                for (auto field : doc.GetFieldsIterator()) {
                    if (field != nullptr &&
                        field->GetType() == PoDoFo::PdfFieldType::Signature) {
                        signedDoc = true;
                        break;
                    }
                }
            } catch (const PoDoFo::PdfError&) {
                // Cannot determine — claim nothing (conservative).
                signedDoc = true;
            }
            if (!signedDoc) {
                savings += unreachableStreamBytes(doc);
            }
        }

        est.estimatedBytes = qMax(est.originalBytes - savings, est.originalBytes / 10);
        est.reductionPercent = 100.0 * (1.0 - static_cast<double>(est.estimatedBytes) / est.originalBytes);

        return est;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error estimating optimization:" << e.what();
        return est;
    }
}

// §9.13 P0 DEFECT 3: build a canonical serialization of the image-dictionary
// parameters that determine how the raw stream bytes are interpreted. Two
// images sharing stream bytes but differing in any of these params are NOT
// equivalent and must not be deduplicated (e.g. the same image used once WITH
// an /SMask and once without). /ColorSpace is resolved through references so
// two names pointing at the same colorspace object collide, while different
// colorspaces do not. /SMask is folded in by mask-object identity so a masked
// and an unmasked copy of the same bytes never merge.
static QByteArray imageDictFingerprint(PoDoFo::PdfObject& obj, PoDoFo::PdfIndirectObjectList& objects)
{
    auto& dict = obj.GetDictionary();
    QByteArray fp;
    const char* keys[] = {
        "Width", "Height", "BitsPerComponent", "Decode", "Filter",
        "ImageMask", "ColorSpace", "SMask", "Interpolate", "Intent"
    };
    for (const char* key : keys) {
        fp.append(key);
        fp.append('=');
        auto* v = dict.FindKey(key);
        if (!v) {
            fp.append("(null)");
            continue;
        }
        if (v->IsReference()) {
            // Resolve references so two names pointing at the same object
            // collide, but different objects do not.
            try {
                auto& target = objects.MustGetObject(v->GetReference());
                fp.append(target.ToString());
            } catch (...) {
                fp.append(v->ToString());
            }
        } else {
            fp.append(v->ToString());
        }
        fp.append(';');
    }
    // upgrade path: fold stream-bearing targets (/SMask, ICCBased) by object
    // IDENTITY instead of content so many-to-one mask sharing costs O(1) per
    // image. Empirically the content serialization does not mutate streams
    // (pinned by TestDedupSMask::fingerprintingDoesNotMutateStreams) and the
    // amplification only matters for very large shared masks.
    return fp;
}

// §9.13 P1: the same signature-field inspection writeUpdate() performs. A
// signed document must never get the unused-object sweep (ER-2 precedent).
static bool documentHasSignatureFields(PoDoFo::PdfMemDocument &doc)
{
    try {
        for (auto field : doc.GetFieldsIterator()) {
            if (field != nullptr && field->GetType() == PoDoFo::PdfFieldType::Signature)
                return true;
        }
    } catch (const PoDoFo::PdfError&) {
        // Cannot determine — treat conservatively as signed (skip the sweep).
        return true;
    }
    return false;
}

bool PoDoFoBackend::optimizeDocument(const QString &outputPath, const OptimizeOptions &options)
{
    QMutexLocker locker(&d->mutex);
    if (!d->document) return false;

    try {
        auto& doc = *d->document;
        auto& objects = doc.GetObjects();
        // Phase 1: Downsample images. Two decodable cases — (a) JPEG
        // (/DCTDecode): the raw stream bytes ARE a JPEG file, decoded via Qt
        // and re-encoded honoring options.jpegQuality; (b) legacy uncompressed
        // /DeviceRGB 8bpc pixels (previously written back as raw RGB, now also
        // re-encoded to real JPEG). Media-filter streams are read with
        // CopyTo(raw) — CopyTo() cannot expand DCTDecode and throws
        // UnsupportedFilter. Everything else (CCITT, JPX, indexed, 16bpc,
        // CMYK, /ImageMask, images carrying /SMask or /Mask — rescaling would
        // desync the mask — or a /Decode array the re-encode would invalidate)
        // is skipped untouched.
        // upgrade path: downscale /SMask masks together with their base image
        // instead of skipping masked images.
        // §9.13 F9: a non-positive targetDpi inverts the ratio below and would
        // clamp every image to 1x1 — skip downsampling instead of destroying
        // images on a degenerate setting.
        if (options.downsampleImages && options.targetDpi > 0) {
            constexpr int64_t kMaxOptimizeDim = 10000;
            auto asInt = [](const PoDoFo::PdfObject* o) -> int64_t {
                return (o && o->IsNumberOrReal()) ? static_cast<int64_t>(o->GetReal()) : 0;
            };
            auto isName = [](const PoDoFo::PdfObject* o, const char* n) {
                return o && o->IsName() && o->GetName().GetString() == n;
            };
            auto isMediaFilterName = [](const PoDoFo::PdfObject* o) {
                if (!o || !o->IsName()) return false;
                const std::string_view n = o->GetName().GetString();
                return n == "DCTDecode" || n == "JPXDecode"
                    || n == "CCITTFaxDecode" || n == "JBIG2Decode";
            };
            auto hasMediaFilter = [&](const PoDoFo::PdfObject* filter) {
                if (isMediaFilterName(filter)) return true;
                if (filter && filter->IsArray())
                    for (const auto& f : filter->GetArray())
                        if (isMediaFilterName(&f)) return true;
                return false;
            };
            for (auto obj : objects) {
                if (!obj->IsDictionary() || !obj->HasStream()) continue;
                auto& dict = obj->GetDictionary();

                auto* subtype = dict.FindKey("Subtype");
                if (!subtype || !subtype->IsName() || subtype->GetName().GetString() != "Image")
                    continue;

                int64_t w = asInt(dict.FindKey("Width"));
                int64_t h = asInt(dict.FindKey("Height"));
                if (w <= 0 || h <= 0) continue;
                // Cap to 10 000 px on each axis, matching the replaceImage()
                // cap: a crafted PDF with w/h > INT_MAX would truncate in the
                // int casts below and produce a mismatched-stride QImage.
                if (w > kMaxOptimizeDim || h > kMaxOptimizeDim) continue;

                auto* imObj = dict.FindKey("ImageMask");
                if (imObj && imObj->IsBool() && imObj->GetBool()) continue;
                if (dict.FindKey("SMask") || dict.FindKey("Mask") || dict.FindKey("Decode"))
                    continue;

                double estDpi = static_cast<double>(w) / 8.27;
                if (estDpi <= options.targetDpi * 1.2) continue;

                // §9.13 F5 (containment): one hostile image throwing from the
                // stream APIs must degrade to "skip this image", not abort the
                // whole optimization via the outer catch.
                PoDoFo::charbuff buf;
                QImage src;
                bool isGrayImage = false;
                    try {
                    auto* filterObj = dict.FindKey("Filter");
                    bool isDct = isName(filterObj, "DCTDecode")
                                 || (filterObj && filterObj->IsArray()
                                     && filterObj->GetArray().size() == 1
                                     && isName(&filterObj->GetArray()[0], "DCTDecode"));
                    if (isDct) {
                        // A re-encoded JPEG must stay /DeviceRGB or /DeviceGray;
                        // CMYK JPEGs would silently change colors.
                        auto* csObjDct = dict.FindKey("ColorSpace");
                        if (!isName(csObjDct, "DeviceRGB") && !isName(csObjDct, "DeviceGray")) {
                            qDebug() << "optimizeDocument: DCT image with unsupported colorspace, left untouched";
                            continue;
                        }
                        obj->GetOrCreateStream().CopyTo(buf, /*raw=*/true);
                        src.loadFromData(reinterpret_cast<const uchar*>(buf.data()),
                                         static_cast<int>(buf.size()), "JPG");
                    } else {
                        // §9.13 P1: FlateDecode (or raw) coverage — decode via
                        // PoDoFo's own stream expansion and re-encode as real
                        // JPEG, same contract as the DCT path above.
                        // /DeviceRGB 8bpc (pre-existing) and /DeviceGray 8bpc
                        // (new) qualify.
                        auto* csObj = dict.FindKey("ColorSpace");
                        bool isRgb = isName(csObj, "DeviceRGB");
                        bool isGray = isName(csObj, "DeviceGray");
                        auto* bpcObj = dict.FindKey("BitsPerComponent");
                        int bpc = static_cast<int>(asInt(bpcObj) == 0 ? 8 : asInt(bpcObj));
                        if ((!isRgb && !isGray) || bpc != 8) continue;
                        // §9.13 P1: PNG/TIFF predictors transform the decoded
                        // bytes ABOVE the filter — PoDoFo's expansion does not
                        // undo them, so predictor-coded streams must never be
                        // treated as pixels. Skip byte-identical (pinned by
                        // TestCompressJpegReencode::predictorImageIsSkippedSafely).
                        auto* parmsObj = dict.FindKey("DecodeParms");
                        if (parmsObj) {
                            bool hasPredictor = false;
                            auto checkParms = [&hasPredictor](const PoDoFo::PdfObject* p) {
                                if (!p || !p->IsDictionary()) return;
                                auto* pred = p->GetDictionary().FindKey("Predictor");
                                hasPredictor = hasPredictor
                                    || (pred && pred->IsNumberOrReal() && pred->GetReal() > 1);
                            };
                            checkParms(parmsObj);
                            if (parmsObj->IsArray())
                                for (const auto& p : parmsObj->GetArray())
                                    checkParms(&p);
                            if (hasPredictor) {
                                qDebug() << "optimizeDocument: predictor-coded image, left untouched";
                                continue;
                            }
                        }
                        // §9.13 F5: any media filter in the chain (e.g. a wrapped
                        // JPEG [/FlateDecode /DCTDecode]) makes the expanding
                        // CopyTo() throw UnsupportedFilter — skip, don't fail.
                        if (hasMediaFilter(filterObj)) {
                            qDebug() << "optimizeDocument: image with media filter chain, left untouched";
                            continue;
                        }
                        obj->GetOrCreateStream().CopyTo(buf);
                        const int64_t cpp = isGray ? 1 : 3; // channels per pixel
                        if (static_cast<qint64>(buf.size()) < w * h * cpp) continue;
                        src = QImage(reinterpret_cast<const uchar*>(buf.data()),
                                     static_cast<int>(w), static_cast<int>(h),
                                     static_cast<int>(w * cpp),
                                     isGray ? QImage::Format_Grayscale8
                                            : QImage::Format_RGB888);
                        isGrayImage = isGray;
                    }
                    if (src.isNull()) {
                        qDebug() << "optimizeDocument: undecodable image, left untouched";
                        continue;
                    }

                    double ratio = static_cast<double>(options.targetDpi) / estDpi;
                    int64_t newW = qMax<int64_t>(1, static_cast<int64_t>(w * ratio));
                    int64_t newH = qMax<int64_t>(1, static_cast<int64_t>(h * ratio));

                    QImage scaled = src.scaled(static_cast<int>(newW), static_cast<int>(newH),
                                               Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
                    // §9.13 P1: grayscale stays grayscale — Qt writes a real
                    // luminance-only JPEG for Format_Grayscale8; RGB is
                    // normalized to RGB888 as before.
                    if (!isGrayImage)
                        scaled = scaled.convertToFormat(QImage::Format_RGB888);

                    // Encode at the user-selected quality and write the bytes
                    // verbatim. The filters overload with raw=true is required:
                    // plain SetData(raw=true) clears /Filter unconditionally.
                    QByteArray jpeg;
                    {
                        QBuffer jbuf(&jpeg);
                        jbuf.open(QIODevice::WriteOnly);
                        QImageWriter writer(&jbuf, "jpg");
                        writer.setQuality(qBound(1, options.jpegQuality, 100));
                        if (!writer.write(scaled)) {
                            qDebug() << "optimizeDocument: JPEG re-encode failed, image left untouched";
                            continue;
                        }
                    }

                    PoDoFo::charbuff newBuf(std::string_view(jpeg.constData(), jpeg.size()));
                    obj->GetOrCreateStream().SetData(
                        newBuf, PoDoFo::PdfFilterList{ PoDoFo::PdfFilterType::DCTDecode }, /*raw=*/true);
                    dict.AddKey("Width", static_cast<int64_t>(scaled.width()));
                    dict.AddKey("Height", static_cast<int64_t>(scaled.height()));
                    dict.AddKey("BitsPerComponent", static_cast<int64_t>(8));
                    dict.AddKey("ColorSpace",
                                PoDoFo::PdfName(isGrayImage ? "DeviceGray" : "DeviceRGB"));
                    dict.RemoveKey("DecodeParms");
                } catch (const PoDoFo::PdfError& e) {
                    qDebug() << "optimizeDocument: image skipped on stream error:" << e.what();
                    continue;
                }
            }
        }

        // Phase 2: Deduplicate images (replace duplicates with references to first)
        if (options.deduplicateImages) {
            QHash<QByteArray, PoDoFo::PdfObject*> hashToObj;
            QHash<PoDoFo::PdfObject*, PoDoFo::PdfObject*> duplicateMap;

            for (auto obj : objects) {
                if (!obj->IsDictionary() || !obj->HasStream()) continue;
                auto& dict = obj->GetDictionary();
                auto* subtype = dict.FindKey("Subtype");
                if (!subtype || !subtype->IsName() || subtype->GetName().GetString() != "Image")
                    continue;

                PoDoFo::charbuff buf;
                // Raw (encoded) bytes: CopyTo() cannot expand media filters
                // like /DCTDecode, and identical images have identical raw
                // bytes anyway. The dict fingerprint below keeps differing
                // encodings apart.
                obj->GetOrCreateStream().CopyTo(buf, /*raw=*/true);
                // §9.13 P0 DEFECT 3: hash the stream bytes AND the image-dict
                // params. Two images with identical bytes but different
                // /ColorSpace, /SMask, /Width, /Height, /BitsPerComponent,
                // /Decode, /Filter or /ImageMask are NOT equivalent and must
                // not be merged (silent transparency/colorspace corruption).
                QByteArray hashInput;
                hashInput.append(QByteArray(buf.data(), static_cast<int>(buf.size())));
                hashInput.append(imageDictFingerprint(*obj, objects));
                QByteArray hash = QCryptographicHash::hash(hashInput, QCryptographicHash::Sha256);

                if (hashToObj.contains(hash)) {
                    duplicateMap.insert(obj, hashToObj[hash]);
                } else {
                    hashToObj.insert(hash, obj);
                }
            }

            // §9.13 P0: complete the rewiring — every page /XObject entry that
            // points at a duplicate image is rewritten to reference the
            // canonical (first) copy. The duplicate objects then become
            // unreferenced and are dropped by PoDoFo's save-time garbage
            // collection.
            if (!duplicateMap.isEmpty()) {
                unsigned int pc = doc.GetPages().GetCount();
                for (unsigned int pi = 0; pi < pc; ++pi) {
                    auto& page = doc.GetPages().GetPageAt(pi);
                    auto* res = page.GetDictionary().FindKey("Resources");
                    if (!res) continue;
                    if (res->IsReference())
                        res = &doc.GetObjects().MustGetObject(res->GetReference());
                    if (!res || !res->IsDictionary()) continue;
                    auto* xobjs = res->GetDictionary().FindKey("XObject");
                    if (!xobjs) continue;
                    if (xobjs->IsReference())
                        xobjs = &doc.GetObjects().MustGetObject(xobjs->GetReference());
                    if (!xobjs || !xobjs->IsDictionary()) continue;

                    for (auto& entry : xobjs->GetDictionary()) {
                        PoDoFo::PdfObject* val = &entry.second;
                        if (!val->IsReference()) continue;
                        // §9.13 F8: a dangling /XObject reference must not
                        // throw and abort the pass — skip unresolvable entries
                        // (consistent with the imageDictFingerprint guard).
                        PoDoFo::PdfObject* target =
                            doc.GetObjects().GetObject(val->GetReference());
                        if (!target) continue;
                        auto it = duplicateMap.find(target);
                        if (it != duplicateMap.end()) {
                            xobjs->GetDictionary().AddKey(
                                entry.first, it.value()->GetIndirectReference());
                        }
                    }
                }
            }
        }

        // Phase 3: full hidden-data scrub if requested — §9.13 P0: reuse the
        // complete sanitizeDocument() pass instead of the former /Info +
        // catalog-/Metadata-only subset, so "strip metadata" in the Compress
        // flow can no longer leave PII in attachments, actions, or XMP.
        if (options.stripMetadata) {
            sanitizeDocumentContents(doc);
        }

        // Phase 4 (§9.13 P1): unused-object removal — a REAL trailer-rooted
        // mark-and-sweep. PoDoFo 1.1's PdfIndirectObjectList::CollectGarbage()
        // computes the transitive closure of references from the trailer (page
        // tree, /Contents, /Resources incl. XObjects, /Annots, AcroForm,
        // /StructTreeRoot, /Outlines, /Names — everything reachable), then
        // deletes the rest, garbage clusters included. Reused (rung 2) instead
        // of hand-rolling the same walk. Gated behind options.removeUnusedObjects:
        // the "Remove unused objects" checkbox now does real work.
        // Guard ordering: signed documents skip the sweep ENTIRELY — writeUpdate()
        // below appends an incremental revision whose /ByteRange windows cover
        // the original bytes; deleting objects from a signed document's working
        // set must not happen (the unsigned path's full save is unaffected).
        if (options.removeUnusedObjects) {
            if (documentHasSignatureFields(doc)) {
                qDebug() << "optimizeDocument: signed document — unused-object sweep skipped";
            } else {
                // §9.13 P1 (crash safety): PdfMemDocument caches a PdfInfo
                // wrapper over the trailer /Info object. When an earlier phase
                // (strip metadata) removed the trailer /Info KEY, that object
                // becomes unreachable and the sweep would delete it — leaving
                // the cached wrapper dangling; Save() then updates /Info/ModDate
                // through the stale wrapper and dereferences freed memory
                // (observed SIGSEGV: PdfInfo::GetTitle → PdfDictionary::FindKey,
                // caught by TestCompressStripSanitize). Re-anchor the object for
                // the duration of the sweep; the anchor key is removed right
                // after, so the written artifact is unchanged — PoDoFo's own
                // save-time sweep drops the object AFTER its metadata update,
                // the ordering it is written to tolerate.
                bool infoReanchored = false;
                auto& trailerDict = doc.GetTrailer().GetObject().GetDictionary();
                const PoDoFo::PdfInfo* cachedInfo = doc.GetInfo();
                if (cachedInfo != nullptr && !trailerDict.HasKey("Info")
                    && cachedInfo->GetObject().IsIndirect()) {
                    trailerDict.AddKey("Info", cachedInfo->GetObject().GetIndirectReference());
                    infoReanchored = true;
                }
                const unsigned beforeSweep = objects.GetSize();
                doc.CollectGarbage();
                if (infoReanchored)
                    trailerDict.RemoveKey("Info");
                qDebug() << "optimizeDocument: unused-object sweep removed"
                         << (beforeSweep - objects.GetSize()) << "object(s)";
            }
        }

        if (!writeUpdate(outputPath)) throw std::runtime_error("writeUpdate failed");
        return true;
    } catch (const PoDoFo::PdfError& e) {
        qWarning() << "Error optimizing document:" << e.what();
        return false;
    }
}

