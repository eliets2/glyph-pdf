#include <QApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <podofo/podofo.h>
#include "engines/podofo/PoDoFoBackend.h"
#include "core/MeasureCore.h"
int main(int argc,char**argv){QApplication app(argc,argv);qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){fprintf(stdout,"%s\n",s.toUtf8().constData());fflush(stdout);});QString dir=QString::fromLocal8Bit(argv[1]);QDir().mkpath(dir);QString input=dir+"/seed.pdf",out=dir+"/measured.pdf";{PoDoFo::PdfMemDocument d;d.GetPages().CreatePage(PoDoFo::Rect(0,0,612,792));d.Save(input.toStdString());}
 AnnotationItem perimeter;perimeter.mode=ToolMode::MeasurePerimeter;perimeter.pageIndex=0;perimeter.points={{10,10},{82,10},{82,82},{10,82}};perimeter.rect=QRectF(10,10,72,72);perimeter.measureCalibrated=true;perimeter.measureUnitsPerPt=0.5;perimeter.measureUnit="mm";perimeter.measureAreaUnit="mm2";perimeter.measureRatio="1 mm = 2 pt";perimeter.text="144.00 mm";
 AnnotationItem line=perimeter;line.mode=ToolMode::MeasureDistance;line.points={{10,100},{82,100}};line.rect=QRectF(10,100,72,0);line.text="36.00 mm";
 PoDoFoBackend engine;bool ok=engine.embedAnnotations(input,out,{perimeter,line});qInfo()<<"EMBED"<<ok;for(const auto&a:engine.extractAnnotations(out))qInfo()<<"READBACK"<<int(a.mode)<<"RECT"<<a.rect<<"POINTS"<<a.points<<"LABEL"<<a.text;
 PoDoFo::PdfMemDocument d;d.Load(out.toStdString());auto&annos=d.GetPages().GetPageAt(0).GetAnnotations();for(unsigned i=0;i<annos.GetCount();++i){auto&dict=annos.GetAnnotAt(i).GetDictionary();auto&r=dict.FindKey("Rect")->GetArray();qInfo()<<"RAW_RECT"<<r[0].GetReal()<<r[1].GetReal()<<r[2].GetReal()<<r[3].GetReal();}return ok?0:1;
}
