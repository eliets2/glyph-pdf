from pathlib import Path
import subprocess,os,shlex
w=Path(__file__).resolve().parent
src=w.parent/'local'
env=dict(os.environ); env['PATH']='C:/msys64/ucrt64/bin;'+env.get('PATH','')
flags=shlex.split(subprocess.check_output(['C:/msys64/ucrt64/bin/pkg-config.exe','--cflags','--libs','Qt6Core'],env=env,text=True))
cmd=['C:/msys64/ucrt64/bin/g++.exe','-std=c++17','-I'+str(src/'src'),str(w/'measure-core-probe.cpp'),'-o',str(w/'measure-core-probe.exe'),*flags]
r=subprocess.run(cmd,env=env,capture_output=True,text=True)
(w/'measure-core-probe-build.log').write_text(r.stdout+r.stderr,encoding='utf-8')
if r.returncode: print(r.stderr);raise SystemExit(r.returncode)
r=subprocess.run([str(w/'measure-core-probe.exe')],env=env,capture_output=True,text=True)
(w/'measure-core-probe.log').write_text(r.stdout+r.stderr,encoding='utf-8')
print(r.stdout+r.stderr)
raise SystemExit(r.returncode)
