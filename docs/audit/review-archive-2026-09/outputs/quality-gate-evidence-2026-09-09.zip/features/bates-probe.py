from pathlib import Path
import subprocess,os,shlex,sys
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent;s=w.parent/'remote';b=w.parent/'build-remote'
stem=sys.argv[1] if len(sys.argv)>1 else 'bates-probe'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
cmds=subprocess.check_output(['ninja','-t','commands','TestDocumentIdentity'],cwd=b,env=env,text=True).splitlines();cmd=next(x for x in reversed(cmds) if '  libpdfws_ui.a' in x)
libs=[str(b/'CMakeFiles/TestDocumentIdentity.dir/src/app/Bootstrapper.cpp.obj'),'libpdfws_ui.a']+shlex.split(cmd.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets','Qt6Pdf','Qt6PdfWidgets','Qt6Concurrent'],env=env,text=True))
with (w/(stem+'-build.log')).open('w') as log:r=subprocess.run(['g++','-std=c++17','-I'+str(s/'src'),'-I'+str(s/'third_party/podofo/install/include'),'-I'+str(s/'third_party/pdfium/include'),*flags,str(w/(stem+'.cpp')),'-o',str(w/(stem+'.exe')),*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((w/(stem+'-build.log')).read_text(errors='replace'));sys.exit(r.returncode)
with (w/(stem+'.log')).open('w') as log:r=subprocess.run([str(w/(stem+'.exe'))],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
print((w/(stem+'.log')).read_text(errors='replace'));sys.exit(r.returncode)
