#define main architectureOriginalMain
#include "../architecture/probe.cpp"
#undef main
#include "ui/BatesNumberingDialog.h"
#include "shell/controllers/PagesController.h"
int main(int argc,char**argv){
 QApplication app(argc,argv);app.setQuitOnLastWindowClosed(false);QApplication::setAttribute(Qt::AA_DontUseNativeDialogs,true);
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){fprintf(stdout,"%s\n",s.toUtf8().constData());fflush(stdout);});
 QCoreApplication::setOrganizationName("GlyphGateOwnFixtures");QCoreApplication::setApplicationName("BatesSep9");QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,QDir::currentPath()+"/profile");
 QString dir=QDir::currentPath()+"/bates-"+QString::number(QDateTime::currentMSecsSinceEpoch());QDir().mkpath(dir);
 QString active=makePdf(dir+"/active.pdf","BT /F1 12 Tf 72 720 Td (ACTIVE) Tj ET\n");gp::MainWindow win(Bootstrapper::createContext());win.openDocument(active);auto* ctx=win.appContext();gp::PagesController controller(ctx,&win);
 auto run=[&](const QStringList&files){QTimer t;QObject::connect(&t,&QTimer::timeout,[&](){for(auto*w:QApplication::topLevelWidgets())if(auto*d=qobject_cast<gp::BatesNumberingDialog*>(w)){d->setBatchFiles(files);d->accept();}});t.start(5);controller.activate(ToolId::BatesNumber);};
 QString missing=dir+"/missing.pdf",existing=makePdf(dir+"/missing_bated.pdf","BT /F1 12 Tf 72 720 Td (KEEP_EXISTING_DESTINATION) Tj ET\n");auto before=bytes(existing);run({missing});qInfo()<<"BATES_MISSING_INPUT_EXISTING_DEST_PRESERVED"<<(bytes(existing)==before)<<"DEST_EXISTS"<<QFile::exists(existing);
 QString a=makePdf(dir+"/first.pdf","BT /F1 12 Tf 72 720 Td (FIRST_SOURCE) Tj ET\n"),b=makePdf(dir+"/first_bated.pdf","BT /F1 12 Tf 72 720 Td (SECOND_SOURCE_MUST_SURVIVE) Tj ET\n");auto bBefore=bytes(b);run({a,b});qInfo()<<"BATES_SECOND_INPUT_CHANGED"<<(bytes(b)!=bBefore)<<"SECOND_SOURCE_TEXT"<<textOf(b)<<"SECOND_OUTPUT_TEXT"<<textOf(dir+"/first_bated_bated.pdf");
 qInfo()<<"BATES_ACTIVE_ROTATE_AFTER_BATCH"<<ctx->pdfEditor->rotatePage(active,0,90)<<"SESSION_PATH"<<ctx->document->path()<<"VIEWER_PATH"<<win.pdfViewer()->filePath();ctx->document->setClean();qInfo()<<"FIXTURE_DIR"<<dir;return 0;
}
