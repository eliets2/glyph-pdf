from pathlib import Path
import subprocess,os,shlex
w=Path(__file__).resolve().parent;s=w.parent/'remote';v=s/'third_party/podofo/install'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(w.parent/'build-remote'),str(v/'bin'),'C:/msys64/ucrt64/bin',env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
flags=shlex.split(subprocess.check_output(['C:/msys64/ucrt64/bin/pkg-config.exe','--cflags','--libs','Qt6Widgets'],env=env,text=True))
cmd=['C:/msys64/ucrt64/bin/g++.exe','-std=c++17','-I'+str(s/'src'),'-I'+str(v/'include'),str(w/'labels-probe.cpp'),str(s/'src/core/PageLabels.cpp'),'-o',str(w/'labels-probe.exe'),str(v/'lib/libpodofo.dll.a'),*flags]
r=subprocess.run(cmd,env=env,capture_output=True,text=True)
(w/'labels-probe-build.log').write_text(r.stdout+r.stderr,encoding='utf-8')
if r.returncode: print(r.stderr);raise SystemExit(r.returncode)
r=subprocess.run([str(w/'labels-probe.exe'),str(w/'labels-input.pdf')],env=env,capture_output=True,text=True,timeout=20)
(w/'labels-probe.log').write_text(r.stdout+r.stderr,encoding='utf-8')
print(r.stdout+r.stderr)
raise SystemExit(r.returncode)
