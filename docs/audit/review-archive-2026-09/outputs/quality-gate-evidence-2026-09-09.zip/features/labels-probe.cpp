#include <QApplication>
#include <QPdfWriter>
#include <QPainter>
#include <QFile>
#include <QFileInfo>
#include <cstdio>
#include <podofo/podofo.h>
#include "core/PageLabels.h"
int main(int argc,char** argv) {
 QApplication app(argc,argv);
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&m){std::fprintf(stdout,"%s\n",m.toUtf8().constData());});
 const QString path=QString::fromLocal8Bit(argv[1]);
 { QPdfWriter w(path); QPainter p(&w); p.drawText(100,100,QStringLiteral("SOURCE_TEXT_MUST_SURVIVE")); w.newPage(); p.drawText(100,100,QStringLiteral("PAGE_TWO")); }
 const auto before=QFileInfo(path).size();
 QFile::copy(path,path+".before");
 bool ok=gp::PageLabels::writeNumberTree(path,7,gp::PageLabels::Style::Decimal);
 std::printf("writeNumberTree ok=%d bytesBefore=%lld bytesAfter=%lld\n",ok,(long long)before,(long long)QFileInfo(path).size());
 try { PoDoFo::PdfMemDocument doc;doc.Load(path.toUtf8().constData());std::printf("reopen pages=%u\n",doc.GetPages().GetCount()); } catch(const std::exception&e){std::printf("reopen failed: %s\n",e.what());}
}
