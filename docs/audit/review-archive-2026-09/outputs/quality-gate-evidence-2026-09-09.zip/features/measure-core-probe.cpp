#include <QCoreApplication>
#include <QDebug>
#include <QRectF>
#include <cstdio>
#include "core/MeasureCore.h"

int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    qInstallMessageHandler([](QtMsgType, const QMessageLogContext&, const QString& m) { std::fprintf(stdout,"%s\n",m.toUtf8().constData()); });
    using namespace gp::measure;
    for (const QString s : {QStringLiteral("1 typo = 1 ft"), QStringLiteral("1 in = 1 typo"), QStringLiteral("1/4 999 in = 1 ft"), QStringLiteral("1 in = 1 ft")}) {
        auto v = parseScaleRatio(s);
        qInfo().noquote() << s << "accepted=" << bool(v) << "calibrated=" << (v && v->calibrated)
            << "units/pt=" << (v ? v->unitsPerPt : 0) << "label=" << (v ? unitLabel(v->unit) : QString());
    }
    const QList<QPointF> square {{10,10},{82,10},{82,82},{10,82}};
    QRectF bounds(square.first(),square.first());
    for (const auto &p : square) bounds=bounds.united(QRectF(p,p));
    qInfo() << "measurement writer bounds expression gives" << bounds << "expected bounding rectangle" << QRectF(10,10,72,72);
    const Scale scale=fromKnownLength(2,1,Unit::Mm);
    qInfo() << "four vertices of saved PolyLine: open geometry mm=" << convertLengthPt(polylineLength(square),scale)
            << "Glyph closed perimeter mm=" << convertLengthPt(closedPerimeter(square),scale);
}
