#include <QApplication>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QDateTime>
#include <QSettings>
#include <QTimer>
#include <QEventLoop>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QCloseEvent>
#include <QUndoStack>
#include <QAction>
#include <cstdio>
#include "GpMainWindow.h"
#include "app/Bootstrapper.h"
#include "core/AppContext.h"
#include "core/Capability.h"
#include "engines/PdfEditorEngine.h"
#include "engines/DocumentSession.h"
#include "engines/ocr/RapidOcrEngine.h"
#include "engines/pdfium/PdfiumBackend.h"
#include "commands/RotatePageCommand.h"
#include "shell/ToolRegistry.h"
#include "shell/controllers/HomeController.h"
#include "shell/controllers/EditController.h"
#include "modes/PdfAValidationPanel.h"
#include "modes/WatermarkDialog.h"
#include "ui/PdfViewerWidget.h"
#include <podofo/podofo.h>

static QString makePdf(const QString& path, const QByteArray& content) {
 QList<QByteArray> objs={"<</Type/Catalog/Pages 2 0 R>>", "<</Type/Pages/Kids[3 0 R]/Count 1>>", "<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>", "<</Length "+QByteArray::number(content.size())+">>stream\n"+content+"endstream", "<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>"};
 QByteArray pdf="%PDF-1.4\n";QList<qint64> offsets;for(int i=0;i<objs.size();++i){offsets.append(pdf.size());pdf+=QByteArray::number(i+1)+" 0 obj\n"+objs[i]+"\nendobj\n";}
 auto xref=pdf.size();pdf+="xref\n0 6\n0000000000 65535 f \n";for(auto off:offsets)pdf+=QByteArray::number(off).rightJustified(10,'0')+" 00000 n \n";pdf+="trailer<</Size 6/Root 1 0 R>>\nstartxref\n"+QByteArray::number(xref)+"\n%%EOF\n";QFile f(path);if(!f.open(QIODevice::WriteOnly)||f.write(pdf)!=pdf.size())return {};return path;
}
static QByteArray bytes(const QString& p){QFile f(p);f.open(QIODevice::ReadOnly);return f.readAll();}
static void drain(int ms){QEventLoop e;QTimer::singleShot(ms,&e,&QEventLoop::quit);e.exec();}
static int rotation(const QString& p){PoDoFo::PdfMemDocument d;d.Load(p.toStdString());return d.GetPages().GetPageAt(0).GetRotation();}
static QString textOf(const QString& p){PdfiumBackend d;if(!d.loadDocument(p))return "LOAD_FAILED";QString text;for(const auto& r:d.extractPageTextRuns(0))text+=r.text;return text;}
int main(int argc,char**argv){
 qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString& msg){std::fprintf(stdout,"%s\n",msg.toUtf8().constData());std::fflush(stdout);});
 QApplication app(argc,argv);app.setQuitOnLastWindowClosed(false);QApplication::setAttribute(Qt::AA_DontUseNativeDialogs,true);
 QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,QDir::currentPath()+"/profile");QCoreApplication::setOrganizationName("GlyphGateOwnFixtures");QCoreApplication::setApplicationName("ArchitectureSep9");
 QString dir=QDir::currentPath()+"/data-"+QString::number(QDateTime::currentMSecsSinceEpoch());QDir().mkpath(dir);
 auto a=makePdf(dir+"/a.pdf","BT /F1 12 Tf 72 720 Td (DOC_A) Tj ET\n");auto b=makePdf(dir+"/b.pdf","BT /F1 12 Tf 72 720 Td (DOC_B) Tj ET\n");
 gp::MainWindow win(Bootstrapper::createContext());const auto* ctx=win.appContext();auto* v=win.pdfViewer();auto* registry=win.findChild<gp::ToolRegistry*>();
 int modalCount=0;QTimer dismiss;QObject::connect(&dismiss,&QTimer::timeout,[&](){for(auto* w:QApplication::topLevelWidgets())if(auto* box=qobject_cast<QMessageBox*>(w)){if(!box->isVisible())continue;++modalCount;if(box->windowTitle()=="Unsaved Changes"){for(auto* btn:box->buttons())if(btn->text()=="Save")btn->click();}else box->accept();}});dismiss.start(10);
 win.openDocument(a);ctx->undoStack->push(new RotatePageCommand(ctx->pdfEditor.get(),ctx->document.get(),0,90));qInfo()<<"OPEN_ROTATE"<<rotation(a)<<"HISTORY"<<ctx->undoStack->count();
 win.openDocument(b);ctx->undoStack->undo();qInfo()<<"SWITCH_CLEARS_HISTORY"<<ctx->undoStack->count()<<"B_ROTATION"<<rotation(b);
 win.openDocument(a);AnnotationItem note;note.mode=ToolMode::AddComment;note.pageIndex=0;note.rect=QRectF(70,70,100,20);note.text="ONLY_A_GATE_NOTE";v->setAnnotations({note});qInfo()<<"ANNOTATION_DIRTY"<<ctx->document->isDirty();const int modalsBefore=modalCount;win.openDocument(b);qInfo()<<"DIRTY_SWITCH_PROMPTS"<<modalCount-modalsBefore<<"B_DIRTY"<<ctx->document->isDirty()<<"B_ANNOTATIONS"<<v->annotations().size()<<"A_SIDECAR_OWNS_NOTE"<<bytes(a+".ann").contains("ONLY_A_GATE_NOTE");win.openDocument(a);qInfo()<<"REOPEN_UNEMBEDDED_NOTE_DIRTY"<<ctx->document->isDirty()<<"ANNOTATIONS"<<v->annotations().size();
 gp::OcrReviewSession review;review.generation=1;review.sourcePath=a;review.sourcePage=0;review.sourcePageCount=1;review.sourceRevision=ctx->document->mutationRevision();review.pageImage=QImage(2,2,QImage::Format_RGB32);review.pageImage.fill(Qt::white);auto generation=ctx->document->documentGeneration();win.openDocument(b);win.openDocument(a);QString why;bool staleAllowed=gp::EditController::ocrSessionIsExportable(review,v->filePath(),v->pageCount(),ctx->document->mutationRevision(),&why);qInfo()<<"OCR_A_B_A_GENERATION"<<generation<<ctx->document->documentGeneration()<<"REVISION"<<review.sourceRevision<<ctx->document->mutationRevision()<<"EXPORTABLE"<<staleAllowed;
 ctx->document->markDirty();qInfo()<<"OCR_MUTATION_CONTROL_EXPORTABLE"<<gp::EditController::ocrSessionIsExportable(review,v->filePath(),v->pageCount(),ctx->document->mutationRevision(),&why);ctx->document->setClean();
 win.activateScreen("pdfa");drain(300);auto* status=win.findChild<QLabel*>("pdfaStatusLabel");qInfo()<<"PDFA_BOUND_STATUS"<<(status?status->text():"MISSING");win.activateScreen("");
 ctx->document->setReadOnly(true);auto readonlyBefore=bytes(a);qInfo()<<"READONLY_ROTATE_ENABLED"<<registry->actionFor(ToolId::RotateCW)->isEnabled()<<"WATERMARK_ENABLED"<<registry->actionFor(ToolId::Watermark)->isEnabled();QTimer applyWatermark;QObject::connect(&applyWatermark,&QTimer::timeout,[&](){for(auto* w:QApplication::topLevelWidgets())if(auto* dlg=qobject_cast<gp::WatermarkDialog*>(w)){if(dlg->isVisible())QMetaObject::invokeMethod(dlg,"onApply",Qt::DirectConnection);}});applyWatermark.start(10);win.onToolActivated("watermark");applyWatermark.stop();qInfo()<<"READONLY_WATERMARK_SOURCE_CHANGED"<<(bytes(a)!=readonlyBefore)<<"READONLY"<<ctx->document->isReadOnly()<<"TEXT"<<textOf(a);ctx->document->setReadOnly(false);ctx->document->setClean();
 auto original=makePdf(dir+"/recover.pdf","BT /F1 12 Tf 72 720 Td (ORIGINAL_BEFORE_RECOVERY) Tj ET\n");makePdf(original+".autosave.pdf","BT /F1 12 Tf 72 720 Td (RECOVERED_NEW_CONTENT) Tj ET\n");auto originalBefore=bytes(original);win.recoverDocument(original);gp::HomeController home(ctx,&win);auto outcome=home.saveNow();qInfo()<<"RECOVERY_SAVE_OUTCOME"<<int(outcome)<<"SESSION"<<ctx->document->path()<<"VIEWER"<<v->filePath()<<"ORIGINAL_UNCHANGED"<<(bytes(original)==originalBefore)<<"ORIGINAL_TEXT"<<textOf(original)<<"DIRTY"<<ctx->document->isDirty();QCloseEvent close;QApplication::sendEvent(&win,&close);qInfo()<<"RECOVERY_CLOSE_ACCEPTED"<<close.isAccepted()<<"DIRTY"<<ctx->document->isDirty()<<"ORIGINAL_TEXT"<<textOf(original);ctx->document->setClean();
 gp::CapabilityRegistry cap;bool available=false;cap.registerProbe(gp::CapId::OcrRapidModels,[&](const QVariant&){gp::Capability c;c.status=available?gp::Availability::Available:gp::Availability::UnavailableRuntime;c.whyNot="test";return c;});QPushButton foreign;foreign.setEnabled(false);cap.applyToWidget(&foreign,gp::CapId::OcrRapidModels);available=true;cap.invalidate(gp::CapId::OcrRapidModels);cap.applyToWidget(&foreign,gp::CapId::OcrRapidModels);qInfo()<<"CAPABILITY_FOREIGN_DISABLE_LOST"<<foreign.isEnabled();
 auto models=dir+"/models";QDir().mkpath(models);for(const char* name:{"PP-OCRv5_mobile_det_infer.onnx","PP-OCRv5_mobile_rec_infer.onnx","ppocrv5_rec_dict.txt"}){QFile f(models+"/"+name);f.open(QIODevice::WriteOnly);f.write("payload");}auto capability=gp::CapabilityRegistry::probeRapidModelsIn(models);RapidOcrEngine rapid;qInfo()<<"FAKE_MODELS_CAPABILITY"<<int(capability.status)<<"INITIALIZE"<<rapid.initialize("eng",models);
 dismiss.stop();drain(100);qInfo()<<"FIXTURE_DIR"<<dir;return 0;
}
