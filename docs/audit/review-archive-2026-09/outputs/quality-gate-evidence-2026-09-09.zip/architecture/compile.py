from pathlib import Path
import os,shlex,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent;b=w.parent/'build-remote';s=w.parent/'remote'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
commands=subprocess.check_output(['ninja','-t','commands','TestDocumentIdentity'],cwd=b,env=env,text=True).splitlines()
command=next(x for x in reversed(commands) if '  libpdfws_ui.a' in x)
libs=[str(b/'CMakeFiles/TestDocumentIdentity.dir/src/app/Bootstrapper.cpp.obj'),'libpdfws_ui.a']+shlex.split(command.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets','Qt6Pdf','Qt6PdfWidgets','Qt6Concurrent'],env=env,text=True))
with (w/'build.log').open('w',encoding='utf-8') as log:
 r=subprocess.run(['g++','-std=c++17','-I'+str(s/'src'),'-I'+str(s/'third_party/podofo/install/include'),'-I'+str(s/'third_party/pdfium/include'),*flags,str(w/'probe.cpp'),'-o',str(w/'probe.exe'),*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((w/'build.log').read_text(encoding='utf-8',errors='replace'));raise SystemExit(r.returncode)
with (w/'probe.log').open('w',encoding='utf-8') as log:r=subprocess.run([str(w/'probe.exe')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=50)
print((w/'probe.log').read_text(encoding='utf-8',errors='replace'));raise SystemExit(r.returncode)
