from pathlib import Path
import os,sys,subprocess,json,hashlib,importlib.util,traceback,shutil
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent; out=w/'infra';out.mkdir(exist_ok=True)
source=w/'remote'/'tools'/'clean_scanned_pdf.py'
spec=importlib.util.spec_from_file_location('clean_tool',source);tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
import fitz
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
def pdf(p):
    d=fitz.open()
    for i in range(3):
        page=d.new_page(width=300,height=400)
        for y in range(35,345,18):page.insert_text((25,y),'SYNTHETIC AUDIT PAGE '+str(i+1),fontsize=11)
    d.save(p);d.close()
rows=[]
for case in ['same_path','missing_input','corrupt_input','processing_failure','candidate_alias_input','existing_candidate']:
    d=out/case;d.mkdir(exist_ok=True); inp=d/'source.pdf';dest=d/'result.pdf';art=d/'artifacts';png=art/'png'/'page_002_cleaned.png'
    png.parent.mkdir(parents=True,exist_ok=True);png.write_bytes(b'PREEXISTING PNG ARTIFACT')
    pdf(inp);pdf(dest)
    candidate=dest.with_name(dest.name+'.cleaning-tmp.pdf')
    if case=='same_path':dest=inp
    if case=='missing_input':inp=d/'absent.pdf'
    if case=='corrupt_input':inp.write_bytes(b'INVALID PDF')
    if case=='candidate_alias_input':shutil.copyfile(inp,candidate);inp=candidate
    if case=='existing_candidate':candidate.write_bytes(b'PREEXISTING USER CANDIDATE')
    paths={'input':inp,'output':dest,'png':png,'candidate':candidate};before={k:sha(p) for k,p in paths.items()}
    sys.argv=[str(source),str(inp),str(art),str(dest)]
    if case in ['processing_failure','candidate_alias_input','existing_candidate']:os.environ['CLEAN_SCANNED_PDF_FAIL_AFTER_PAGE']='1'
    else:os.environ.pop('CLEAN_SCANNED_PDF_FAIL_AFTER_PAGE',None)
    try:result=tool.main()
    except Exception as exc:result=type(exc).__name__+': '+str(exc)
    after={k:sha(p) for k,p in paths.items()}
    rows.append({'case':case,'return':result,'before':before,'after':after})
(out/'cleanup-results.json').write_text(json.dumps(rows,indent=2))
for row in rows:print(row['case'],row['return'],{k:row['before'][k]==row['after'][k] for k in row['before']})
