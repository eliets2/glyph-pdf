#include <QApplication>
#include <QSettings>
#include <QDir>
#include <QFile>
#include <QAction>
#include <QToolButton>
#include <QPushButton>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QPdfWriter>
#include <QPainter>
#include <QFontDatabase>
#include <QStyleFactory>
#include <QTimer>
#include <QEventLoop>
#include "GpMainWindow.h"
#include "app/Bootstrapper.h"
#include "core/AppContext.h"
#include "engines/DocumentSession.h"
#include "shell/Ribbon.h"
#include "shell/RibbonModel.h"
#include "shell/ToolRegistry.h"
#include "ui/PdfViewerWidget.h"

static void drain(){QEventLoop e;QTimer::singleShot(250,&e,&QEventLoop::quit);e.exec();}
int main(int argc,char**argv){
 QApplication app(argc,argv);app.setQuitOnLastWindowClosed(false);
 app.setStyle(QStyleFactory::create("Fusion"));
 // Offscreen has no Windows desktop font fallback. Load local fonts explicitly
 // for layout evidence; this is a harness adaptation, not a product change.
 QFontDatabase::addApplicationFont("C:/Windows/Fonts/segoeui.ttf");
 QFontDatabase::addApplicationFont("C:/Windows/Fonts/consola.ttf");
 QFont::insertSubstitution("Manrope","Segoe UI");
 QFont::insertSubstitution("JetBrains Mono","Consolas");
 app.setFont(QFont("Segoe UI",9));
 QCoreApplication::setOrganizationName("GlyphUiReviewOwnFixture");QCoreApplication::setApplicationName("Sep9");
 QSettings::setDefaultFormat(QSettings::IniFormat);QSettings::setPath(QSettings::IniFormat,QSettings::UserScope,QDir::currentPath()+"/profile");
 QDir().mkpath("images");
 {QPdfWriter pdf("ui-review-fixture.pdf");pdf.setPageSize(QPageSize(QPageSize::A4));QPainter p(&pdf);p.setFont(QFont("Arial",22));p.drawText(QRect(700,800,8000,1600),Qt::TextWordWrap,"GlyphPDF UI review\nSynthetic document — no private contents");}
 gp::MainWindow win(Bootstrapper::createContext());win.resize(1440,900);win.show();drain();
 win.grab().save("images/welcome-1440.png");
 QJsonArray welcome;
 for(auto*b:win.findChildren<QPushButton*>())if(b->isVisible())welcome.append(QJsonObject{{"text",b->text()},{"accessibleName",b->accessibleName()},{"enabled",b->isEnabled()}});
 win.openDocument(QDir::currentPath()+"/ui-review-fixture.pdf");drain();
 auto* ribbon=win.findChild<gp::Ribbon*>();auto* registry=win.findChild<gp::ToolRegistry*>();if(!ribbon||!registry)return 2;
 ribbon->setCollapsed(false);QJsonArray entries;QJsonArray tabs;
 for(const auto&tab:gp::RibbonModel::tabs()){
  ribbon->raiseTab(tab.name);drain();int defined=0,hidden=0,hiddenGroups=0;
  for(const auto&group:tab.groups){bool allHidden=true;for(const auto&t:group.tools){++defined;bool planned=gp::RibbonModel::plannedTools().contains(t.id);hidden+=planned;allHidden&=planned;
   auto id=toolIdFromString(t.id);QToolButton* button=nullptr;for(auto*b:ribbon->findChildren<QToolButton*>())if(b->property("toolId").toString()==t.id)button=b;
   QJsonObject entry{{"tab",tab.name},{"group",group.title},{"label",t.label},{"id",t.id},{"icon",t.icon},{"plannedHidden",planned},{"canonicalId",id?toolIdToString(*id):QString()},{"hasController",id&&registry->controllerFor(*id)!=nullptr},{"buttonExists",button!=nullptr},{"buttonVisible",button&&button->isVisible()},{"buttonEnabled",button&&button->isEnabled()},{"buttonUsesQAction",button&&button->defaultAction()!=nullptr}};
   if(id&&registry->controllerFor(*id))entry["actionEnabled"]=registry->actionFor(*id)->isEnabled();entries.append(entry);
  }hiddenGroups+=allHidden;}
  tabs.append(QJsonObject{{"tab",tab.name},{"defined",defined},{"hidden",hidden},{"rendered",defined-hidden},{"hiddenGroups",hiddenGroups}});
  win.grab().save("images/"+tab.name.toLower()+"-1440.png");
 }
 win.resize(1100,768);ribbon->raiseTab("Forms");drain();win.grab().save("images/forms-1100.png");
 win.appContext()->document->setReadOnly(true);ribbon->raiseTab("Edit");drain();QJsonArray readOnly;
 for(auto*b:ribbon->findChildren<QToolButton*>()){auto id=toolIdFromString(b->property("toolId").toString());if(!b->isVisible()||!id||!registry->controllerFor(*id))continue;readOnly.append(QJsonObject{{"id",b->property("toolId").toString()},{"buttonEnabled",b->isEnabled()},{"actionEnabled",registry->actionFor(*id)->isEnabled()}});}
 QFile f("command-inventory.json");f.open(QIODevice::WriteOnly);f.write(QJsonDocument(QJsonObject{{"welcomeVisibleButtons",welcome},{"tabs",tabs},{"commands",entries},{"readOnlyEditButtons",readOnly},{"actualFinalWidth",win.width()},{"actualFinalHeight",win.height()},{"viewerPages",win.pdfViewer()->pageCount()},{"viewerPath",win.pdfViewer()->filePath()}}).toJson());
 win.appContext()->document->setClean();return 0;
}
