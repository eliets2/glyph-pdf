from pathlib import Path
import subprocess,os,shlex,sys
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent;s=w.parent/'gate-2026-09-09/local';b=w.parent/'gate-2026-09-09/build-local'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),'C:/msys64/ucrt64/bin',str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
cmds=subprocess.check_output(['ninja','-t','commands','TestDocumentIdentity'],cwd=b,env=env,text=True).splitlines();cmd=next(x for x in reversed(cmds) if '  libpdfws_ui.a' in x)
libs=[str(b/'CMakeFiles/TestDocumentIdentity.dir/src/app/Bootstrapper.cpp.obj'),str(next((b/'CMakeFiles/PdfWorkstation.dir').rglob('qrc_resources.cpp.obj'))),'libpdfws_ui.a']+shlex.split(cmd.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets','Qt6Pdf','Qt6PdfWidgets','Qt6Concurrent'],env=env,text=True))
with (w/'build.log').open('w') as log:r=subprocess.run(['g++','-std=c++17','-flto=8','-I'+str(s/'src'),'-I'+str(s/'third_party/podofo/install/include'),'-I'+str(s/'third_party/pdfium/include'),*flags,str(w/'ui-probe.cpp'),'-o',str(w/'ui-probe.exe'),*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((w/'build.log').read_text(errors='replace'));sys.exit(r.returncode)
with (w/'run.log').open('w') as log:r=subprocess.run([str(w/'ui-probe.exe')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=35)
print((w/'run.log').read_text(errors='replace'));sys.exit(r.returncode)
