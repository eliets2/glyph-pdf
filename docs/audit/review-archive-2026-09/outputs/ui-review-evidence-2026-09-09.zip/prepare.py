from pathlib import Path
import re,json,hashlib,sys
sys.stdout.reconfigure(encoding='utf-8')
w=Path(__file__).resolve().parent
names='backend-specialist code-archaeologist devops-engineer emergence-engine fuzz-harness-engineer gsd-debugger gsd-executor gsd-planner gsd-roadmapper guarantee-verification-engine native-adversary orchestrator performance-optimizer security-auditor solution-architect testing-specialist ui-specialist ux-specialist'.split()
entries=[]
for name in names:
    p=Path(r'C:\Users\User\.claude\agents')/name/(name+'.md');raw=p.read_bytes();text=raw.decode('utf-8-sig');lines=text.splitlines();front=text.split('---',2)[1] if text.startswith('---') else ''
    headings=[line for line in lines if line.startswith('#')]
    # Routing-focused extracts, not a claim to have loaded every reference library.
    lead=next((i for i,line in enumerate(lines) if line.startswith('# ')),0)
    snippets=[]
    for i,line in enumerate(lines):
        if re.match(r'^#{1,3} .*?(MANDATE|BOUNDAR|OUTPUT CONTRACT|DO NOT|When to Use|Identity|Safety|HARD RULE|NATIVE|Operating Mode)',line,re.I):
            j=i+1
            while j<len(lines) and not lines[j].startswith('#'):j+=1
            snippets.append('\n'.join(lines[i:min(j,i+26)]))
    entries.append({'agent':name,'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'frontmatter':front.strip(),'headings':headings,'intro':'\n'.join(lines[lead:lead+15]),'selected_sections':snippets})
(w/'agent-profiles.json').write_text(json.dumps(entries,indent=2),encoding='utf8')
print('\n\n'.join(e['agent']+'\n'+e['frontmatter']+'\n'+e['intro'] for e in entries if e['agent'] not in ['orchestrator','emergence-engine']))
