from pathlib import Path
import subprocess, json, hashlib, zipfile, re

w = Path(__file__).resolve().parent
s = w / 'parity-95676e6'
b = w / 'build-parity-95676e6'
out = w.parent / 'outputs'
repo = Path(r'C:\Users\User\Projects\pdf-parity')
git = ['git', '-c', 'safe.directory=C:/Users/User/Projects/pdf-parity', '-C', str(repo)]
base = '703fa34ece32733ea3b2093da94fa1aed94e1afc'
previous = '4761443278750390c36dec0c1fe77cde775ced20'
head = '95676e6a36ae9aadb2c98c39d47e55d4b0a9cfdd'

def command(*args):
    return subprocess.check_output(git + list(args), text=True, encoding='utf-8', errors='replace')

def save(name, value):
    (w / name).write_text(value, encoding='utf-8')

save('sep7-new-updates.diff', command('diff', '--no-ext-diff', previous + '..' + head))
save('sep7-main-to-reviewed.diff', command('diff', '--no-ext-diff', base + '..' + head))
save('sep7-diff-stat.txt', 'New updates:\n' + command('diff', '--stat', previous + '..' + head)
     + '\nMain baseline:\n' + command('diff', '--stat', base + '..' + head))
save('sep7-vendor-commit.txt', command('show', '--no-patch', '--format=full', '05a3336'))
save('sep7-log.txt', command('log', '--oneline', previous + '..' + head))

same_paths = [
    'src/shell/controllers/FormsController.cpp',
    'src/commands/EditFormFieldCommand.h',
    'src/engines/pdfium/PdfiumBackend.cpp',
    'src/engines/ConversionManager.cpp',
    'src/engines/DiffEngine.cpp',
    'src/engines/ocr/OcrPreprocessor.cpp',
    'src/ui/OcrScanCanvas.cpp',
    'src/core/Capability.cpp',
]
same = {p: (s / p).read_bytes() == (w / 'parity-4761443' / p).read_bytes() for p in same_paths}
with zipfile.ZipFile(w / 'parity-95676e6.zip') as z:
    source_changes = [m.filename for m in z.infolist() if not m.is_dir()
                      and z.read(m) != (s / m.filename).read_bytes()]
assert not source_changes, source_changes
assert (b / 'CTestTestfile.cmake').read_text() == (w / 'sep7-original-CTestTestfile.cmake').read_text()
details = sorted((w / 'sep7-test-details').glob('*.txt'))
skips = {p.name: [line for line in p.read_text(encoding='utf-8', errors='replace').splitlines()
                  if 'SKIP' in line] for p in details}
skips = {k: v for k, v in skips.items() if v}
build_log = (w / 'sep7-build.log').read_text(encoding='utf-8', errors='replace')
test_log = (w / 'sep7-tests.log').read_text(encoding='utf-8', errors='replace')
assert '100% tests passed, 0 tests failed out of 107' in test_log
manifest = {
    'review_date': '2026-09-07',
    'fetch': 'git fetch origin completed successfully, exit 0',
    'reviewed_ref_at_fetch': 'origin/feat/parity-glm',
    'reviewed_commit': head,
    'previous_reviewed_commit': previous,
    'main_baseline_commit': base,
    'comparison': 'Exact-hash two-dot tree diffs; new updates and full main comparison',
    'remote_url': command('remote', 'get-url', 'origin').strip(),
    'observed_remote_ref_after_review': command('rev-parse', 'origin/feat/parity-glm').strip(),
    'snapshot_archive_sha256': hashlib.sha256((w / 'parity-95676e6.zip').read_bytes()).hexdigest(),
    'archived_tracked_source_changes_during_review': source_changes,
    'build': '635 steps, exit 0; GCC 16.1, Qt 6.11, Debug -g0, Tesseract enabled',
    'build_warning_lines': sum('warning:' in line for line in build_log.splitlines()),
    'full_ctest': '107/107 passed first full run, 65.28 seconds',
    'detailed_qt_log_files': len(details),
    'skips_in_captured_detailed_logs': skips,
    'generated_ctest_registration_restored': True,
    'unchanged_sources_from_previous_review': same,
    'new_pdfa3u_fixture_header': (w / 'sep7-probe-data/pdfa3u.pdf').read_bytes()[:8].decode('ascii'),
    'new_findings': ['N01', 'N02', 'N03', 'N04', 'N05', 'N06', 'N07', 'N08', 'N09'],
    'retained_findings': ['V01', 'V02', 'V03', 'V04', 'V05', 'V06', 'D01', 'D02', 'D03', 'D04', 'D05', 'D06', 'D07'],
    'e1': 'Not independently reproduced on either own fixture; remains open pending exact original reproducer',
    'finding_evidence_limits': {
        'N04': 'Caller trace; Security modal was not driven',
        'N05': 'Production notification sequence simulated with actual session/cache classes; full window lifecycle not driven',
        'N06': 'Two ordinary B-B engine calls reproduce appearance loss; full partial-LTV modal retry not driven',
        'N07': 'Offscreen real mode/viewer plus matching exit relay; MainWindow relay source-traced',
        'N09': 'Real engine/default split failure reproduced; duplicate-output overwrite is source trace and blocked earlier by engine failure',
        'D02': 'Ownership trace; no induced use-after-free or sanitizer run',
    },
    'observed_worktree_status_after_review': command('status', '--short'),
    'reviewer_source_edits_merges_installs': False,
    'live_ui_review': 'Deferred until code acceptance and newest exact build installed',
    'not_run': ['Sanitizers', 'Full alternate dependency matrix', 'veraPDF validation', 'External Office round-trip', 'Installed application walkthrough'],
}
save('sep7-manifest.json', json.dumps(manifest, indent=2))
save('sep7-reproduction-readme.txt', '''GlyphPDF independent update review, 2026-09-07

Pinned revision: 95676e6a36ae9aadb2c98c39d47e55d4b0a9cfdd
Read UPDATE-QUALITY-REVIEW-2026-09-07.md first for interpretation and evidence limits.
Scripts are audit harnesses, not proposed production fixes. Some intentionally
exercise failures; the no-Tesseract harness records compiler exit 1 in its log.

The scripts assume their containing directory has these siblings:
  parity-95676e6/       source archive of the pinned commit
  build-parity-95676e6/ configured/built CMake Ninja output
They currently select C:/msys64/ucrt64/bin. Adjust paths for another machine.
Create the source archive with git archive of the exact hash. The build recipe in
review_sep7.py copies the declared vendor trees from a previous isolated snapshot;
on a new machine supply them from the trusted existing worktree as documented in
sep7-vendor-commit.txt, including headers/import libraries. Vendor binaries and the
large source archive are deliberately excluded from this evidence ZIP.

After configuration/build, run the Python harnesses:
  compile_sep7_probe.py        new N findings, real libraries/offscreen widgets
  compile_sep7_previous.py     prior engine, undo, conversion, compare/retry probes
  compile_sep7_canvas.py       actual OCR overlay painting
  compile_sep7_capability.py   incomplete model set and capability recovery
  sep7_compile_fallback.py     Qt-only syntax check
  review_sep7.py test          full CTest with 25 selected detailed Qt logs

Tests use disposable PDF fixtures and the repository test certificate. Full-suite
tests may write their own QSettings keys and start loopback-only test servers.
No user PDF or installed GlyphPDF UI was used. Retain failed assertions and
record model/hook skips. Merely passing the full suite does not close these findings.
''')

files = [
    'sep7-manifest.json', 'sep7-new-updates.diff', 'sep7-main-to-reviewed.diff',
    'sep7-diff-stat.txt', 'sep7-vendor-commit.txt', 'sep7-log.txt',
    'sep7-reproduction-readme.txt', 'sep7-configure.log', 'sep7-build.log',
    'sep7-tests.log', 'sep7-original-CTestTestfile.cmake', 'sep7-qt-only-compile.log',
    'sep7-canvas.log', 'sep7-capability.log', 'sep7-probe.log',
    'sep7-canvas-build.log', 'sep7-capability-build.log', 'sep7-probe-build.log',
    'parity_probe-95676e6.log', 'delta_probe-95676e6.log',
    'parity_probe-95676e6-build.log', 'delta_probe-95676e6-build.log',
    'review_sep7.py', 'compile_sep7_probe.py', 'compile_sep7_previous.py',
    'compile_sep7_canvas.py', 'compile_sep7_capability.py', 'sep7_compile_fallback.py',
    'sep7_probe.cpp', 'parity_probe.cpp', 'delta_probe.cpp',
    'delta_canvas_probe.cpp', 'remote_capability_probe.cpp', 'package_sep7_review.py',
]
archive = out / 'update-quality-evidence-2026-09-07.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in ['UPDATE-QUALITY-REVIEW-2026-09-07.md', 'GLM-FLASH-IMPLEMENTATION-AND-UI-PLAN-2026-09-05.md']:
        z.write(out / name, name)
    for name in files:
        z.write(w / name, name)
    z.write(s / 'docs/audit/CURRENT-EVIDENCE-LEDGER-2026-09-05.md', 'reviewed-ledger.md')
    for folder in ['sep7-test-details', 'sep7-probe-data', 'parity-probe-data', 'delta-probe-data']:
        for p in sorted((w / folder).rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    entries = len(z.infolist())

# Verify every local delivery link in the current report and companion.
broken = []
for name in ['UPDATE-QUALITY-REVIEW-2026-09-07.md', 'GLM-FLASH-IMPLEMENTATION-AND-UI-PLAN-2026-09-05.md']:
    text = (out / name).read_text(encoding='utf-8')
    for link in re.findall(r'\]\((C:/[^)]+)\)', text):
        if not Path(link).exists():
            broken.append((name, link))
assert not broken, broken
print(json.dumps(manifest, indent=2))
print(f'Evidence ZIP verified: {entries} entries, {archive.stat().st_size:,} bytes')
print('All current report/companion local delivery links resolve.')
