from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;s=w/'parity-95676e6'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets'],env=env,text=True))
result=subprocess.run(['g++','-std=c++17','-fsyntax-only','-I'+str(s/'src'),*flags,str(s/'src/engines/ocr/OcrPreprocessor.cpp')],env=env,text=True,capture_output=True)
text=f'Qt-only OcrPreprocessor syntax check (HAS_TESSERACT absent), exit {result.returncode}\n'+result.stdout+result.stderr
(w/'sep7-qt-only-compile.log').write_text(text,encoding='utf-8');print(text)
