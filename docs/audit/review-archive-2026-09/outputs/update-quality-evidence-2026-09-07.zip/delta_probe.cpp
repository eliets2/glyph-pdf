#define main previousProbeMain
#include "parity_probe.cpp"
#undef main
#include "engines/RedactOperation.h"
#include <QCryptographicHash>
#include <podofo/podofo.h>

int main(int argc,char**argv) {
    qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString& msg){std::fprintf(stdout,"%s\n",msg.toUtf8().constData());});
    QApplication app(argc,argv);
    QDir().mkpath("../delta-probe-data");const QString d=QDir("../delta-probe-data").absolutePath();
    const QString src=makePdf(d+"/redaction-source.pdf","BT /F1 12 Tf 50 700 Td (TOPSECRET_DATA) Tj ET\nBT /F1 12 Tf 50 650 Td (PUBLIC_KEEP_TEXT) Tj ET\n");
    auto hash=[](const QString&p){QFile f(p);if(!f.open(QIODevice::ReadOnly))return QByteArray();return QCryptographicHash::hash(f.readAll(),QCryptographicHash::Sha256);};
    const auto before=hash(src);
    gp::RedactRequest req;req.sourcePath=src;req.destinationPath=d+"/redacted.pdf";req.redactionsByPage[0]={QRectF(40,80,300,30)};req.sanitize=true;req.sanitizedDestinationPath=d+"/sanitized.pdf";
    gp::RedactOperation op(req);gp::RedactResult result;
    QObject::connect(&op,&gp::RedactOperation::finished,&op,[&](const gp::RedactResult&r){result=r;});
    gp::RedactOperation::setFaultForTesting(gp::RedactOperation::Fault::Sanitize);op.run();gp::RedactOperation::setFaultForTesting(gp::RedactOperation::Fault::None);
    qInfo()<<"PARTIAL_OUTCOME"<<static_cast<int>(result.outcome)<<"REQUESTED_SANITIZE_DEST"<<req.sanitizedDestinationPath<<"RESULT_SANITIZE_DEST"<<result.sanitizedDestination;
    QString error;qInfo()<<"RETRY_USING_PRESENTER_ARGUMENTS"<<gp::RedactOperation::sanitizeCommittedFile(result.destination,result.sanitizedDestination,&error)<<error;
    PdfiumBackend reader;qInfo()<<"REDACTED_LOAD"<<reader.loadDocument(req.destinationPath)<<"REDACTED_TEXT"<<reader.extractText(0);
    qInfo()<<"SOURCE_HASH_UNCHANGED"<<(hash(src)==before);
    error.clear();qInfo()<<"RETRY_USING_ORIGINAL_REQUEST"<<gp::RedactOperation::sanitizeCommittedFile(result.destination,req.sanitizedDestinationPath,&error)<<error;
    const QString generated=d+"/podofo-source.pdf";
    {
        PoDoFo::PdfMemDocument doc;
        auto& page=doc.GetPages().CreatePage(PoDoFo::PdfPage::CreateStandardPageSize(PoDoFo::PdfPageSize::A4));
        PoDoFo::PdfPainter painter;painter.SetCanvas(page);
        auto& font=doc.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        painter.TextState.SetFont(font,12.0);
        (painter.DrawText)("TOPSECRET_DATA",50,700);
        (painter.DrawText)("PUBLIC_KEEP_TEXT",50,650);
        painter.FinishDrawing();doc.Save(generated.toUtf8().constData());
    }
    gp::RedactRequest next;next.sourcePath=generated;next.destinationPath=d+"/podofo-redacted.pdf";next.redactionsByPage[0]={QRectF(40,130,300,30)};
    gp::RedactOperation nextOp(next);gp::RedactResult nextResult;
    QObject::connect(&nextOp,&gp::RedactOperation::finished,&nextOp,[&](const gp::RedactResult&r){nextResult=r;});nextOp.run();
    PdfiumBackend nextReader;nextReader.loadDocument(next.destinationPath);
    qInfo()<<"PODOFO_FIXTURE_OUTCOME"<<static_cast<int>(nextResult.outcome)<<"TEXT"<<nextReader.extractText(0);
    return 0;
}
