#include <QApplication>
#include <QImage>
#include <QDebug>
#include <cstdio>
#include "ui/OcrScanCanvas.h"
int main(int argc,char**argv){
    qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){std::fprintf(stdout,"%s\n",s.toUtf8().constData());});
    QApplication app(argc,argv);
    gp::OcrScanCanvas canvas;canvas.resize(200,100);
    QImage source(100,100,QImage::Format_RGB32);source.fill(Qt::white);canvas.setPageImage(source);
    gp::OcrReviewedWord word;word.stableId=0;word.reviewedText="Review";word.boundingBox=QRectF(10,10,20,20);word.confidence=95;
    canvas.setWords({word});
    QImage rendered(canvas.size(),QImage::Format_RGB32);rendered.fill(Qt::black);canvas.render(&rendered);
    qInfo()<<"LETTERBOX_IMAGE_RECT"<<gp::OcrScanCanvas::imageRectFor(QSizeF(100,100),QRectF(0,0,200,100));
    qInfo()<<"EXPECTED_BOX_CENTER_70_20"<<rendered.pixelColor(70,20)<<"EXPECTED_NON_WHITE_OVERLAY"<<(rendered.pixelColor(70,20)!=QColor(Qt::white));
}
