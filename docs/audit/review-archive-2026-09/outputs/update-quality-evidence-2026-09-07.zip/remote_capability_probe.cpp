#include "core/Capability.h"
#include <QApplication>
#include <QDir>
#include <QFile>
#include <QDebug>
#include <QPushButton>
#include <cstdio>
int main(int argc,char**argv) {
    qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){std::fprintf(stdout,"%s\n",s.toUtf8().constData());});
    QApplication app(argc,argv);
    QCoreApplication::setApplicationName("GlyphRemoteCapabilityReview");
    QCoreApplication::setOrganizationName("GlyphReviewFixture");
    const QString modelDir=QCoreApplication::applicationDirPath()+"/models/ppocrv5";
    QDir().mkpath(modelDir);
    const QString detector=modelDir+"/PP-OCRv5_mobile_det_infer.onnx";
    QFile file(detector);
    if(file.exists()) { qWarning()<<"fixture destination already exists; refusing overwrite"; return 2; }
    if(!file.open(QIODevice::WriteOnly)) return 3;
    file.close();
    gp::CapabilityRegistry real;
    real.registerEngineProbes();
    qInfo()<<"DETECTOR_ONLY_ZERO_BYTES_STATUS"<<int(real.query(gp::CapId::OcrRapidModels).status)
           <<"AVAILABLE_ENUM"<<int(gp::Availability::Available);
    qInfo()<<"DETECTOR_ONLY_ENSEMBLE_STATUS"<<int(real.query(gp::CapId::OcrEnsemble).status);
    QFile::remove(detector);
    gp::CapabilityRegistry reg;
    bool ready=false;
    reg.registerProbe(gp::CapId::OfficeImport,[&](const QVariant&) {
        gp::Capability c;
        c.status=ready?gp::Availability::Available:gp::Availability::UnavailableRuntime;
        c.whyNot="Dependency missing";c.alternative="Install dependency";return c;
    });
    QPushButton widget;
    reg.applyToWidget(&widget,gp::CapId::OfficeImport);
    ready=true;reg.invalidate(gp::CapId::OfficeImport);
    reg.applyToWidget(&widget,gp::CapId::OfficeImport);
    qInfo()<<"AFTER_AVAILABLE_REFRESH_ENABLED"<<widget.isEnabled()<<"TOOLTIP"<<widget.toolTip();
    return 0;
}
