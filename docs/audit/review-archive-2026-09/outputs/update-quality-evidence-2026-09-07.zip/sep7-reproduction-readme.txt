GlyphPDF independent update review, 2026-09-07

Pinned revision: 95676e6a36ae9aadb2c98c39d47e55d4b0a9cfdd
Read UPDATE-QUALITY-REVIEW-2026-09-07.md first for interpretation and evidence limits.
Scripts are audit harnesses, not proposed production fixes. Some intentionally
exercise failures; the no-Tesseract harness records compiler exit 1 in its log.

The scripts assume their containing directory has these siblings:
  parity-95676e6/       source archive of the pinned commit
  build-parity-95676e6/ configured/built CMake Ninja output
They currently select C:/msys64/ucrt64/bin. Adjust paths for another machine.
Create the source archive with git archive of the exact hash. The build recipe in
review_sep7.py copies the declared vendor trees from a previous isolated snapshot;
on a new machine supply them from the trusted existing worktree as documented in
sep7-vendor-commit.txt, including headers/import libraries. Vendor binaries and the
large source archive are deliberately excluded from this evidence ZIP.

After configuration/build, run the Python harnesses:
  compile_sep7_probe.py        new N findings, real libraries/offscreen widgets
  compile_sep7_previous.py     prior engine, undo, conversion, compare/retry probes
  compile_sep7_canvas.py       actual OCR overlay painting
  compile_sep7_capability.py   incomplete model set and capability recovery
  sep7_compile_fallback.py     Qt-only syntax check
  review_sep7.py test          full CTest with 25 selected detailed Qt logs

Tests use disposable PDF fixtures and the repository test certificate. Full-suite
tests may write their own QSettings keys and start loopback-only test servers.
No user PDF or installed GlyphPDF UI was used. Retain failed assertions and
record model/hook skips. Merely passing the full suite does not close these findings.
