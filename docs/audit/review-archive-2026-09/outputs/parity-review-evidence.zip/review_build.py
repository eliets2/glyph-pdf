from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parent
env={k.upper():v for k,v in os.environ.items()}
env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
targets=['TestConversionExtraction','TestExportPathBadge','TestFormSafety','TestFormUndo','TestOllamaProvider','TestDiffEngine','TestCompareEntry','TestCompressDialogHonesty','TestOcrReviewLifecycle','TestSignatureBadges','TestOcrPreprocessor','TestControllers','PdfWorkstation']
with (root/'parity-build.log').open('w',encoding='utf-8') as log:
    r=subprocess.run([r'C:\msys64\ucrt64\bin\cmake.exe','--build',str(root/'build-parity-06b542d'),'--parallel','4','--target',*targets],env=env,stdout=log,stderr=subprocess.STDOUT)
print('Pinned snapshot build exit:',r.returncode,flush=True)
print((root/'parity-build.log').read_text(encoding='utf-8')[-8500:],flush=True)
