from pathlib import Path
import os, subprocess
root=Path(__file__).resolve().parent
env={k.upper():v for k,v in os.environ.items()}
snapshot=root/'parity-06b542d'
env['PATH']=';'.join([str(root/'build-parity-06b542d'),r'C:\msys64\ucrt64\bin',str(snapshot/'third_party/podofo/install/bin'),str(snapshot/'third_party/pdfium/bin'),str(snapshot/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')])
env['QT_QPA_PLATFORM']='offscreen'
targets=['TestConversionExtraction','TestExportPathBadge','TestFormSafety','TestFormUndo','TestOllamaProvider','TestDiffEngine','TestCompareEntry','TestCompressDialogHonesty','TestOcrReviewLifecycle','TestSignatureBadges','TestOcrPreprocessor','TestControllers']
with (root/'parity-tests.log').open('w',encoding='utf-8') as log:
    r=subprocess.run([r'C:\msys64\ucrt64\bin\ctest.exe','--test-dir',str(root/'build-parity-06b542d'),'--output-on-failure','--timeout','60','-R','^('+'|'.join(targets)+')$'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('Pinned snapshot targeted tests exit:',r.returncode,flush=True)
print((root/'parity-tests.log').read_text(encoding='utf-8')[-15000:],flush=True)
