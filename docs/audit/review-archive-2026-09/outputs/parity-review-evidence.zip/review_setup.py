from pathlib import Path
import zipfile, shutil, subprocess, os
root=Path(__file__).resolve().parent
snapshot=root/'parity-06b542d'
with zipfile.ZipFile(root/'parity-06b542d.zip') as z:
    z.extractall(snapshot)
repo=Path(r'C:\Users\User\Projects\pdf-parity')
for rel in ('third_party/podofo/install','third_party/pdfium','onnxruntime-win-x64-1.17.3'):
    shutil.copytree(repo/rel,snapshot/rel,dirs_exist_ok=True)
env={k.upper():v for k,v in os.environ.items()}
env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
cmd=[r'C:\msys64\ucrt64\bin\cmake.exe','-S',str(snapshot),'-B',str(root/'build-parity-06b542d'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug']
with (root/'parity-configure.log').open('w',encoding='utf-8') as log:
    result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Pinned 06b542d snapshot configure exit:',result.returncode,flush=True)
print((root/'parity-configure.log').read_text(encoding='utf-8')[-5000:],flush=True)
