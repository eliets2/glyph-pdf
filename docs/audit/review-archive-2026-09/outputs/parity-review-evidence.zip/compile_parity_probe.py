import os,pathlib,shlex,subprocess,sys,zipfile,xml.etree.ElementTree as ET
work=pathlib.Path(__file__).resolve().parent
build=work/'build-parity-06b542d'; root=work/'parity-06b542d'
env={k.upper():v for k,v in os.environ.items()}
env['PATH']=';'.join([str(build),'C:/msys64/ucrt64/bin',str(root/'third_party/podofo/install/bin'),str(root/'third_party/pdfium/bin'),str(root/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')])
env['QT_QPA_PLATFORM']='offscreen'
command=subprocess.check_output(['ninja','-t','commands','TestConversionExtraction'],cwd=build,env=env,text=True).splitlines()[-1]
libs=['libpdfws_engines.a']+shlex.split(command.split('  libpdfws_engines.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets'],env=env,text=True))
with (work/'parity-probe-build.log').open('w') as log:
    r=subprocess.run(['g++','-std=c++17','-I'+str(root/'src'),*flags,str(work/'parity_probe.cpp'),'-o','parity_probe.exe',*libs],cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode: print((work/'parity-probe-build.log').read_text());sys.exit(r.returncode)
with (work/'parity-probe.log').open('w') as log:
    r=subprocess.run([str(build/'parity_probe.exe')],cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
print((work/'parity-probe.log').read_text())
p=work/'parity-probe-data/table.xlsx'
if p.exists():
    with zipfile.ZipFile(p) as z:
        xml=z.read('xl/worksheets/sheet1.xml'); ET.fromstring(xml)
        print('XLSX_SHEET_XML:',xml.decode())
sys.exit(r.returncode)
