from pathlib import Path
import subprocess,json,hashlib,zipfile,re
w=Path(__file__).resolve().parent;s=w/'parity-95676e6';b=w/'build-parity-95676e6';out=w.parent/'outputs'
git=['git','-c','safe.directory=C:/Users/User/Projects/pdf-parity','-C',r'C:\Users\User\Projects\pdf-parity']
head='0caa45e7d0751caaa36a54a085c41211a422f019';prior='95676e6a36ae9aadb2c98c39d47e55d4b0a9cfdd';base='703fa34ece32733ea3b2093da94fa1aed94e1afc'
def cmd(*args):return subprocess.check_output(git+list(args),text=True,encoding='utf-8',errors='replace')
def save(n,t):(w/n).write_text(t,encoding='utf-8')
save('late-sep7.diff',cmd('diff','--no-ext-diff',prior+'..'+head))
save('latest-main-to-reviewed.diff',cmd('diff','--no-ext-diff',base+'..'+head))
save('late-sep7-log.txt',cmd('log','--oneline',prior+'..'+head))
save('late-sep7-diff-stat.txt',cmd('diff','--stat',prior+'..'+head))
with zipfile.ZipFile(w/'parity-0caa45e.zip') as z:
    changed=[p.filename for p in z.infolist() if not p.is_dir() and z.read(p)!=(s/p.filename).read_bytes()]
assert not changed,changed
assert (b/'CTestTestfile.cmake').read_text()==(w/'sep7-original-CTestTestfile.cmake').read_text()
qt={}
for p in sorted((w/'late-sep7-test-details').glob('*.txt')):
    qt[p.name]=[x for x in p.read_text(encoding='utf-8',errors='replace').splitlines() if x.startswith(('Totals:','FAIL','SKIP'))]
testlog=(w/'late-sep7-tests.log').read_text()
assert '100% tests passed, 0 tests failed out of 107' in testlog
same_paths=['src/shell/controllers/FormsController.cpp','src/commands/EditFormFieldCommand.h','src/engines/pdfium/PdfiumBackend.cpp','src/engines/ConversionManager.cpp','src/engines/DiffEngine.cpp','src/engines/ocr/OcrPreprocessor.cpp','src/ui/OcrScanCanvas.cpp','src/ui/SignaturePicker.cpp','src/core/PageLabels.cpp','src/engines/podofo/PoDoFoBackend.cpp']
with zipfile.ZipFile(w/'parity-95676e6.zip') as old:
    same={p:old.read(p)==(s/p).read_bytes() for p in same_paths}
manifest={
    'reviewed_commit':head,'fetch':'git fetch origin exit 0 during review',
    'preceding_reviewed_commit':prior,'main_baseline':base,
    'scope':'Late six-commit delta plus retained nine findings; exact snapshot, no later branch movement included',
    'source_archive_sha256':hashlib.sha256((w/'parity-0caa45e.zip').read_bytes()).hexdigest(),
    'isolated_source_dir_name':'parity-95676e6 (historical name; contains archived 0caa45e sources for final build)',
    'source_differences_from_reviewed_archive':changed,
    'build':'Full application/test targets build exit 0, same declared dependencies as initial 95676e6 build',
    'ctest':'107/107 pass, 38.24s',
    'detailed_qt_results':qt,
    'generated_test_registration_restored':True,
    'missing_registered_tests':['rapidModelsProbeRejectsFilenameOnly','rapidModelsProbeFullSetIsAvailableWithoutClassifier','rapidModelsProbeEmptyOrUnreadableFilesAreRejected','defaultSanitizePolicyIsSharedAndOn'],
    'unchanged_sources_from_initial_sep7_review':same,
    'verified_scoped_fixes':['D05 redaction transaction and retry safe replacement','D07 shared initial sanitize policy and explicit opt-out'],
    'partially_repaired':['D01 intended path repaired; Security banner residual','D06 empty-file rejection repaired; model readiness/resolution/refresh residuals'],
    'new_findings_retained':['N01','N02','N03','N04','N05','N06','N07','N08','N09'],
    'additional_finding':'N10 four new Qt tests are not registered',
    'old_form_findings':'V01/V02 remain; redaction test commit did not change their source',
    'worktree_status_after_review':cmd('status','--short'),
    'repository_edits_merge_install':False,
    'limits':['No sanitizer','No full alternate dependency matrix','No veraPDF conformance validation','No external Office round-trip','No installed-app review','Signing-repeat probe is not full partial-LTV modal retry','Security banner residual is caller trace'],
}
save('latest-sep7-manifest.json',json.dumps(manifest,indent=2))
save('latest-evidence-readme.txt','''Latest reviewed commit: 0caa45e7d0751caaa36a54a085c41211a422f019
Read LATEST-QUALITY-REVIEW-2026-09-07.md first. It overrides the earlier
95676e6 snapshot's D01/D05/D06/D07 status. Initial evidence remains preserved
in initial-95676e6-evidence.zip; its manifest correctly records 24 detailed Qt
logs (the original prose said 25 before the final inventory correction).

review_late_sep7.py overlaid a Git archive of 0caa45e into the existing isolated
source directory called parity-95676e6, then rebuilt all targets. The directory
name is historical. No production repository source/test assertions were edited.
latest-sep7-manifest.json verifies every tracked source against the new archive.

For reproductions, use the declared MSYS2/Qt/vendor dependencies described in
the initial evidence ZIP. Prepare source/build siblings under the paths expected
by the scripts, or adjust them for a new machine. Source archives and vendor
binaries are excluded for size; obtain the exact Git revisions and trusted
vendor trees. compile_late_probe.py uses late_snapshot_probe.cpp and includes
parity_probe.cpp. compile_late_capability.py uses late_capability_probe.cpp.
late_test_inventory.py prints Qt's executable test inventories without running
the cases; these prove four new functions are missing from the test registration.

Synthetic PDFs in sep7-probe-data are from the final 0caa45e probe run. They are
not private user documents. The earlier run's own fixtures are separately in
the nested initial evidence archive. No installed GlyphPDF UI was operated.
''')
files=['latest-sep7-manifest.json','latest-evidence-readme.txt','late-sep7.diff','latest-main-to-reviewed.diff','late-sep7-log.txt','late-sep7-diff-stat.txt','late-sep7-build.log','late-sep7-tests.log','review_late_sep7.py','late_test_inventory.py','late-TestCapabilityRegistry-functions.txt','late-TestRedactMarkAll-functions.txt','compile_late_probe.py','compile_late_capability.py','late_snapshot_probe.cpp','late_capability_probe.cpp','parity_probe.cpp','late-sep7-probe.log','late-sep7-probe-build.log','late-sep7-capability.log','late-sep7-capability-build.log','package_latest_sep7.py']
archive=out/'latest-quality-evidence-2026-09-07.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n in ['LATEST-QUALITY-REVIEW-2026-09-07.md','UPDATE-QUALITY-REVIEW-2026-09-07.md','GLM-FLASH-IMPLEMENTATION-AND-UI-PLAN-2026-09-05.md']:
        z.write(out/n,n)
    z.write(out/'update-quality-evidence-2026-09-07.zip','initial-95676e6-evidence.zip')
    for n in files:z.write(w/n,n)
    z.write(s/'docs/audit/CURRENT-EVIDENCE-LEDGER-2026-09-05.md','latest-reviewed-ledger.md')
    for folder in ['late-sep7-test-details','sep7-probe-data']:
        for p in sorted((w/folder).rglob('*')):
            if p.is_file():z.write(p,p.relative_to(w).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
for n in ['LATEST-QUALITY-REVIEW-2026-09-07.md','UPDATE-QUALITY-REVIEW-2026-09-07.md','GLM-FLASH-IMPLEMENTATION-AND-UI-PLAN-2026-09-05.md']:
    t=(out/n).read_text(encoding='utf-8')
    assert 'LATEST_VALIDATION_PENDING' not in t
    for link in re.findall(r'\]\((C:/[^)]+)\)',t):assert Path(link).exists(),link
print(json.dumps(manifest,indent=2))
print('Latest ZIP CRC and all current local delivery links verified.',archive.stat().st_size,'bytes')
