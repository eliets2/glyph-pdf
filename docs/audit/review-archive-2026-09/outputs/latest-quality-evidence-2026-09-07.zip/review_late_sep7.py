from pathlib import Path
import subprocess,os,sys,zipfile
w=Path(__file__).resolve().parent
s=w/'parity-95676e6' # Existing isolated incremental-build source directory; name is historical.
b=w/'build-parity-95676e6'
repo=Path(r'C:\Users\User\Projects\pdf-parity')
head='0caa45e7d0751caaa36a54a085c41211a422f019'
git=['git','-c','safe.directory=C:/Users/User/Projects/pdf-parity','-C',str(repo)]
env={k.upper():v for k,v in os.environ.items()}
env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')])
env['QT_QPA_PLATFORM']='offscreen'
mode=sys.argv[1]
if mode=='build':
    # Original 95676e6 source archive and evidence ZIP remain untouched.
    subprocess.run(git+['archive','--format=zip','--output='+str(w/'parity-0caa45e.zip'),head],check=True)
    with zipfile.ZipFile(w/'parity-0caa45e.zip') as z:z.extractall(s)
    with (w/'late-sep7-build.log').open('w') as log:
        r=subprocess.run(['cmake','--build',str(b),'--parallel','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Incremental full-target build exit',r.returncode,flush=True)
    print((w/'late-sep7-build.log').read_text()[-1500:]);sys.exit(r.returncode)
elif mode=='test':
    details=w/'late-sep7-test-details';details.mkdir(exist_ok=True)
    cfg=b/'CTestTestfile.cmake';original=cfg.read_text()
    targets=['TestCapabilityRegistry','TestOllamaProvider','TestRedactMarkAll','TestRedactTransaction']
    for name in targets:
        exe=str(b/(name+'.exe')).replace('\\','/')
        original_arg='"'+exe+'"'
        # Generated CTest format differs across CMake versions; replace only matching executable arguments.
        marker=str(details/(name+'.txt')).replace('\\','/')
        original_line=next(line for line in original.splitlines() if line.startswith('add_test('+name+' '))
        changed=original_line[:-1]+' "-o" "'+marker+',txt")'
        if name==targets[0]:patched=original
        patched=patched.replace(original_line,changed)
    cfg.write_text(patched)
    try:
        with (w/'late-sep7-tests.log').open('w') as log:
            r=subprocess.run(['ctest','--test-dir',str(b),'--output-on-failure','--parallel','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    finally:cfg.write_text(original)
    print('Latest full CTest exit',r.returncode,flush=True)
    print((w/'late-sep7-tests.log').read_text()[-2000:]);sys.exit(r.returncode)
