#define main originalAuditMain
#include "parity_probe.cpp"
#undef main
#include "ui/SignaturePicker.h"
#include "core/PageLabels.h"
#include "engines/PdfEditorEngine.h"
#include "engines/SignatureManager.h"
#include "engines/RedactOperation.h"
#include "modes/ModeController.h"
#include "modes/RedactMode.h"
#include "modes/RedactApplyDialog.h"
#include "modes/PagesMode.h"
#include "core/AppContext.h"
#include "ui/PdfViewerWidget.h"
#include <QToolButton>
#include <QTabWidget>
#include <QLineEdit>
#include <QCheckBox>
#include <QDialogButtonBox>
#include <QPushButton>
#include <podofo/podofo.h>
#include <fpdfview.h>
#include <fpdf_doc.h>
#include <fpdf_text.h>
#ifdef DrawText
#undef DrawText
#endif
static bool appearanceHasImage(const QString& path) {
    PoDoFo::PdfMemDocument doc;doc.Load(path.toUtf8().constData());
    for(const auto& obj:doc.GetObjects()) {
        if(obj->IsDictionary()) {
            const auto* type=obj->GetDictionary().FindKey("Subtype");
            if(type && type->IsName() && type->GetName()==PoDoFo::PdfName("Image")) return true;
        }
    }
    return false;
}
int main(int argc,char**argv) {
    qInstallMessageHandler([](QtMsgType,const QMessageLogContext&,const QString&s){std::fprintf(stdout,"%s\n",s.toUtf8().constData());});
    QApplication app(argc,argv);
    QCoreApplication::setOrganizationName("GlyphReviewFixture");QCoreApplication::setApplicationName("Sep7Review");
    QDir().mkpath("../sep7-probe-data");const QString dir=QDir("../sep7-probe-data").absolutePath();
    SignaturePickerDialog picker;
    auto*tabs=picker.findChild<QTabWidget*>();
    for(int i=0;i<tabs->count();++i)qInfo()<<"VISIBLE_TAB"<<i<<tabs->tabText(i);
    tabs->setCurrentIndex(2);
    picker.findChild<QLineEdit*>("signatureInitialsEdit")->setText("Jane Doe");
    qInfo()<<"VISIBLE_INITIALS_VALID_NAME_OK"<<picker.isAcceptEnabled();
    tabs->setCurrentIndex(3);
    qInfo()<<"VISIBLE_UPLOAD_NO_UPLOAD_OK"<<picker.isAcceptEnabled();
    picker.findChild<QDialogButtonBox*>()->button(QDialogButtonBox::Ok)->click();
    qInfo()<<"VISIBLE_UPLOAD_ACCEPTED_KIND"<<int(picker.acceptedKind())<<"INITIALS_ENUM"<<int(SignatureContent::Kind::Initials);
    SignatureSessionCache cache;DocumentSession session;
    QImage ink(20,20,QImage::Format_RGB32);ink.fill(Qt::blue);
    session.setPath("A.pdf");cache.noteDocument(session.path());cache.store(SignatureContent::Kind::Typed,ink,"Cached Name");
    session.setPath("B.pdf");session.setPath("A.pdf");cache.noteDocument(session.path());
    qInfo()<<"CACHE_AFTER_A_B_A_WITHOUT_PICKER"<<cache.hasSignature();
    SignaturePickerDialog reuse;reuse.setSessionCache(&cache);reuse.showTab(SignatureContent::Kind::Typed);
    qInfo()<<"CACHED_REUSE_CHECKED_EMPTY_TYPE_OK"<<reuse.isAcceptEnabled();
    qInfo()<<"APP_LABELS_27_28"<<gp::PageLabels::labelsFor(27,gp::PageLabels::Style::LowercaseLetters,2);
    const QString seed=makePdf(dir+"/seed.pdf","BT /F1 12 Tf 72 720 Td (Synthetic review text) Tj ET\n");
    const QString labeled=dir+"/labeled.pdf";
    {PoDoFo::PdfMemDocument pdf;pdf.Load(seed.toUtf8().constData());
        auto& labels=pdf.GetObjects().CreateDictionaryObject();
        PoDoFo::PdfDictionary rule;rule.AddKey("S",PoDoFo::PdfName("a"));rule.AddKey("St",PoDoFo::PdfObject(int64_t(28)));
        PoDoFo::PdfArray nums;nums.Add(PoDoFo::PdfObject(int64_t(0)));nums.Add(PoDoFo::PdfObject(rule));
        labels.GetDictionary().AddKey("Nums",nums);pdf.GetCatalog().GetDictionary().AddKey("PageLabels",labels.GetIndirectReference());
        pdf.Save(labeled.toUtf8().constData());}
    PdfiumBackend init;init.loadDocument(seed);
    FPDF_DOCUMENT doc=FPDF_LoadDocument(labeled.toUtf8().constData(),nullptr);unsigned short buf[100]={};
    FPDF_GetPageLabel(doc,0,buf,sizeof(buf));qInfo()<<"PDFIUM_LABEL_28"<<QString::fromUtf16(reinterpret_cast<char16_t*>(buf));FPDF_CloseDocument(doc);
    PdfEditorEngine engine;engine.loadDocumentForEditing(seed);
    const QString pdfa=dir+"/pdfa3u.pdf";qInfo()<<"PDFA3U_EXPORT"<<engine.exportPdfA(pdfa,5);
    {PoDoFo::PdfMemDocument out;out.Load(pdfa.toUtf8().constData());qInfo()<<"PDFA3U_VERSION_ENUM"<<int(out.GetMetadata().GetPdfVersion())<<"V2_ENUM"<<int(PoDoFo::PdfVersion::V2_0)<<"LEVEL_ENUM"<<int(out.GetMetadata().GetPdfALevel());}
    const QString p12=QDir("../parity-95676e6/tests/fixtures/signing").absoluteFilePath("test_signer.p12");
    SignatureManager mgr;mgr.setSignatureLevel(PAdESLevel::B_B);
    SignatureManager::setPendingAppearanceImage(ink);
    const QString signed1=dir+"/signed-first.pdf",signed2=dir+"/signed-retry.pdf";
    auto first=mgr.signDocument(seed,signed1,p12,"test","Audit",{});
    auto second=mgr.signDocument(seed,signed2,p12,"test","Audit",{});
    qInfo()<<"SAME_SIGNING_ARGS_OUTCOMES"<<int(first)<<int(second);
    if(QFile::exists(signed1)&&QFile::exists(signed2))qInfo()<<"SIGN_AP_IMAGE_FIRST_RETRY"<<appearanceHasImage(signed1)<<appearanceHasImage(signed2);
    gp::ModeController modes;auto* viewer=modes.findChild<PdfViewerWidget*>();
    modes.setScreen("redact");viewer->setToolMode(ToolMode::Redact);
    QObject::connect(&modes,&gp::ModeController::redactExitRequested,&modes,[&]{modes.setScreen(QString());});
    modes.findChild<QToolButton*>("redactBtnCancel")->click();
    qInfo()<<"CANCEL_EXIT_SCREEN"<<modes.currentScreen()<<"STILL_REDACT_TOOL"<<(viewer->toolMode()==ToolMode::Redact);
    gp::RedactRequest request;request.sourcePath=seed;request.destinationPath=dir+"/overlay-small-box.pdf";
    request.redactionsByPage[0]={QRectF(40,80,300,9)};request.overlayText="LABEL";
    gp::RedactOperation operation(request);gp::RedactResult result;
    QObject::connect(&operation,&gp::RedactOperation::finished,&operation,[&](const gp::RedactResult&r){result=r;});operation.run();
    qInfo()<<"SMALL_OVERLAY_OUTCOME"<<int(result.outcome);
    FPDF_DOCUMENT odoc=FPDF_LoadDocument(request.destinationPath.toUtf8().constData(),nullptr);
    if(odoc){auto page=FPDF_LoadPage(odoc,0);auto textpage=FPDFText_LoadPage(page);double highest=0;
        int count=FPDFText_CountChars(textpage);
        for(int i=0;i+4<count;++i)if(FPDFText_GetUnicode(textpage,i)=='L'&&FPDFText_GetUnicode(textpage,i+1)=='A'&&FPDFText_GetUnicode(textpage,i+2)=='B') {
            for(int j=i;j<i+5;++j){double l,r,b,t;FPDFText_GetCharBox(textpage,j,&l,&r,&b,&t);highest=qMax(highest,t);}
        }
        qInfo()<<"OVERLAY_GLYPH_PDF_TOP"<<highest<<"BOX_PDF_TOP"<<712.0<<"TEXT_SPILLS_ABOVE_BOX"<<(highest>712.0);
        FPDFText_ClosePage(textpage);FPDF_ClosePage(page);FPDF_CloseDocument(odoc);
    }
    qInfo()<<"REDACT_MODE_DEFAULT_SANITIZE"<<modes.findChild<QCheckBox*>("redactChkSanitizeCopy")->isChecked();
    gp::RedactApplyPlan defaultPlan;defaultPlan.sanitize=kDefaultSanitizeOn;
    gp::RedactApplyDialog defaultDialog(defaultPlan);
    auto* sanitizeBox=defaultDialog.findChild<QCheckBox*>("redactApplySanitizeCheck");
    qInfo()<<"SHARED_DEFAULT_DIALOG_SANITIZE"<<sanitizeBox->isChecked();
    sanitizeBox->setChecked(false);
    qInfo()<<"EXPLICIT_OPTOUT_PRESERVED"<<!defaultDialog.plan().sanitize;
    const QString splitSource=dir+"/split-source.pdf";
    {PoDoFo::PdfMemDocument pdf;pdf.Load(seed.toUtf8().constData());
        auto& pg=pdf.GetPages().CreatePage(PoDoFo::Rect(0,0,612,792));
        auto& font=pdf.GetFonts().GetStandard14Font(PoDoFo::PdfStandard14FontType::Helvetica);
        PoDoFo::PdfPainter paint;paint.SetCanvas(pg);paint.TextState.SetFont(font,12);
        (paint.DrawText)("SECOND_PART",72,700);paint.FinishDrawing();pdf.Save(splitSource.toUtf8().constData());}
    AppContext ctx;ctx.pdfEditor=std::make_shared<PdfEditorEngine>();ctx.document=std::make_shared<DocumentSession>();ctx.undoStack=std::make_shared<QUndoStack>();
    ctx.document->setPath(splitSource);ctx.pdfEditor->loadDocumentForEditing(splitSource);
    gp::PagesMode pages;pages.setAppContext(&ctx);
    const QString stub=dir+"/split-stub.pdf";
    gp::PagesMode::writeMinimalPdf(stub);
    {QFile f(stub);f.open(QIODevice::ReadOnly);const QByteArray bytes=f.readAll();
        qInfo()<<"STUB_ACTUAL_OFFSETS_1_2_3_XREF"<<bytes.indexOf("1 0 obj")<<bytes.indexOf("2 0 obj")<<bytes.indexOf("3 0 obj")<<bytes.indexOf("xref");}
    try {PoDoFo::PdfMemDocument pdf;pdf.Load(stub.toUtf8().constData());qInfo()<<"STUB_PODOFO_LOAD"<<true;}
    catch(const PoDoFo::PdfError& e){qInfo()<<"STUB_PODOFO_ERROR"<<e.what();}
    const QByteArray extracted=ctx.pdfEditor->extractPageAsBytes(splitSource,0);
    const QString validTarget=makePdf(dir+"/valid-target.pdf","");
    qInfo()<<"VALID_TARGET_INSERT_CONTROL"<<ctx.pdfEditor->insertPageFromBytes(validTarget,0,extracted);
    PdfEditorEngine targetEngine;targetEngine.loadDocumentForEditing(validTarget);
    qInfo()<<"SEPARATE_TARGET_ENGINE_INSERT"<<targetEngine.insertPageFromBytes(validTarget,0,extracted);
    PdfEditorEngine stubEngine;stubEngine.loadDocumentForEditing(stub);
    qInfo()<<"SEPARATE_STUB_ENGINE_INSERT"<<stubEngine.insertPageFromBytes(stub,0,extracted);
    const QStringList defaultParts=pages.executeSplit(splitSource,{{0},{1}},dir,"{stem}_part{n}.pdf");
    qInfo()<<"DEFAULT_SPLIT_REPORTED_PATHS"<<defaultParts;
    const QStringList parts=pages.executeSplit(splitSource,{{0},{1}},dir,"collision.pdf");
    qInfo()<<"SPLIT_REPORTED_PATHS"<<parts;
    PdfiumBackend splitReader;splitReader.loadDocument(dir+"/collision.pdf");
    qInfo()<<"SPLIT_FINAL_CONTENT"<<splitReader.extractText(0);
}
