Latest reviewed commit: 0caa45e7d0751caaa36a54a085c41211a422f019
Read LATEST-QUALITY-REVIEW-2026-09-07.md first. It overrides the earlier
95676e6 snapshot's D01/D05/D06/D07 status. Initial evidence remains preserved
in initial-95676e6-evidence.zip; its manifest correctly records 24 detailed Qt
logs (the original prose said 25 before the final inventory correction).

review_late_sep7.py overlaid a Git archive of 0caa45e into the existing isolated
source directory called parity-95676e6, then rebuilt all targets. The directory
name is historical. No production repository source/test assertions were edited.
latest-sep7-manifest.json verifies every tracked source against the new archive.

For reproductions, use the declared MSYS2/Qt/vendor dependencies described in
the initial evidence ZIP. Prepare source/build siblings under the paths expected
by the scripts, or adjust them for a new machine. Source archives and vendor
binaries are excluded for size; obtain the exact Git revisions and trusted
vendor trees. compile_late_probe.py uses late_snapshot_probe.cpp and includes
parity_probe.cpp. compile_late_capability.py uses late_capability_probe.cpp.
late_test_inventory.py prints Qt's executable test inventories without running
the cases; these prove four new functions are missing from the test registration.

Synthetic PDFs in sep7-probe-data are from the final 0caa45e probe run. They are
not private user documents. The earlier run's own fixtures are separately in
the nested initial evidence archive. No installed GlyphPDF UI was operated.
