from pathlib import Path
import os,subprocess
w=Path(__file__).resolve().parent;b=w/'build-parity-95676e6';s=w/'parity-95676e6'
env={k.upper():v for k,v in os.environ.items()};env['QT_QPA_PLATFORM']='offscreen'
env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')])
for name in ['TestCapabilityRegistry','TestRedactMarkAll']:
    r=subprocess.run([str(b/(name+'.exe')),'-functions'],env=env,text=True,capture_output=True,timeout=30)
    (w/('late-'+name+'-functions.txt')).write_text(r.stdout+r.stderr,encoding='utf-8')
    print(name,'inventory exit',r.returncode)
    expected=['rapidModelsProbeRejectsFilenameOnly','rapidModelsProbeFullSetIsAvailableWithoutClassifier','rapidModelsProbeEmptyOrUnreadableFilesAreRejected'] if name=='TestCapabilityRegistry' else ['defaultSanitizePolicyIsSharedAndOn']
    for e in expected:print(e,'REGISTERED' if e in r.stdout+r.stderr else 'MISSING')
