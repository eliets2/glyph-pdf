from pathlib import Path
import zipfile,shutil,subprocess,os,sys
w=Path(__file__).resolve().parent;s=w/'parity-4761443';b=w/'build-parity-4761443'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
mode=sys.argv[1]
if mode=='build':
    with zipfile.ZipFile(w/'parity-4761443.zip') as z:z.extractall(s)
    for rel in ('third_party/podofo/install','third_party/pdfium','onnxruntime-win-x64-1.17.3'):
        shutil.copytree(w/'parity-cf5ddc7'/rel,s/rel,dirs_exist_ok=True)
    with (w/'remote-configure.log').open('w') as log:r=subprocess.run(['cmake','-S',str(s),'-B',str(b),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-g0','-DCMAKE_C_FLAGS_DEBUG=-g0'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Configure exit:',r.returncode,flush=True)
    if r.returncode:print((w/'remote-configure.log').read_text());sys.exit(r.returncode)
    with (w/'remote-build.log').open('w') as log:r=subprocess.run(['cmake','--build',str(b),'--parallel','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Full build exit:',r.returncode,flush=True);print((w/'remote-build.log').read_text()[-6500:]);sys.exit(r.returncode)
elif mode=='test':
    env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env['PATH']]);env['QT_QPA_PLATFORM']='offscreen'
    with (w/'remote-tests.log').open('w') as log:r=subprocess.run(['ctest','--test-dir',str(b),'--output-on-failure','-j','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Full tests exit:',r.returncode,flush=True);print((w/'remote-tests.log').read_text()[-18000:]);sys.exit(r.returncode)
