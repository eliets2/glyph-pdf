from pathlib import Path
import os,subprocess,sys
w=Path(__file__).resolve().parent;b=w/'build-parity-4761443';s=w/'parity-4761443'
env={k.upper():v for k,v in os.environ.items()}
env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),r'C:\msys64\ucrt64\bin',env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
out=w/'remote-test-details';out.mkdir(exist_ok=True)
for name in sys.argv[1:]:
    r=subprocess.run([str(b/(name+'.exe')),'-o',str(out/(name+'.txt'))+',txt'],cwd=b,env=env,capture_output=True,timeout=90)
    print(name,'exit',r.returncode,flush=True)
    p=out/(name+'.txt')
    if p.exists():
        lines=p.read_text(errors='replace').splitlines()
        for i,line in enumerate(lines):
            if any(t in line for t in ('FAIL!','SKIP','Totals:')):print('\n'.join(lines[i:i+(4 if 'FAIL!' in line else 1)]),flush=True)
    else: print(r.stdout,r.stderr,flush=True)
