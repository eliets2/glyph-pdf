from pathlib import Path
import os,re,shutil,subprocess
w=Path(__file__).resolve().parent;b=w/'build-parity-4761443';s=w/'parity-4761443'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),r'C:\msys64\ucrt64\bin',env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
shutil.copyfile(b/'Testing/Temporary/LastTest.log',w/'remote-first-LastTest.log')
config=b/'CTestTestfile.cmake';original=config.read_text();(w/'remote-original-CTestTestfile.cmake').write_text(original)
names='TestBatchMode TestFormSafety TestFormUndo TestOllamaProvider TestOcrPreprocessor TestOcrPreprocessPrefs TestOcrReviewLifecycle TestOcrVerifyNavigation TestConversionExtraction TestExportPathBadge TestDiffEngine TestCompareEntry TestCompressDialogHonesty TestCompressJpegReencode TestOptimizeSignedGuard TestRedactMarkAll TestRedactSanitizeBundle TestSignaturePicker TestSignatureBadges TestSignatureAppearance TestTwoPageOverlay TestReadingOrderAsync TestAnnotationDjot TestWelcomeLayout TestTaskNavRegistry TestScreenStateSync TestRibbonCollapse TestStatusBarSlim TestRedactTransaction TestPagesMode TestCommentsReview TestCapabilityRegistry TestRapidOcr'.split()
out=w/'remote-test-details';out.mkdir(exist_ok=True)
patched=original
for name in names:
    patched=re.sub(r'(add_test\('+name+r' "[^"]+"\))',lambda m:m[0][:-1]+' "-o" "'+(out/(name+'.txt')).as_posix()+',txt")',patched)
config.write_text(patched)
try:
    with (w/'remote-retest.log').open('w') as log:r=subprocess.run(['ctest','--test-dir',str(b),'--output-on-failure','-j','4'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Diagnostic full rerun exit:',r.returncode);print((w/'remote-retest.log').read_text()[-1100:])
finally:config.write_text(original)
for p in sorted(out.glob('*.txt')):
    print(p.name)
    lines=p.read_text(errors='replace').splitlines()
    for i,line in enumerate(lines):
        if any(t in line for t in ('FAIL!','SKIP','Totals:')):print('\n'.join(lines[i:i+(4 if 'FAIL!' in line else 1)]))
