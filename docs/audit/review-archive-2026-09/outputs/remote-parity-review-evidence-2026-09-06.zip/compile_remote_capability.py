from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;b=w/'build-parity-4761443';s=w/'parity-4761443'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
commands=subprocess.check_output(['ninja','-t','commands','TestOcrVerifyNavigation'],cwd=b,env=env,text=True).splitlines()
command=next(x for x in reversed(commands) if '  libpdfws_ui.a' in x)
libs=['libpdfws_ui.a']+shlex.split(command.split('  libpdfws_ui.a',1)[1].split(' &&',1)[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets'],env=env,text=True))
with (w/'remote-capability-build.log').open('w') as log:
    r=subprocess.run(['g++','-std=c++17','-I'+str(s/'src'),*flags,str(w/'remote_capability_probe.cpp'),'-o','remote_capability_probe.exe',*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
if r.returncode:print((w/'remote-capability-build.log').read_text());raise SystemExit(r.returncode)
with (w/'remote-capability.log').open('w') as log:r=subprocess.run([str(b/'remote_capability_probe.exe')],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
print((w/'remote-capability.log').read_text());raise SystemExit(r.returncode)
