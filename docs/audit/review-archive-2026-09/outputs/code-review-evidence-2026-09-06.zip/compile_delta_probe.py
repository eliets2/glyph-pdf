from pathlib import Path
import os,shlex,subprocess
w=Path(__file__).resolve().parent;b=w/'build-parity-cf5ddc7';s=w/'parity-cf5ddc7'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=';'.join([str(b),'C:/msys64/ucrt64/bin',str(s/'third_party/podofo/install/bin'),str(s/'third_party/pdfium/bin'),str(s/'onnxruntime-win-x64-1.17.3/lib'),env.get('PATH','')]);env['QT_QPA_PLATFORM']='offscreen'
command=subprocess.check_output(['ninja','-t','commands','TestConversionExtraction'],cwd=b,env=env,text=True).splitlines()[-1]
libs=['libpdfws_engines.a']+shlex.split(command.split('  libpdfws_engines.a',1)[1].split(' &&',1)[0]);flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets'],env=env,text=True))
for name in ['parity_probe','delta_probe']:
    with (w/(name+'-cf5ddc7-build.log')).open('w') as log:
        r=subprocess.run(['g++','-std=c++17','-I'+str(s/'src'),'-I'+str(s/'third_party/podofo/install/include'),*flags,str(w/(name+'.cpp')),'-o',name+'.exe',*libs],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT)
    if r.returncode:print((w/(name+'-cf5ddc7-build.log')).read_text());raise SystemExit(r.returncode)
    with (w/(name+'-cf5ddc7.log')).open('w') as log:r=subprocess.run([str(b/(name+'.exe'))],cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
    print(name,'exit',r.returncode);print((w/(name+'-cf5ddc7.log')).read_text())
