from pathlib import Path
import zipfile,shutil,subprocess,os,sys,json
work=Path(__file__).resolve().parent;snapshot=work/'parity-cf5ddc7';build=work/'build-parity-cf5ddc7'
env={k.upper():v for k,v in os.environ.items()};env['PATH']=r'C:\msys64\ucrt64\bin;'+env.get('PATH','')
targets=['TestConversionExtraction','TestExportPathBadge','TestFormSafety','TestFormUndo','TestOllamaProvider','TestDiffEngine','TestCompareEntry','TestCompressDialogHonesty','TestOcrReviewLifecycle','TestSignatureBadges','TestOcrPreprocessor','TestControllers','TestWelcomeLayout','TestTaskNavRegistry','TestScreenStateSync','TestRibbonCollapse','TestStatusBarSlim','TestOcrVerifyNavigation','TestCommentsReview','TestPagesMode','TestRedactTransaction','TestRedactMarkAll','TestSignatureAppearance','PdfWorkstation']
mode=sys.argv[1] if len(sys.argv)>1 else 'build'
if mode=='build':
    with zipfile.ZipFile(work/'parity-cf5ddc7.zip') as z:z.extractall(snapshot)
    for rel in ('third_party/podofo/install','third_party/pdfium','onnxruntime-win-x64-1.17.3'):
        shutil.copytree(work/'parity-06b542d'/rel,snapshot/rel,dirs_exist_ok=True)
    with (work/'delta-configure.log').open('w') as log:
        r=subprocess.run(['cmake','-S',str(snapshot),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS_DEBUG=-g0','-DCMAKE_C_FLAGS_DEBUG=-g0'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Configure:',r.returncode,flush=True)
    if r.returncode:print((work/'delta-configure.log').read_text());sys.exit(r.returncode)
    with (work/'delta-build.log').open('w') as log:
        r=subprocess.run(['cmake','--build',str(build),'--parallel','4','--target',*targets],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Build:',r.returncode,flush=True);print((work/'delta-build.log').read_text()[-7000:]);sys.exit(r.returncode)
elif mode=='test':
    env['PATH']=';'.join([str(build),str(snapshot/'third_party/podofo/install/bin'),str(snapshot/'third_party/pdfium/bin'),str(snapshot/'onnxruntime-win-x64-1.17.3/lib'),env['PATH']]);env['QT_QPA_PLATFORM']='offscreen'
    with (work/'delta-tests.log').open('w') as log:
        r=subprocess.run(['ctest','--test-dir',str(build),'--output-on-failure','-R','^('+'|'.join(targets[:-1])+')$'],env=env,stdout=log,stderr=subprocess.STDOUT)
    print('Tests:',r.returncode);print((work/'delta-tests.log').read_text()[-14000:]);sys.exit(r.returncode)
