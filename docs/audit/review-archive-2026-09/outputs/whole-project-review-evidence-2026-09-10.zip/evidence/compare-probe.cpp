#include <QCoreApplication>
#include <QFile>
#include <QTemporaryDir>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <iostream>
#include "engines/DiffEngine.h"
static QString createPagePdf(const QString& dir, const QString& name,
                             const QStringList& pageTexts) {
    const int n = pageTexts.size();
    QByteArray pdf = "%PDF-1.4\n";
    QList<qint64> offsets;
    // Object layout: 1 catalog, 2 pages tree, page k at 3+2k, its content at
    // 4+2k, font at 3+2n. Object numbers stay dense (blank pages get an empty
    // stream object) so the xref stays byte-exact.
    offsets.append(pdf.size());
    pdf += "1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n";
    offsets.append(pdf.size());
    QByteArray kids;
    for (int k = 0; k < n; ++k)
        kids += QByteArray::number(3 + 2 * k) + " 0 R ";
    pdf += "2 0 obj<</Type/Pages/Kids[" + kids + "]/Count "
           + QByteArray::number(n) + ">>endobj\n";
    for (int k = 0; k < n; ++k) {
        const int pageNo = 3 + 2 * k;
        const int contNo = 4 + 2 * k;
        const QString line = pageTexts.at(k);
        QByteArray content;
        if (!line.isEmpty()) {
            QByteArray lit = line.toLatin1();
            lit.replace('\\', "\\\\").replace('(', "\\(").replace(')', "\\)");
            content = "BT /F1 12 Tf 72 720 Td (" + lit + ") Tj ET\n";
        }
        offsets.append(pdf.size());
        pdf += QByteArray::number(pageNo)
             + " 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents "
             + QByteArray::number(contNo)
             + " 0 R/Resources<</Font<</F1 " + QByteArray::number(3 + 2 * n)
             + " 0 R>>>>>>endobj\n";
        offsets.append(pdf.size());
        pdf += QByteArray::number(contNo) + " 0 obj<</Length "
             + QByteArray::number(content.size()) + ">>stream\n"
             + content + "endstream endobj\n";
    }
    offsets.append(pdf.size());
    pdf += QByteArray::number(3 + 2 * n)
         + " 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n";
    const qint64 xrefOffset = pdf.size();
    const int objCount = 4 + 2 * n;  // objects 0 .. (3+2n)
    pdf += "xref\n0 " + QByteArray::number(objCount) + "\n0000000000 65535 f \n";
    for (qint64 off : offsets)
        pdf += QByteArray::number(static_cast<qulonglong>(off)).rightJustified(10, '0')
               + " 00000 n \n";
    pdf += "trailer<</Size " + QByteArray::number(objCount) + "/Root 1 0 R>>\nstartxref\n"
         + QByteArray::number(xrefOffset) + "\n%%EOF\n";

    const QString path = dir + "/" + name;
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly)) return {};
    f.write(pdf);
    return path;
}


static QJsonObject summarize(const DiffResult& r) {
    QJsonArray pages, changes;
    qint64 overlayBytes = 0;
    for (const auto& p : r.pages) {
        overlayBytes += p.diffImage.sizeInBytes();
        pages.append(QJsonObject{{"index", p.pageIndex}, {"added", QJsonArray::fromStringList(p.textAdded)},
            {"removed", QJsonArray::fromStringList(p.textRemoved)}, {"pixels", p.pixelDiffCount},
            {"overlayBytes", double(p.diffImage.sizeInBytes())}});
    }
    for (const auto& c : r.pageChanges)
        changes.append(QJsonObject{{"type", int(c.type)}, {"old", c.oldPage}, {"new", c.newPage}});
    return {{"identical", r.isIdentical}, {"pageCount1", r.pageCount1}, {"pageCount2", r.pageCount2},
        {"pages", pages}, {"structural", changes}, {"totalOverlayBytes", double(overlayBytes)}};
}
int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    QTemporaryDir dir;
    if (!dir.isValid()) return 2;
    auto a = createPagePdf(dir.path(), "a.pdf", {"Alpha", "Beta", "Gamma"});
    auto b = createPagePdf(dir.path(), "b.pdf", {"Alpha", "Inserted", "Beta", "Gamma"});
    auto c = createPagePdf(dir.path(), "c.pdf", {"Alpha", "Beta", "Gamma"});
    QFile f(c); if (!f.open(QIODevice::Append)) return 3;
    f.write("\n% metadata-only container difference\n"); f.close();
    DiffEngine engine;
    QJsonObject out{{"middleInsertion", summarize(engine.compare(a,b,36))},
        {"equalPagesDifferentBytes", summarize(engine.compare(a,c,150))},
        {"sameBytesControl", summarize(engine.compare(a,a,36))}};
    std::cout << QJsonDocument(out).toJson().constData();
}
