from pathlib import Path
import subprocess, os, shlex, json, hashlib

w = Path(__file__).resolve().parent
s = w / 'source'
vendor = Path('C:/Users/User/Projects/pdf-parity/third_party/pdfium')
env = {k.upper(): v for k, v in os.environ.items()}
env['PATH'] = str(vendor / 'bin') + ';C:/msys64/ucrt64/bin;' + env['PATH']
test = (s / 'tests/TestDiffEngine.cpp').read_text(encoding='utf8')
fixture = test[test.index('static QString createPagePdf'):test.index('class TestDiffEngine')]
probe = '''#include <QCoreApplication>
#include <QFile>
#include <QTemporaryDir>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <iostream>
#include "engines/DiffEngine.h"
'''+fixture+'''
static QJsonObject summarize(const DiffResult& r) {
    QJsonArray pages, changes;
    qint64 overlayBytes = 0;
    for (const auto& p : r.pages) {
        overlayBytes += p.diffImage.sizeInBytes();
        pages.append(QJsonObject{{"index", p.pageIndex}, {"added", QJsonArray::fromStringList(p.textAdded)},
            {"removed", QJsonArray::fromStringList(p.textRemoved)}, {"pixels", p.pixelDiffCount},
            {"overlayBytes", double(p.diffImage.sizeInBytes())}});
    }
    for (const auto& c : r.pageChanges)
        changes.append(QJsonObject{{"type", int(c.type)}, {"old", c.oldPage}, {"new", c.newPage}});
    return {{"identical", r.isIdentical}, {"pageCount1", r.pageCount1}, {"pageCount2", r.pageCount2},
        {"pages", pages}, {"structural", changes}, {"totalOverlayBytes", double(overlayBytes)}};
}
int main(int argc, char** argv) {
    QCoreApplication app(argc, argv);
    QTemporaryDir dir;
    if (!dir.isValid()) return 2;
    auto a = createPagePdf(dir.path(), "a.pdf", {"Alpha", "Beta", "Gamma"});
    auto b = createPagePdf(dir.path(), "b.pdf", {"Alpha", "Inserted", "Beta", "Gamma"});
    auto c = createPagePdf(dir.path(), "c.pdf", {"Alpha", "Beta", "Gamma"});
    QFile f(c); if (!f.open(QIODevice::Append)) return 3;
    f.write("\\n% metadata-only container difference\\n"); f.close();
    DiffEngine engine;
    QJsonObject out{{"middleInsertion", summarize(engine.compare(a,b,36))},
        {"equalPagesDifferentBytes", summarize(engine.compare(a,c,150))},
        {"sameBytesControl", summarize(engine.compare(a,a,36))}};
    std::cout << QJsonDocument(out).toJson().constData();
}
'''
(w / 'compare-probe.cpp').write_text(probe, encoding='utf8')
sources = [s / ('src/' + p) for p in ['engines/DiffEngine.cpp', 'engines/MyersDiff.cpp',
    'engines/pdfium/PdfiumBackend.cpp', 'engines/pdfium/PdfiumEnvironment.cpp']]
flags = shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','Qt6Core','Qt6Gui'], env=env, text=True))
cmd = ['g++','-std=c++17','-O2','-DHAS_PDFIUM','-I'+str(s/'src'),'-I'+str(vendor/'include'),
    str(w/'compare-probe.cpp'),*[str(p) for p in sources],str(vendor/'lib/libpdfium.dll.a'),
    '-o',str(w/'compare-probe.exe'),*flags]
r = subprocess.run(cmd, env=env, text=True, capture_output=True)
(w/'compare-build.log').write_text(r.stdout+r.stderr, encoding='utf8'); r.check_returncode()
r = subprocess.run([str(w/'compare-probe.exe')], env=env, text=True, capture_output=True, timeout=30)
(w/'compare-stderr.log').write_text(r.stderr, encoding='utf8'); r.check_returncode()
result = {'method':'Fresh -O2 build of current DiffEngine, MyersDiff and PDFium backend; real hand-built PDFs using repository fixture helper; no UI harness',
    'sourceSha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
    'pdfiumDllSha256':hashlib.sha256((vendor/'bin/pdfium.dll').read_bytes()).hexdigest(),
    'results':json.loads(r.stdout)}
(w/'compare-results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result,indent=2))
