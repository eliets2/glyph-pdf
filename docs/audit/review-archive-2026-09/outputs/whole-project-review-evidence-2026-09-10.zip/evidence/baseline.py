from pathlib import Path
import subprocess,json,zipfile,hashlib,shutil
w=Path(__file__).resolve().parent;repo=Path(r'C:\Users\User\Projects\pdf-parity')
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),*args])
head=git('rev-parse','HEAD').decode().strip();upstream=git('rev-parse','origin/feat/parity-glm').decode().strip()
archive=w/'source.zip'
if not archive.exists():subprocess.run(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'archive','--format=zip','--output='+str(archive),head],check=True)
src=w/'source';src.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():
  p=(src/n).resolve()
  if not p.is_relative_to(src.resolve()):raise RuntimeError(n)
 z.extractall(src)
(w/'dirty.diff').write_bytes(git('diff','--binary'))
(w/'local-vs-upstream.diff').write_bytes(git('diff',upstream,head))
(w/'main-vs-upstream.stat').write_bytes(git('diff','--stat','main..origin/feat/parity-glm'))
dirty=[]
for rel in git('diff','--name-only').decode().splitlines():
 p=repo/rel
 if p.is_file():
  dest=w/'dirty-files'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
  dirty.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
context=repo/'.context/research'
if context.exists():shutil.copytree(context,w/'context-research',dirs_exist_ok=True)
manifest={'head':head,'upstream':upstream,'main':git('rev-parse','main').decode().strip(),'status':git('status','--short','--branch').decode(),'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'dirty':dirty,'sourceFiles':len(list(src.rglob('*'))),'scope':'committed source snapshot; uncommitted changes preserved separately; vendor binaries not copied'}
(w/'baseline.json').write_text(json.dumps(manifest,indent=2),encoding='utf8');print(json.dumps(manifest,indent=2))
