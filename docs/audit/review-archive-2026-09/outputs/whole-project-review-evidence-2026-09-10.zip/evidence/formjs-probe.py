from pathlib import Path
import subprocess, os, shlex, json, hashlib, zipfile, io, time

w=Path(__file__).resolve().parent
repo='C:/Users/User/Projects/pdf-parity'
ref='b38a4fd524e754fc91981f7bbeba254d85674c24'
base=['git','-c','safe.directory='+repo,'-C',repo]
data=subprocess.check_output(base+['archive','--format=zip',ref,'src/engines/formjs'])
s=w/'local-formjs-source';s.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(data)) as z:z.extractall(s)
env={k.upper():v for k,v in os.environ.items()};env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
probe=r'''#include <QCoreApplication>
#include <QElapsedTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <iostream>
#include "engines/formjs/FormJsSandbox.h"
int main(int argc, char** argv) {
    QCoreApplication app(argc,argv);
    gp::formjs::FormJsSandbox box;
    QString error;
    if (!box.isValid() || !box.installShim(&error)) {std::cerr<<error.toStdString();return 2;}
    box.setFieldValues({{"total", "0"}});
    QString mode=argc>1?QString::fromUtf8(argv[1]):"normal";
    QString code="event.value = 42;";
    if(mode=="loop") code="while(true) {}";
    if(mode=="endHook") code="globalThis.__gpEndEvent = function() { while(true) {} }; event.value=42;";
    if(mode=="getter") code="Object.defineProperty(event, 'value', { get() { while(true) {} } });";
    QElapsedTimer clock;clock.start();
    auto r=box.runEvent(code,"total","Calculate","0",50);
    QJsonObject out{{"ok",r.ok},{"kind",int(r.kind)},{"value",r.value},{"message",r.message},
        {"elapsedMs",double(clock.elapsed())}};
    std::cout<<QJsonDocument(out).toJson(QJsonDocument::Compact).constData();
}
'''
(w/'formjs-probe.cpp').write_text(probe,encoding='utf8')
src=[s/'src/engines/formjs/FormJsSandbox.cpp',s/'src/engines/formjs/AFormShim.cpp']
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','Qt6Core'],env=env,text=True))
cmd=['g++','-O2','-std=c++17','-DHAS_QUICKJS','-I'+str(s/'src'),str(w/'formjs-probe.cpp'),
    *[str(p) for p in src],'-o',str(w/'formjs-probe.exe'),*flags,'-lqjs']
r=subprocess.run(cmd,env=env,text=True,capture_output=True)
(w/'formjs-build.log').write_text(r.stdout+r.stderr,encoding='utf8');r.check_returncode()
rows=[]
for mode in ['normal','loop','endHook','getter']:
    start=time.monotonic()
    try:
        r=subprocess.run([str(w/'formjs-probe.exe'),mode],env=env,text=True,capture_output=True,timeout=3)
        rows.append({'mode':mode,'childKilledByHarness':False,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    except subprocess.TimeoutExpired:
        rows.append({'mode':mode,'childKilledByHarness':True,'timeoutSeconds':3,'elapsedSeconds':time.monotonic()-start})
result={'localUnpublishedRef':ref,'method':'Fresh current FormJsSandbox + AFormShim compiled -O2 against installed quickjs-ng. 50ms event deadline, harness kills its own child after3s. Not full form UI or full suite.',
    'sourceSha256':{str(p.relative_to(s)):hashlib.sha256(p.read_bytes()).hexdigest() for p in src},
    'runtimeSha256':hashlib.sha256(Path('C:/msys64/ucrt64/bin/libqjs-0.dll').read_bytes()).hexdigest(),
    'cases':rows}
(w/'formjs-deadline-results.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result,indent=2))
