from pathlib import Path
import subprocess,os,shlex,json,statistics,hashlib
w=Path(__file__).resolve().parent;s=w/'source';env={k.upper():v for k,v in os.environ.items()};env['PATH']='C:/msys64/ucrt64/bin;'+env['PATH']
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','Qt6Core'],env=env,text=True))
cmd=['g++','-std=c++17','-O2','-I'+str(s/'src'),str(w/'perf-probe.cpp'),str(s/'src/engines/MyersDiff.cpp'),'-o',str(w/'perf-probe.exe'),*flags,'-lpsapi']
r=subprocess.run(cmd,env=env,text=True,capture_output=True);(w/'perf-build.log').write_text(r.stdout+r.stderr,encoding='utf8');r.check_returncode()
rows=[]
for n in [500,1000,2000]:
 for mode in ['same','different']:
  for trial in range(3):
   r=subprocess.run([str(w/'perf-probe.exe'),str(n),mode],env=env,text=True,capture_output=True,timeout=20);r.check_returncode();row=json.loads(r.stdout);row['trial']=trial+1;rows.append(row)
result={'sourceSha256':hashlib.sha256((s/'src/engines/MyersDiff.cpp').read_bytes()).hexdigest(),'method':'Actual current MyersDiff.cpp compiled -O2; Qt6Core; separate process per sample; synthetic token lists; not end-to-end PDF timing','compiler':subprocess.check_output(['g++','--version'],env=env,text=True).splitlines()[0],'samples':rows}
(w/'myers-benchmark.json').write_text(json.dumps(result,indent=2),encoding='utf8')
for n in [500,1000,2000]:
 for same in [True,False]:
  selected=[r for r in rows if r['tokensEach']==n and r['identical']==same]
  print(json.dumps({'tokensEach':n,'identical':same,'medianMs':statistics.median(r['elapsedMs'] for r in selected),'maxPeakMiB':max(r['peakWorkingSetBytes'] for r in selected)/1048576,'allCountChecksPassed':all(r['countsCorrect'] for r in selected)}))
