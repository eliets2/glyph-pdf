from pathlib import Path
import csv, hashlib, json, re, zipfile

w=Path(__file__).resolve().parent
out=w.parents[1]/'outputs'
cols=['id','phase','priority','work_package','owner','depends_on','evidence','acceptance_gate','source_or_report']
rows=[
('R01','0','P1','Freeze candidate and reconcile verification labels','integrator + independent reviewer','','Published backlog includes awaiting-review in SHIPPED','Each capability records implementation ref; review result; artifact/release status separately; no automatic upgrades','CURRENT-EVIDENCE-LEDGER; RESEARCH-BACKLOG line17; published-baseline.json'),
('R02','1','P1','Preserve earlier resident edits on every failed commit','backend specialist','R01','Source-traced watermark then failed Save rollback','Failure leaves disk and complete pre-operation resident state intact; later retry persists prior work','WHOLE-ARCHITECTURE-REVIEW'),
('R03','1','P1','Complete mutation and checked history coverage','backend specialist + testing specialist','R02','Rotate and inline-text commands still unchecked','Fail redo/undo/reload at shared seams; history index dirty state and retryability remain truthful','WHOLE-ARCHITECTURE-REVIEW'),
('R04','1','P1','Safe encrypted-package replacement and helper lifecycle','backend specialist','R01','Source pre-delete before external tool succeeds','Existing package survives launch/tool/write failure; cancel stops owned process; only validated candidate replaces destination','WHOLE-ARCHITECTURE-REVIEW'),
('R05','1','P1','Form JavaScript whole-operation deadline','security auditor + backend specialist','R01','Two actual b38a4fd post-eval deadline bypasses reproduced','All JS entry and result handling bounded; endHook/getter return safely; control semantics preserved; no external kill needed','PERFORMANCE-AND-SCRIPT-REVIEW JS-01; formjs-deadline-results.json'),
('R06','1','P1','One alignment mapping for document comparison','backend specialist','R01','Real PDF insertion produces false Beta/Gamma content changes','Inserted page appears once; unchanged matched pages have no false text/pixel changes; all exports/navigation agree','PERFORMANCE-AND-SCRIPT-REVIEW PERF-01; compare-results.json'),
('R07','1','P1','Truthful content replacement and match model','backend specialist + UI specialist','R03','Source overlay and fixed rectangle; unchecked Replace All','Old text actually removed when replacing; surrounding text preserved; regex/options/ranges align; failed writes excluded from count; read-only enforced','WHOLE-PRODUCT-AND-PLAN-REVIEW'),
('R08','1','P1','Print range job ownership and error outcomes','UI specialist + backend specialist','R01','Source print path ignores selection and reads live view-owned PDF','Selected ranges/order honored; snapshot owned by job; cancel/switch/close safe; painter/spool failures visible','WHOLE-PRODUCT-AND-PLAN-REVIEW; NATIVE-LINUX-READINESS'),
('R09','1','P1','Repair/recovery load identity and save conflicts','backend specialist','R02','Repair success misses load identity; external file guard absent in inspected path','Every new load increments identity; stale callbacks rejected; concurrent external change never silently overwritten','WHOLE-ARCHITECTURE-REVIEW'),
('R10','1','P1','Temporary data ownership and liveness','backend specialist + security auditor','R01','Age/name cleanup lacks active-session ownership checks','Second instance cannot delete first active session; only owned proven orphan data cleaned; fail closed when private root creation fails','WHOLE-ARCHITECTURE-REVIEW'),
('R11','2','P2','Bound comparison resource use','performance optimizer','R06','Empty overlays25.245MB for3pages; Myers134MiB for2000 divergenttokens/side','Streaming hash; bounded overlay retention and algorithm work; cancellation; correct typical small edits','PERFORMANCE-AND-SCRIPT-REVIEW PERF-02/PERF-03'),
('R12','2','P2','Guard and profile actual render paths','performance optimizer','R01','Separate active viewer cache and unchecked render dimensions','Finite sizes/scales checked preallocation; operation budget; current view path profiled; stale output suppressed','PERFORMANCE-AND-SCRIPT-REVIEW PERF-04'),
('R13','1','P2','Fix PDFium terminator count handling','backend specialist','R01','Actual tokens include appended NUL','Exact strings for empty/single/multiline/Unicode; only API terminator removed','PERFORMANCE-AND-SCRIPT-REVIEW PERF-05'),
('R14','2','P1','Independent review of recently implemented packages','independent verification agent','R01;R02;R03','Published G01-G20 and signing repairs await independent gate','Negative control fails before repair; current real artifacts pass; preserve meaningful optional-build skips; ledger records exact testedref','CURRENT-EVIDENCE-LEDGER; published-delta.log'),
('R15','2','P2','Canonical command binding and honest feature discovery','UI specialist','R03;R07;R08','52 hidden planned ribbon entries; standalone control state mismatches','Menu/ribbon/shortcut share command state; planned entries visibly explained; no enabled no-op buttons','WHOLE-PRODUCT-AND-PLAN-REVIEW; UI-BUTTON-REVIEW'),
('R16','2','P2','Task-oriented welcome and result feedback','UX specialist + UI specialist','R15','Six narrow cards; Convert/Protect only Open','Twelve useful task routes preserve intent; responsive layout; recent files; output actions; counts reflect commits','WHOLE-PROJECT-READINESS-REVIEW UI section'),
('R17','2','P2','Keyboard accessibility localization and scale pass','UI specialist + testing specialist','R15;R16','Source review only; current native build UI not yet inspected','Keyboard/screenreader complete workflows; ArabicRTL/CJK;100-200% mixedDPI; no inaccessible disabled reasons','WHOLE-PROJECT-READINESS-REVIEW UI section'),
('R18','2','P1','Finish form compatibility and stale-result disclosure','backend specialist + testing specialist','R05;R03','Local Calculate/Format only; display preview and remaining phases differ','Real forms + dependent failures; correct tab vs calculationorder; pin shim/library; persistent stale-field warnings; runtimeclosure; noengine build','PERFORMANCE-AND-SCRIPT-REVIEW Form JavaScript release conditions'),
('R19','2','P2','Signing settings and effective capability honesty','security specialist + UI specialist','R14','No production TSA/level setters in published snapshot','Timestamp/level actions either configured and independently validated or explain unavailable state; preserve retries and old output','WHOLE-PRODUCT-AND-PLAN-REVIEW'),
('R20','3','P1','Native Linux toolchain and dependency closure','devops engineer','R01','Windows defaults flags and binary artifact discovery','Clean native configure/build without Windows trees; platformarch manifests; package closure; no forbidden linkdeps','NATIVE-LINUX-READINESS L01-L06'),
('R21','3','P1','Native Linux file and credential safety','backend specialist + security auditor','R20;R09;R10','Nonatomic autosave and publicidentifier key derivation','Atomic replacement failures preserve recovery; SecretService lock/unavailable fallback sessiononly; correct private paths','NATIVE-LINUX-READINESS L07-L08'),
('R22','3','P1','Installed resources and clean-machine release gate','devops engineer','R14;R20','Djot path points at source tree; portable registry promise differs','Installed app works with source/toolchain hidden; models/fonts/Qtplugins/runtime hashes present; installupgradeuninstall tested','NATIVE-LINUX-READINESS L09-L10; WHOLE-PROJECT-READINESS'),
('R23','3','P2','Native desktop and package channel','devops engineer + UI specialist','R21;R22;R08','Full Linux product runtime unverified','DesktopMIME/XDG/portals/printing/Wayland/X11/IME/clipboard/keyring passed on declared matrix; authenticated packageupdates','NATIVE-LINUX-READINESS staged plan'),
('R24','3','P2','Managed policy and privacy-safe diagnostics','solution architect + security auditor','R15;R22','Runtime enterprise policy layer unproven','Machinepolicy overrides userprefs and is visible; local supportbundle omits PDFtext/secrets; networkbehavior explicit','WHOLE-PROJECT-READINESS corporate readiness table'),
('R25','3','P1','Release evidence dependency security and soak','devops engineer + independent reviewer','R11;R12;R14;R17;R18;R19;R22','Prior full-suite results belong to older commits','Exact Releasecandidate fullsuite + optionalconfigs; SBOM/runtimehashes; cleanmachine verification; resource/cancel benchmarks; completedsoak','WHOLE-PROJECT-READINESS Gate3'),
('R26','4','P2','Deliver high-value workflow expansions','product planner + bounded implementers','R25','Batchpresets signingrequests accessibilityauthoring mostly planned','Choose pilot workflows; extend existing seams; defined unsupported scope; real savedartifacts; independent perpackage review','WHOLE-PRODUCT-AND-PLAN-REVIEW featurematrix'),
('R27','4','P2','Observed customer pilot and positioning','UX specialist + product owner','R25','Competitive claims mostly research not comparative validation','Measure completiontime/discovery/recovery in approved forms legal scanning workflows; limit claims to proven releasedfeatures','WHOLE-PROJECT-READINESS Gate4')
]
csv_path=out/'WHOLE-PROJECT-IMPLEMENTATION-BACKLOG-2026-09-10.csv'
wording={
    'endHook/getter':'end-hook/getter cases', 'platformarch':'platform/architecture',
    'linkdeps':'linked dependencies', 'SecretService':'Secret Service', 'sessiononly':'session only',
    'Windows trees':'Windows binary trees', 'installupgradeuninstall':'install, upgrade and uninstall',
    'DesktopMIME/XDG/portals/printing/Wayland/X11/IME/clipboard/keyring':'Desktop MIME, XDG, portals, printing, Wayland/X11, IME, clipboard and keyring',
    'packageupdates':'package updates', 'Machinepolicy':'Machine policy', 'userprefs':'user preferences',
    'supportbundle':'support bundle', 'PDFtext/secrets':'PDF text or secrets', 'networkbehavior':'network behavior',
    'Releasecandidate fullsuite':'Release candidate full suite', 'optionalconfigs':'optional configurations',
    'SBOM/runtimehashes':'SBOM/runtime hashes', 'cleanmachine':'clean-machine', 'completedsoak':'completed soak',
    'Batchpresets signingrequests accessibilityauthoring':'Batch presets, signing requests and accessibility authoring',
    'savedartifacts':'saved artifacts', 'perpackage':'per-package', 'completiontime/discovery/recovery':'completion time, discovery and recovery',
    'releasedfeatures':'released features', 'featurematrix':'feature matrix', 'default100':'default 100',
    'ArabicRTL/CJK;100-200% mixedDPI':'Arabic RTL/CJK; 100–200% mixed DPI',
    'tab vs calculationorder':'tab versus calculation order', 'runtimeclosure':'runtime closure',
    'noengine':'no-engine', 'testedref':'tested ref', 'publicidentifier':'public-identifier',
    'pixels/scales':'pixels/scales', '25.245MB for3pages':'25.245 MB for 3 pages',
    'Myers134MiB for2000 divergenttokens/side':'Myers 134 MiB for 2,000 divergent tokens per side',
    '50ms':'50 ms', 'preallocation':'before allocation', 'buildresources':'build resources'
}
def readable(value):
    for before,after in wording.items():value=value.replace(before,after)
    return value
rows=[tuple(readable(value) for value in row) for row in rows]
with csv_path.open('w',encoding='utf-8-sig',newline='') as f:
    wr=csv.writer(f);wr.writerow(cols);wr.writerows(rows)

# Normalize only the primary reviewer's two artifacts; other agents own theirs.
for name in ['WHOLE-PROJECT-READINESS-REVIEW-2026-09-10.md','PERFORMANCE-AND-SCRIPT-REVIEW-2026-09-10.md']:
    p=out/name;t=p.read_text(encoding='utf8').replace('</C:/','<C:/')
    if 'Finalized 2026-09-11' not in t:
        t=t.replace('\n\n','\n\nFinalized 2026-09-11 against the explicitly recorded September 10 source snapshots. Later commits are outside this report.\n\n',1)
    p.write_text(t,encoding='utf8')

unchanged={}
for p in ['src/engines/DiffEngine.cpp','src/engines/MyersDiff.cpp','src/engines/pdfium/PdfiumBackend.cpp','src/engines/pdfium/PdfiumEnvironment.cpp']:
    a=hashlib.sha256((w/'source'/p).read_bytes()).hexdigest()
    b=hashlib.sha256((w/'published-source'/p).read_bytes()).hexdigest()
    unchanged[p]={'initial':a,'published':b,'identical':a==b}
assert all(v['identical'] for v in unchanged.values())
myers=json.loads((w/'myers-benchmark.json').read_text())
compare=json.loads((w/'compare-results.json').read_text())
js=json.loads((w/'formjs-deadline-results.json').read_text())
assert len(myers['samples'])==18 and all(x['countsCorrect'] for x in myers['samples'])
assert compare['results']['equalPagesDifferentBytes']['totalOverlayBytes']==25245000
assert compare['results']['middleInsertion']['pages'][2]['removed']==['Gamma\u0000']
assert [x['childKilledByHarness'] for x in js['cases']]==[False,False,True,True]
ids={r[0] for r in rows};assert len(ids)==len(rows)
for r in rows:
    assert not r[5] or all(d in ids for d in r[5].split(';'))
with csv_path.open(encoding='utf-8-sig',newline='') as f:
    assert len(list(csv.DictReader(f)))==27

documents=list(out.glob('*2026-09-10.md'))
broken=[];links=0
for p in documents:
    content=p.read_text(encoding='utf8')
    targets=re.findall(r'\]\((<?C:/[^)]+)\)',content)
    targets+=re.findall(r'^\[[^\]]+\]:\s*(C:/[^\r\n]+)',content,re.M)
    for raw in targets:
        target=raw.strip('<>');line=re.search(r':(\d+)$',target);target=re.sub(r':\d+$','',target)
        links+=1
        if not Path(target).exists():broken.append({'document':p.name,'target':target})
        elif line and Path(target).is_file():
            if int(line[1])>len(Path(target).read_text(encoding='utf8').splitlines()):
                broken.append({'document':p.name,'target':target,'line':int(line[1])})
verification={'finalized':'2026-09-11','initialAndPublishedProbeSources':unchanged,
    'myersCountChecks':18,'compareProbe':'false content changes and retained empty overlays reproduced',
    'localFormJsProbe':'two deadline bypasses reproduced; two controls completed',
    'backlogRows':len(rows),'localLinksChecked':links,'brokenLinks':broken,
    'validationLimits':['No fresh full application Release suite at 9ba3cea or b38a4fd','No native Linux build or desktop QA','No current installed UI or physical-printer test','No new 48-hour soak']}
(out/'WHOLE-PROJECT-REVIEW-VERIFICATION-2026-09-10.json').write_text(json.dumps(verification,indent=2),encoding='utf8')

evidence=[]
for p in w.iterdir():
    if p.is_file() and p.name != 'evidence-manifest.json' and p.suffix in ('.py','.cpp','.json','.log','.diff','.stat'):
        evidence.append(p)
evidence+=list((w/'local-formjs-source').rglob('*.cpp'))+list((w/'local-formjs-source').rglob('*.h'))
for p in unchanged:evidence.append(w/'published-source'/p)
reports=[*documents,csv_path,out/'WHOLE-PROJECT-REVIEW-VERIFICATION-2026-09-10.json']
manifest={str(p.relative_to(w)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in evidence}
(w/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
with zipfile.ZipFile(out/'whole-project-review-evidence-2026-09-10.zip','w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('README.txt','GlyphPDF review finalized 2026-09-11 against recorded September 10 refs. This compact bundle contains reports, deltas, probe source, results and hashes. Full immutable source archives and vendor runtimes remain in the audit workspace; they are not duplicated here. Reproduction requires the matching checkout/snapshot and documented MSYS2/vendor dependencies. No production executable or customer PDF is included. Read the scope and validation limits before using a result as release evidence.\n')
    for p in evidence:z.write(p,'evidence/'+str(p.relative_to(w)).replace('\\','/'))
    z.write(w/'evidence-manifest.json','evidence/evidence-manifest.json')
    for p in reports:z.write(p,'reports/'+p.name)
print(json.dumps(verification,indent=2))
print('Packaged',len(evidence),'evidence files and',len(reports),'reports')
