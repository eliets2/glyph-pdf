#include <QCoreApplication>
#include <QElapsedTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <cstdio>
#include <windows.h>
#include <psapi.h>
#include "engines/MyersDiff.h"
int main(int argc,char**argv){
 QCoreApplication app(argc,argv);if(argc!=3)return 2;
 bool ok=false;int n=QString::fromLocal8Bit(argv[1]).toInt(&ok);if(!ok||n<1||n>2500)return 2;
 bool identical=QString::fromLocal8Bit(argv[2])=="same";QStringList a,b;
 for(int i=0;i<n;++i){a.append("A"+QString::number(i));b.append((identical?"A":"B")+QString::number(i));}
 QElapsedTimer timer;timer.start();auto ops=MyersDiff::compute(a,b);double ms=timer.nsecsElapsed()/1e6;
 int keep=0,add=0,del=0;for(const auto&op:ops){if(op.type==EditOp::Type::Keep)++keep;else if(op.type==EditOp::Type::Insert)++add;else if(op.type==EditOp::Type::Delete)++del;}
 PROCESS_MEMORY_COUNTERS pmc{};pmc.cb=sizeof(pmc);if(!GetProcessMemoryInfo(GetCurrentProcess(),&pmc,sizeof(pmc)))return 3;
 bool correct=identical?(keep==n&&add==0&&del==0):(keep==0&&add==n&&del==n);
 auto json=QJsonDocument(QJsonObject{{"tokensEach",n},{"identical",identical},{"elapsedMs",ms},{"peakWorkingSetBytes",double(pmc.PeakWorkingSetSize)},{"keep",keep},{"insert",add},{"delete",del},{"countsCorrect",correct}}).toJson(QJsonDocument::Compact);
 std::fwrite(json.constData(),1,json.size(),stdout);return correct?0:4;
}
