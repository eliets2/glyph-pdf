from pathlib import Path
import subprocess, zipfile, hashlib, json

w=Path(__file__).resolve().parent
repo='C:/Users/User/Projects/pdf-parity'
base=['git','-c','safe.directory='+repo,'-C',repo]
def git(*args): return subprocess.check_output(base+list(args))
published=git('rev-parse','origin/feat/parity-glm').decode().strip()
local=git('rev-parse','feat/parity-glm').decode().strip()
previous=json.loads((w/'baseline.json').read_text())['head']
archive=w/'published-source.zip'
archive.write_bytes(git('archive','--format=zip',published))
dst=w/'published-source'; dst.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z: z.extractall(dst)
(w/'published-delta.diff').write_bytes(git('diff',previous+'..'+published))
(w/'local-unpublished.diff').write_bytes(git('diff',published+'..'+local))
(w/'published-delta.log').write_bytes(git('log','--oneline',previous+'..'+published))
(w/'local-unpublished.log').write_bytes(git('log','--oneline',published+'..'+local))
manifest={'previousBaseline':previous,'publishedReviewedRef':published,'localIntegrationRef':local,
    'worktreeHead':git('rev-parse','HEAD').decode().strip(),
    'status':git('status','--short','--branch').decode(),
    'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'scope':'Source review delta to freshly fetched published branch. Snapshot remains immutable. Local-only integration delta preserved separately, not verified.'}
(w/'published-baseline.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
print(json.dumps(manifest,indent=2));print((w/'local-unpublished.log').read_text())
