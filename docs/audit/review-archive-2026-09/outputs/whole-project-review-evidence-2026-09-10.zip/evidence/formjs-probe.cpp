#include <QCoreApplication>
#include <QElapsedTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <iostream>
#include "engines/formjs/FormJsSandbox.h"
int main(int argc, char** argv) {
    QCoreApplication app(argc,argv);
    gp::formjs::FormJsSandbox box;
    QString error;
    if (!box.isValid() || !box.installShim(&error)) {std::cerr<<error.toStdString();return 2;}
    box.setFieldValues({{"total", "0"}});
    QString mode=argc>1?QString::fromUtf8(argv[1]):"normal";
    QString code="event.value = 42;";
    if(mode=="loop") code="while(true) {}";
    if(mode=="endHook") code="globalThis.__gpEndEvent = function() { while(true) {} }; event.value=42;";
    if(mode=="getter") code="Object.defineProperty(event, 'value', { get() { while(true) {} } });";
    QElapsedTimer clock;clock.start();
    auto r=box.runEvent(code,"total","Calculate","0",50);
    QJsonObject out{{"ok",r.ok},{"kind",int(r.kind)},{"value",r.value},{"message",r.message},
        {"elapsedMs",double(clock.elapsed())}};
    std::cout<<QJsonDocument(out).toJson(QJsonDocument::Compact).constData();
}
