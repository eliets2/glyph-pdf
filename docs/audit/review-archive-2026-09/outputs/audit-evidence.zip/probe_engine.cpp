#include <QApplication>
#include <QPdfWriter>
#include <QPainter>
#include <QFile>
#include <QDir>
#include <cstdio>
#include "engines/ConversionManager.h"
#include "engines/DiffEngine.h"
#include "engines/pdfium/PdfiumBackend.h"
#include "engines/FormManager.h"

static void makePdf(const QString& path, bool extraPage) {
    QPdfWriter writer(path);
    writer.setPageSize(QPageSize(QPageSize::A4));
    writer.setResolution(72);
    QPainter p(&writer);
    p.drawText(80, 100, "Shared first page");
    if (extraPage) {
        writer.newPage();
        p.drawText(80, 100, "Appendix UNIQUE appended content");
    }
    p.end();
}

int main(int argc, char** argv) {
    qInstallMessageHandler([](QtMsgType, const QMessageLogContext&, const QString& message) {
        std::fprintf(stdout, "%s\n", message.toUtf8().constData());
    });
    QApplication app(argc, argv);
    QCoreApplication::setOrganizationName("GlyphAudit");
    QCoreApplication::setApplicationName("EngineProbe");
    QDir().mkpath("../engine-probe-data");
    const QString dir = QDir("../engine-probe-data").absolutePath();
    makePdf(dir + "/one.pdf", false);
    makePdf(dir + "/two.pdf", true);
    PdfiumBackend source;
    if (source.loadDocument(dir + "/one.pdf"))
        std::printf("PDFium source text=%s\n", qPrintable(source.extractText(0)));
    ConversionManager cm;
    for (auto fmt : {IConversionEngine::TargetFormat::Word, IConversionEngine::TargetFormat::Excel}) {
        const QString path = dir + (fmt == IConversionEngine::TargetFormat::Word ? "/out.docx" : "/out.xlsx");
        const bool ok = cm.convertTo(dir + "/one.pdf", path, fmt);
        QFile f(path); if (!f.open(QIODevice::ReadOnly)) return 2;
        std::printf("Export %s: success=%d prefix=%s\n", qPrintable(QFileInfo(path).fileName()), ok, f.read(60).toHex().constData());
    }
    const DiffResult d = DiffEngine().compare(dir + "/one.pdf", dir + "/two.pdf", 72);
    int added=0, removed=0, pixels=0;
    for (const auto& p : d.pages) { added += p.textAdded.size(); removed += p.textRemoved.size(); pixels += p.pixelDiffCount; }
    std::printf("Compare appended page: pageCounts=%d/%d pagesCompared=%lld addedWords=%d removedWords=%d pixelDiff=%d moves=%lld\n", d.pageCount1, d.pageCount2, static_cast<long long>(d.pages.size()), added, removed, pixels, static_cast<long long>(d.pageMoves.size()));
    const QString formPath=dir+"/form.pdf";
    makePdf(formPath, false);
    FormManager fm;
    const auto originalSize=QFileInfo(formPath).size();
    const bool samePath=fm.addTextField(formPath,0,QRectF(72,150,140,30),"field",formPath);
    std::printf("Add field to same Qt PDF: success=%d sizeBefore=%lld sizeAfter=%lld\n",samePath,static_cast<long long>(originalSize),static_cast<long long>(QFileInfo(formPath).size()));
    makePdf(dir+"/form-source.pdf",false);
    const bool separatePath=fm.addTextField(dir+"/form-source.pdf",0,QRectF(72,150,140,30),"field",dir+"/form-output.pdf");
    std::printf("Add field with separate output: success=%d\n",separatePath);
}
