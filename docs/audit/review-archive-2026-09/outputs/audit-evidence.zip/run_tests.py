import os, pathlib, subprocess, sys
work = pathlib.Path(__file__).resolve().parent
env = {k.upper(): v for k,v in os.environ.items()}
env['PATH'] = 'C:/msys64/ucrt64/bin;' + env.get('PATH','')
env['QT_QPA_PLATFORM'] = 'offscreen'
with (work/'ctest-normalized-env.log').open('w') as log:
    r = subprocess.run(['C:/msys64/ucrt64/bin/ctest.exe','--test-dir',str(work/'build-current'),'--output-on-failure','-j4'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('\n'.join((work/'ctest-normalized-env.log').read_text().splitlines()[-70:]))
sys.exit(r.returncode)
