#include <QGuiApplication>
#include <QImage>
#include <QPainter>
#include <QFont>
#include <QDebug>
#include <cstdio>
#include "engines/ocr/OcrPreprocessor.h"
// Compile the production validator in this translation unit; no network calls.
#include "engines/ai/OllamaProvider.cpp"

int main(int argc, char** argv) {
    qInstallMessageHandler([](QtMsgType, const QMessageLogContext&, const QString& message) {
        std::fprintf(stdout, "%s\n", message.toUtf8().constData());
        std::fflush(stdout);
    });
    QGuiApplication app(argc, argv);
    QCoreApplication::setOrganizationName("GlyphAudit");
    QCoreApplication::setApplicationName("PureProbe");
    QImage page(1000, 800, QImage::Format_RGB32);
    page.fill(Qt::white);
    QPainter painter(&page);
    painter.setPen(Qt::black);
    painter.setFont(QFont("Arial", 22));
    for (int y=60; y<750; y+=45)
        painter.drawText(40, y, "The quick brown fox jumps over the lazy dog.");
    painter.end();
    const QImage binary = OcrPreprocessor().binarize(page);
    qInfo() << "Binarization white paper pixel: input=" << qGray(page.pixel(10,10))
            << "output=" << qGray(binary.pixel(10,10));
    const QImage tilted = page.transformed(QTransform().rotate(3));
    double angle = -999;
    const QImage deskewed = OcrPreprocessor().deskew(tilted, &angle);
    qInfo() << "Deskew on 3-degree tilted text: angle=" << angle
            << "imageUnchanged=" << (deskewed == tilted);
    for (const char* url : {"http://127.0.0.1:11434", "http://127.audit.invalid:11434", "http://remote.invalid:11434"})
        qInfo().noquote() << "Endpoint" << url << "allowed=" << gp::isAllowedEndpoint(QUrl(url));
}
