import os, pathlib, shlex, subprocess, sys

work = pathlib.Path(__file__).resolve().parent
build = work / 'build-current'
root = pathlib.Path('C:/Users/User/Projects/pdf')
os.environ['PATH'] = ';'.join([str(build), 'C:/msys64/ucrt64/bin', str(root/'third_party/podofo/install/bin'), str(root/'third_party/pdfium/bin'), str(root/'onnxruntime-win-x64-1.17.3/lib'), os.environ['PATH']])
command = subprocess.check_output(['ninja', '-t', 'commands', 'TestPptxOverlayAlpha'], cwd=build, text=True).splitlines()[-1]
libs = ['libpdfws_engines.a'] + shlex.split(command.split('  libpdfws_engines.a',1)[1].split(' &&',1)[0])
flags = shlex.split(subprocess.check_output(['pkg-config','--cflags','Qt6Widgets'],text=True))
subprocess.run(['g++','-std=c++17','-I'+str(root/'src'),'-I'+str(root/'third_party/podofo/install/include'),*flags,str(work/'probe_engine.cpp'),'-o','probe_engine.exe',*libs],cwd=build,check=True)
os.environ['QT_QPA_PLATFORM']='offscreen'
with (work/'probe_engine.log').open('w') as f:
    result = subprocess.run([str(build/'probe_engine.exe')],cwd=build,stdout=f,stderr=subprocess.STDOUT)
print((work/'probe_engine.log').read_text())
sys.exit(result.returncode)
